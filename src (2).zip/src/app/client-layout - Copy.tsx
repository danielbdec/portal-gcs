"use client";

import { useSession, signOut, signIn } from "next-auth/react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Spin } from "antd";
import {
  House,
  Users,
  ShieldUser,
  SquareCheckBig,
  UserPlus,
  Contact2,
  LogOut,
  ArrowBigLeft,
  ArrowBigRight,
  FileBadge,
  FileChartLine,
  FileSearch,
  FileX2,
} from "lucide-react";
import { LoadingOutlined } from "@ant-design/icons";
import Image from "next/image";

import ChatWidget from "../components/ChatWidget";

import "@refinedev/antd/dist/reset.css";
import "./globals.css";
import "./custom-sidebar.css";

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(true);
  const [loadingLogout, setLoadingLogout] = useState(false);
  const router = useRouter();
  const { data: session, status }: { data: any; status: "loading" | "authenticated" | "unauthenticated" } = useSession();

  if (status === "loading") {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
        <Spin tip="Carregando..." indicator={<LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />} />
      </div>
    );
  }

  if (status === "unauthenticated") {
    signIn("azure-ad", { callbackUrl: pathname });

    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
        <Spin tip="Redirecionando para a página de login..." indicator={<LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />} />
      </div>
    );
  }
  
  if (session && !loadingLogout) {
    const perfil = (session?.user?.perfil || "").toLowerCase().trim();
    
    // Define o tamanho do ícone com base no estado 'collapsed'
    const iconSize = collapsed ? 24 : 18;

    const menuItems: any[] = [
      {
        key: "inicio",
        icon: <House size={iconSize} color="white" />,
        label: "Início",
        onClick: () => router.push("/painel"),
      },
      {
        key: "perfil",
        icon: <ShieldUser size={iconSize} color="white" />,
        label: "Meu Perfil",
        onClick: () => router.push("/painel/perfil"),
      },
      {
        key: "nfentrada",
        icon: <FileBadge size={iconSize} color="white" />,
        label: "NF Entrada",
        children: [
          {
            key: "visaogeralnfe",
            icon: <FileChartLine size={18} color="white" />, // Ícones de submenu mantidos menores
            label: "Visão Geral",
            onClick: () => router.push("/painel/nfe/nfe-visao-geral"),
          },
          {
            key: "centralnfe",
            icon: <FileSearch size={18} color="white" />, // Ícones de submenu mantidos menores
            label: "Central de Notas",
            onClick: () => router.push("/painel/nfe/nfe-central"),
          },
          {
            key: "pendenciacompras",
            icon: <FileX2 size={18} color="white" />, // Ícones de submenu mantidos menores
            label: "Pendencia Compras",
            onClick: () => router.push("/painel/nfe/nfe-pendencia-compras"),
          },
          {
            key: "pendenciafiscal",
            icon: <FileX2 size={18} color="white" />, // Ícones de submenu mantidos menores
            label: "Pendencia Fiscal",
            onClick: () => router.push("/painel/nfe/nfe-pendencia-fiscal"),
          },
          {
            key: "regrafiscalnfe",
            icon: <FileX2 size={18} color="white" />, // Ícones de submenu mantidos menores
            label: "Regras Fiscais",
            onClick: () => router.push("/painel/nfe/nfe-regras-fiscais"),
          },
        ],
      },
    ];

    if (perfil === "admin") {
      menuItems.push({
        key: "cadastro-usuarios",
        icon: <Users size={iconSize} color="white" />,
        label: "Usuários",
        onClick: () => router.push("/painel/cadastro-usuarios"),
      });
    }

    const getSelectedKey = () => {
      if (!pathname) return undefined;
      if (pathname.startsWith("/painel/perfil")) return "perfil";
      if (pathname.startsWith("/painel/cadastro-usuarios")) return "cadastro-usuarios";
      if (pathname.startsWith("/painel/cadastro-cliente")) return "cadastro-cliente";
      if (pathname.startsWith("/painel/cadastro-contato")) return "cadastro-contato";
      if (pathname.startsWith("/painel/cadastro-area")) return "cadastro-area";
      return undefined;
    };
    
    return (
      <div style={{ display: "flex", height: "100vh" }}>
        <div
          onMouseEnter={() => setCollapsed(false)}
          onMouseLeave={() => setCollapsed(true)}
          style={{
            width: collapsed ? 80 : 240,
            transition: "width 0.3s ease-in-out",
            background: "linear-gradient(to bottom, var(--cor-sidebar-gradiente-topo), var(--cor-sidebar-gradiente-base))",
            padding: "1rem 0.5rem",
            color: "white",
            position: 'relative',
          }}
        >
          {/* LOGO E MENU */}
          <div>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                paddingLeft: collapsed ? 0 : 16,
                paddingRight: collapsed ? 0 : 16,
              }}
            >
              <Image
                src="/logo.png"
                alt="Logo"
                width={collapsed ? 70 : 140}
                height={collapsed ? 40 : 60}
                style={{ objectFit: "contain", transition: "all 0.3s ease-in-out" }}
              />
            </div>

            <Menu
              mode="inline"
              inlineCollapsed={collapsed}
              selectedKeys={getSelectedKey() ? [getSelectedKey() as string] : []}
              style={{ background: "transparent", borderRight: 0, marginTop: "2rem" }}
              items={menuItems}
            />
          </div>

          {/* BOTÃO DE SAIR COM POSICIONAMENTO ABSOLUTO */}
          <div
            onClick={async () => {
              setLoadingLogout(true);
              await signOut({ callbackUrl: '/login' });
            }}
            style={{
              position: 'absolute',
              bottom: '1rem',
              left: '0.5rem',
              right: '0.5rem',
              
              color: "white",
              cursor: "pointer",
              padding: "0.5rem 1rem",
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              justifyContent: collapsed ? 'center' : 'flex-start'
            }}
          >
            <LogOut size={iconSize} />
            {/* ALTERADO: Oculta o texto "Sair" alterando sua largura e usando overflow hidden.
              Isso garante que ele não ocupe espaço quando estiver recolhido.
            */}
            <span style={{ 
              transition: 'width 0.2s ease-in-out',
              whiteSpace: 'nowrap',
              width: collapsed ? 0 : 'auto',
              overflow: 'hidden',
            }}>
              Sair
            </span>
          </div>
        </div>
        <main style={{ flex: 1, overflow: "auto", padding: "1rem", position: "relative" }}>
          {children}
          <ChatWidget />
        </main>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <Spin tip="Saindo..." indicator={<LoadingOutlined style={{ fontSize: 48, color: "#52c41a" }} spin />} />
    </div>
  );
}