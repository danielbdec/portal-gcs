"use client";

import React, { useState, useRef, useEffect } from "react";
import { Tabs, Button, Card, Empty, Tag, Tooltip, Spin } from "antd";
import {
  X, FileText, Plus, Edit, Trash2, Landmark, Waves, Trees, FileStack,
  CalendarCheck, ShieldCheck, Building, Siren, Recycle, FileUp, Download, AlertTriangle
} from 'lucide-react';
import "antd/dist/reset.css";
import NotificationModal from "./NotificationModal";

const { TabPane } = Tabs;

/* ========================================================================
    Tipos compartilhados
    ======================================================================== */
export interface Empreendimento {
  id: number;
  nome: string;
  cnpj_cpf: string;
}

type DocumentoStatus = 'Vigente' | 'Vencido' | 'Em Renovação' | 'Não Aplicável';

interface Documento {
  id: number | string;
  numero: string;
  orgaoEmissor?: string;
  dataEmissao: string;
  dataValidade?: string;
  status: DocumentoStatus;
  nomeArquivo?: string;
  id_arquivo?: number;
  relKey?: string;
  observacao?: string;
}

interface ModalGestaoProps {
  visible: boolean;
  onClose: () => void;
  empreendimento: Empreendimento | null;
}

// Funções auxiliares
const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return 'N/A';
    try {
        const date = new Date(dateString);
        return new Intl.DateTimeFormat('pt-BR', { timeZone: 'UTC' }).format(date);
    } catch (e) {
        return 'Data Inválida';
    }
};

const getStatusInfo = (dataValidade: string | null | undefined): { status: DocumentoStatus; color: string } => {
    if (!dataValidade) {
        return { status: 'Não Aplicável', color: 'default' };
    }
    const hoje = new Date();
    const validade = new Date(dataValidade);
    hoje.setHours(0, 0, 0, 0);
    validade.setHours(0, 0, 0, 0);

    if (validade < hoje) {
        return { status: 'Vencido', color: 'red' };
    }
    return { status: 'Vigente', color: 'green' };
};

/* ========================================================================
    Modal interno: Certidão de Inteiro Teor (Upload)
    ======================================================================== */
const ModalCertidaoInteiroTeor: React.FC<{
  open: boolean;
  onClose: () => void;
  empreendimento: Empreendimento;
  onSuccess?: () => void;
}> = ({ open, onClose, empreendimento, onSuccess }) => {
  const [numero, setNumero] = useState<string>("");
  const [orgao, setOrgao] = useState<string>("");
  const [dataEmissao, setDataEmissao] = useState<string>("");
  const [dataValidade, setDataValidade] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [observacao, setObservacao] = useState<string>("");
  const [sending, setSending] = useState<boolean>(false);
  const [notifVisible, setNotifVisible] = useState<boolean>(false);
  const [notifType, setNotifType] = useState<"success" | "error">("success");
  const [notifMsg, setNotifMsg] = useState<string>("");
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!open) {
      setNumero(""); setOrgao(""); setDataEmissao(""); setDataValidade(""); setFile(null); setObservacao("");
      setSending(false); setNotifVisible(false); setNotifType("success"); setNotifMsg("");
    }
  }, [open]);

  useEffect(() => {
    if (open && modalRef.current) {
      const { clientWidth, clientHeight } = modalRef.current;
      setPosition({ x: window.innerWidth / 2 - clientWidth / 2, y: window.innerHeight / 2 - clientHeight / 2 });
    }
  }, [open]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!modalRef.current) return;
    setIsDragging(true);
    const modalRect = modalRef.current.getBoundingClientRect();
    dragOffsetRef.current = { x: e.clientX - modalRect.left, y: e.clientY - modalRect.top };
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    setPosition({ x: e.clientX - dragOffsetRef.current.x, y: e.clientY - dragOffsetRef.current.y });
  };

  const handleMouseUp = () => setIsDragging(false);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const closeNotif = () => {
    setNotifVisible(false);
    if (notifType === "success") { onClose(); }
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    if (!f) { setFile(null); return; }
    const allowed = [".pdf", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".zip"];
    const okExt = allowed.some((ext) => f.name.toLowerCase().endsWith(ext));
    if (!okExt) {
      setNotifType("error"); setNotifMsg("Extensão não permitida. Use PDF, JPG, PNG, TIF/TIFF ou ZIP."); setNotifVisible(true); return;
    }
    if (f.size > 30 * 1024 * 1024) {
      setNotifType("error"); setNotifMsg("Arquivo acima de 30MB."); setNotifVisible(true); return;
    }
    setFile(f);
  };

  const submit = async () => {
    if (!file) { setNotifType("error"); setNotifMsg("Selecione um arquivo."); setNotifVisible(true); return; }
    if (!numero || !dataEmissao) { setNotifType("error"); setNotifMsg("Preencha Número do Documento e Data de Emissão."); setNotifVisible(true); return; }
    try {
      setSending(true);
      const url = `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/api/agrogestor/uploads/certidao`;
      const fd = new FormData();
      fd.append("empreendimentoId", String(empreendimento.id));
      fd.append("tipo", "certidao_inteiro_teor");
      fd.append("numero_documento", numero);
      fd.append("orgao", orgao);
      fd.append("data_emissao", dataEmissao);
      fd.append("data_validade", dataValidade);
      fd.append("observacao", observacao);
      fd.append("file", file);
      const resp = await fetch(url, { method: "POST", body: fd });
      const text = await resp.text();
      let json: any = {};
      try { json = JSON.parse(text || "{}"); } catch { json = { ok: resp.ok, raw: text }; }
      if (!resp.ok || json?.ok === false) { throw new Error(json?.error || `Falha no processamento (${resp.status})`); }
      setNotifType("success");
      setNotifMsg("Certidão enviada para processamento com sucesso!");
      onSuccess?.();
    } catch (err: any) {
      setNotifType("error");
      setNotifMsg(err?.message || "Erro ao enviar.");
    } finally {
      setSending(false);
      setNotifVisible(true);
    }
  };

  if (!open) return null;

  return (
    <>
      <div style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.6)", zIndex: 2100 }} />
      <div ref={modalRef} onMouseDown={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()} style={{ position: "fixed", top: `${position.y}px`, left: `${position.x}px`, width: "95%", maxWidth: 640, background: "#fff", borderRadius: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.2)", zIndex: 2101, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div onMouseDown={handleMouseDown} style={{ padding: "14px 18px", background: "#00314A", color: "#fff", display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "grab" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}><FileText size={18} /><strong>Adicionar Certidão de Inteiro Teor</strong></div>
          <button onClick={() => { if (!sending) onClose(); }} style={{ background: "none", border: "none", color: "#fff", cursor: "pointer" }} title="Fechar" disabled={sending}><X size={20} /></button>
        </div>
        <div style={{ padding: "16px 18px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px 16px", opacity: sending ? 0.6 : 1, pointerEvents: sending ? "none" : "auto" }}>
          <div style={{ gridColumn: "1 / span 2", color: "var(--gcs-gray-dark)" }}><small>Empreendimento:</small> <strong>{empreendimento.nome}</strong></div>
          <div><label className="modal-label">Número do Documento *</label><input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="Ex.: M-10589" style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Órgão Emissor</label><input value={orgao} onChange={(e) => setOrgao(e.target.value)} placeholder="Ex.: Cartório de Registro de Imóveis" style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Data de Emissão *</label><input type="date" value={dataEmissao} onChange={(e) => setDataEmissao(e.target.value)} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Data de Validade</label><input type="date" value={dataValidade} onChange={(e) => setDataValidade(e.target.value)} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div style={{ gridColumn: "1 / span 2" }}><label className="modal-label">Arquivo (PDF/JPG/PNG/TIF/ZIP até 30MB) *</label><input type="file" onChange={handleFile} />{file && (<div style={{ marginTop: 6, fontSize: 12, color: "#555" }}> {file.name} — {(file.size / 1024 / 1024).toFixed(2)} MB </div>)}</div>
          <div style={{ gridColumn: "1 / span 2" }}>
            <label className="modal-label">Observação</label>
            <textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} maxLength={250} placeholder="Observações sobre o documento..." rows={3} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)", resize: "vertical" }} />
            <div style={{ textAlign: 'right', fontSize: '12px', color: '#888', marginTop: '4px' }}>{250 - observacao.length} caracteres restantes</div>
          </div>
        </div>
        <div style={{ padding: "14px 18px", borderTop: "1px solid var(--gcs-border-color)", display: "flex", justifyContent: "flex-end", gap: 8 }}><button className="btn btn-outline-gray" onClick={() => { if (!sending) onClose(); }} disabled={sending}>Fechar</button><button className="btn btn-green" onClick={submit} disabled={sending}>{sending ? "Enviando..." : "Salvar & Enviar"}</button></div>
        {sending && (<div style={{ position: "absolute", inset: 0, background: "rgba(255,255,255,0.7)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, zIndex: 2102 }}><Spin size="large" /><div style={{ color: "#333", fontWeight: 600 }}>Enviando arquivo…</div></div>)}
      </div>
      <NotificationModal visible={notifVisible} type={notifType} message={notifMsg} onClose={closeNotif} />
    </>
  );
};

/* ========================================================================
    Modal de Edição de Certidão
    ======================================================================== */
const ModalEditarCertidao: React.FC<{
    visible: boolean;
    onClose: () => void;
    documento: Documento | null;
    onSuccess: () => void;
}> = ({ visible, onClose, documento, onSuccess }) => {
    const [numero, setNumero] = useState("");
    const [orgao, setOrgao] = useState("");
    const [dataEmissao, setDataEmissao] = useState("");
    const [dataValidade, setDataValidade] = useState("");
    const [observacao, setObservacao] = useState("");
    const [loading, setLoading] = useState(false);
    const [notification, setNotification] = useState({ visible: false, type: 'success' as 'success' | 'error', message: '' });
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const modalRef = useRef<HTMLDivElement>(null);
    const dragOffsetRef = useRef({ x: 0, y: 0 });
    const inputStyle: React.CSSProperties = {
        width: '100%', padding: '10px', borderRadius: '6px',
        border: '1px solid #dee2e6', fontSize: '1rem'
    };

    useEffect(() => {
        if (documento) {
            setNumero(documento.numero || "");
            setOrgao(documento.orgaoEmissor || "");
            setObservacao(documento.observacao || "");
            try { setDataEmissao(documento.dataEmissao ? new Date(documento.dataEmissao).toISOString().split('T')[0] : ""); } catch { setDataEmissao(""); }
            try { setDataValidade(documento.dataValidade ? new Date(documento.dataValidade).toISOString().split('T')[0] : ""); } catch { setDataValidade(""); }
        }
    }, [documento]);

    useEffect(() => {
        if (visible && modalRef.current) {
            const { clientWidth, clientHeight } = modalRef.current;
            setPosition({ x: window.innerWidth / 2 - clientWidth / 2, y: window.innerHeight / 2 - clientHeight / 2 });
        }
    }, [visible]);

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!modalRef.current || (e.target as HTMLElement).closest('button')) return;
        setIsDragging(true);
        const modalRect = modalRef.current.getBoundingClientRect();
        dragOffsetRef.current = { x: e.clientX - modalRect.left, y: e.clientY - modalRect.top };
    };
    const handleMouseMove = (e: MouseEvent) => {
        if (!isDragging) return;
        e.preventDefault();
        setPosition({ x: e.clientX - dragOffsetRef.current.x, y: e.clientY - dragOffsetRef.current.y });
    };
    const handleMouseUp = () => setIsDragging(false);

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging]);

    if (!visible || !documento) return null;

    const handleAlterar = async () => {
        setLoading(true);
        try {
            const response = await fetch('/api/agrogestor/altera-certidao', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_certidao: documento.id,
                    numero_documento: numero,
                    orgao: orgao,
                    data_emissao: dataEmissao,
                    data_validade: dataValidade,
                    observacao: observacao,
                }),
            });
            const result = await response.json();
            const isSuccess = Array.isArray(result) && result.length > 0 && result[0].status === 'ok';
            if (!isSuccess) {
                const errorMessage = result?.error || (Array.isArray(result) && result[0]?.error) || 'Falha ao alterar o documento.';
                throw new Error(errorMessage);
            }
            setNotification({ visible: true, type: 'success', message: 'Documento alterado com sucesso!' });
            onSuccess();
        } catch (error: any) {
            setNotification({ visible: true, type: 'error', message: error.message });
        } finally {
            setLoading(false);
        }
    };
    
    const handleCloseNotification = () => {
        if (notification.type === 'success') { onClose(); }
        setNotification({ ...notification, visible: false });
    }

    return (
        <>
            <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2200 }} />
            <div ref={modalRef} style={{ position: 'fixed', top: `${position.y}px`, left: `${position.x}px`, zIndex: 2201, width: '90%', maxWidth: '640px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
                <div onMouseDown={handleMouseDown} style={{ padding: '1rem 1.5rem', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: isDragging ? 'grabbing' : 'grab' }}>
                    <h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Alterar Certidão</h3>
                    <button onClick={onClose} disabled={loading} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={20} /></button>
                </div>
                <div style={{ padding: '1.5rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem 1.5rem' }}>
                    <div><label className="modal-label">Número do Documento</label><input value={numero} onChange={e => setNumero(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Órgão Emissor</label><input value={orgao} onChange={e => setOrgao(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Data de Emissão</label><input type="date" value={dataEmissao} onChange={e => setDataEmissao(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Data de Validade</label><input type="date" value={dataValidade} onChange={e => setDataValidade(e.target.value)} style={inputStyle} /></div>
                    <div style={{ gridColumn: '1 / span 2' }}>
                        <label className="modal-label">Observação</label>
                        <textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} maxLength={250} rows={3} style={{ ...inputStyle, resize: 'vertical' }} />
                        <div style={{ textAlign: 'right', fontSize: '12px', color: '#888', marginTop: '4px' }}>{250 - observacao.length} caracteres restantes</div>
                    </div>
                </div>
                <div style={{ padding: '1rem 1.5rem', borderTop: '1px solid #eee', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                    <Button onClick={onClose} disabled={loading}>Cancelar</Button>
                    <Button type="primary" onClick={handleAlterar} loading={loading}>Alterar</Button>
                </div>
            </div>
            <NotificationModal visible={notification.visible} type={notification.type} message={notification.message} onClose={handleCloseNotification} />
        </>
    );
};

/* ========================================================================
    Modal de Confirmação de Exclusão
    ======================================================================== */
const ModalConfirmarExclusao: React.FC<{
    visible: boolean;
    onClose: () => void;
    onConfirm: () => void;
    loading: boolean;
}> = ({ visible, onClose, onConfirm, loading }) => {
    if (!visible) return null;
    return (
        <>
            <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2300 }} />
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 2301, width: '90%', maxWidth: '450px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', padding: '2rem', textAlign: 'center' }}>
                <AlertTriangle size={48} color="var(--gcs-orange)" style={{ marginBottom: '1rem' }} />
                <h3 style={{ margin: '0 0 0.5rem 0', color: 'var(--gcs-blue)' }}>Confirmar Exclusão</h3>
                <p style={{ color: 'var(--gcs-gray-dark)', marginBottom: '2rem' }}>Tem certeza que deseja excluir este documento? Esta ação não pode ser desfeita.</p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                    <Button onClick={onClose} disabled={loading}>Cancelar</Button>
                    <Button type="primary" danger onClick={onConfirm} loading={loading}>Excluir</Button>
                </div>
            </div>
        </>
    );
};

/* ========================================================================
    Componente reutilizável DocumentSection
    ======================================================================== */
const DocumentSection: React.FC<{
  title: string;
  icon: React.ReactNode;
  empreendimentoId: number;
  apiEndpoint: string;
  refreshTrigger: number;
  onAdd: () => void;
  onEdit: (doc: Documento) => void;
  onDelete: (doc: Documento) => void;
  onDownload: (doc: Documento) => void;
  headBg?: string;
  downloadingDocId?: number | string | null;
}> = ({
  title, icon, empreendimentoId, apiEndpoint, refreshTrigger, onAdd, onEdit, onDelete, onDownload,
  headBg, downloadingDocId
}) => {
    const [documents, setDocuments] = useState<Documento[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!empreendimentoId || !apiEndpoint) {
            setLoading(false);
            return;
        };
        
        const fetchDocuments = async () => {
            setLoading(true);
            try {
                const response = await fetch(apiEndpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ empreendimento_id: empreendimentoId }),
                });
                if (!response.ok) throw new Error(`Falha ao consultar API: ${apiEndpoint}`);
                
                const data = await response.json();
                const formattedData = data.map((doc: any) => ({ 
                    id: doc.id_certidao || doc.id_ccir || doc.id_itr || doc.id_geo || doc.id_kml || doc.id,
                    numero: doc.numero_documento, 
                    orgaoEmissor: doc.orgao, 
                    dataEmissao: doc.data_emissao, 
                    dataValidade: doc.data_validade, 
                    nomeArquivo: doc.nome_arquivo,
                    id_arquivo: doc.id_arquivo,
                    relKey: doc.relKey,
                    observacao: doc.observacao || doc.observacoes
                }));
                setDocuments(formattedData);
            } catch (error) {
                console.error(`Erro ao carregar dados para ${title}:`, error);
                setDocuments([]);
            } finally {
                setLoading(false);
            }
        };

        fetchDocuments();
    }, [empreendimentoId, apiEndpoint, title, refreshTrigger]);
    
    // CORREÇÃO: Filtra documentos "fantasmas" (sem ID) antes de renderizar
    const validDocuments = documents.filter(doc => doc && doc.id);

    return (
        <Card
          title={<div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}><>{icon}</><span style={{ color: 'var(--gcs-blue)', fontWeight: 600 }}>{title}</span></div>}
          style={{ marginBottom: '1.5rem' }}
          headStyle={{ background: headBg ?? undefined, borderTopLeftRadius: 8, borderTopRightRadius: 8 }}
          extra={<Button icon={<Plus size={16} />} onClick={onAdd} type="primary" ghost>Adicionar</Button>}
        >
          {loading ? (<div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100px'}}><Spin /></div>) 
          : validDocuments.length === 0 ? (<Empty description={`Nenhum documento do tipo "${title}" cadastrado.`} image={Empty.PRESENTED_IMAGE_SIMPLE} />) 
          : (<div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {validDocuments.map((doc) => {
                  const { status, color } = getStatusInfo(doc.dataValidade);
                  return (
                  <Card key={doc.id} bordered size="small">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flex: 1 }}>
                              <FileText size={32} color="var(--gcs-blue)" />
                              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, auto)', gap: '8px 24px', flex: 1, whiteSpace: 'nowrap' }}>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>N° Documento:</strong> {doc.numero || '-'}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Órgão Emissor:</strong> {doc.orgaoEmissor || '-'}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Data Emissão:</strong> {formatDate(doc.dataEmissao)}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Data Validade:</strong> {formatDate(doc.dataValidade)}</p>
                                  {doc.observacao && (
                                      <p style={{ margin: 0, gridColumn: '1 / span 2', marginTop: '8px', paddingTop: '8px', borderTop: '1px dotted #ccc', whiteSpace: 'normal', color: 'var(--gcs-gray-dark)' }}>
                                          <strong style={{color: '#333'}}>Observação:</strong> {doc.observacao}
                                      </p>
                                  )}
                              </div>
                          </div>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}>
                              <Tag color={color}>{status}</Tag>
                              <div style={{display: 'flex', gap: '8px'}}>
                                  <Tooltip title={doc.nomeArquivo || "Baixar Arquivo"}><Button icon={<Download size={16} />} onClick={() => onDownload(doc)} loading={downloadingDocId === doc.id} /></Tooltip>
                                  <Tooltip title="Editar Documento"><Button icon={<Edit size={16} />} onClick={() => onEdit(doc)} /></Tooltip>
                                  <Tooltip title="Excluir Documento"><Button icon={<Trash2 size={16} />} onClick={() => onDelete(doc)} danger /></Tooltip>
                              </div>
                          </div>
                      </div>
                  </Card>
              )})}
            </div>
          )}
        </Card>
    );
};

/* ========================================================================
    Modal principal: Gestão de Documentos
    ======================================================================== */
const ModalGestao: React.FC<ModalGestaoProps> = ({ visible, onClose, empreendimento }) => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [documentoParaEditar, setDocumentoParaEditar] = useState<Documento | null>(null);
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [documentoParaExcluir, setDocumentoParaExcluir] = useState<Documento | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [notification, setNotification] = useState({ visible: false, type: 'success' as 'success' | 'error', message: '' });
  const [openCertidao, setOpenCertidao] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });
  const [downloadingDocId, setDownloadingDocId] = useState<number | string | null>(null);

  useEffect(() => {
    if (visible && modalRef.current) {
        const { clientWidth, clientHeight } = modalRef.current;
        setPosition({ x: window.innerWidth / 2 - clientWidth / 2, y: window.innerHeight / 2 - clientHeight / 2 });
    }
  }, [visible]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!modalRef.current || (e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    const modalRect = modalRef.current.getBoundingClientRect();
    dragOffsetRef.current = { x: e.clientX - modalRect.left, y: e.clientY - modalRect.top };
  };
  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    setPosition({ x: e.clientX - dragOffsetRef.current.x, y: e.clientY - dragOffsetRef.current.y });
  };
  const handleMouseUp = () => setIsDragging(false);

  useEffect(() => {
    if (isDragging) {
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const handleAbrirModalEdicao = (doc: Documento) => {
      setDocumentoParaEditar(doc);
      setIsEditModalVisible(true);
  };

  const handleAbrirModalExclusao = (doc: Documento) => {
    setDocumentoParaExcluir(doc);
    setIsDeleteModalVisible(true);
  };

  const handleConfirmarExclusao = async () => {
    if (!documentoParaExcluir) return;
    setIsDeleting(true);
    try {
        const response = await fetch('/api/agrogestor/inativa-certidao', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_certidao: documentoParaExcluir.id }),
        });
        const result = await response.json();
        const isSuccess = Array.isArray(result) && result.length > 0 && result[0].status === 'ok';
        if (!isSuccess) { throw new Error(result?.error || 'Falha ao excluir o documento.'); }
        setNotification({ visible: true, type: 'success', message: 'Documento excluído com sucesso!' });
        setRefreshTrigger(t => t + 1);
    } catch (error: any) {
        setNotification({ visible: true, type: 'error', message: error.message });
    } finally {
        setIsDeleting(false);
        setIsDeleteModalVisible(false);
    }
  };

  const handleDownload = async (doc: Documento) => {
    if (!doc.relKey || !doc.nomeArquivo) {
        setNotification({ visible: true, type: 'error', message: 'Informações do arquivo (relKey) ausentes.' });
        return;
    }
    setDownloadingDocId(doc.id);
    try {
        const response = await fetch('/api/agrogestor/download-arquivo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ relKey: doc.relKey, nome_arquivo: doc.nomeArquivo }),
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Não foi possível baixar o arquivo.' }));
            throw new Error(errorData.message || 'Não foi possível baixar o arquivo.');
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = doc.nomeArquivo;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    } catch (error: any) {
        setNotification({ visible: true, type: 'error', message: error.message });
    } finally {
        setDownloadingDocId(null);
    }
  };

  if (!visible || !empreendimento) return null;
  const HEAD_HIGHLIGHT = "rgba(0, 102, 204, 0.10)";

  return (
    <>
      <div style={{ position: 'fixed', top:0, left:0, width:'100vw', height:'100vh', backgroundColor:'rgba(0,0,0,0.6)', zIndex: 1000 }} />
      <div ref={modalRef} style={{ position: 'fixed', top: `${position.y}px`, left: `${position.x}px`, backgroundColor: 'white', borderRadius: '12px', boxShadow: '0 8px 32px rgba(0,0,0,0.2)', zIndex: 1001, width: '95%', maxWidth: '1200px', height: '90vh', display: 'flex', flexDirection: 'column' }}>
        <div onMouseDown={handleMouseDown} style={{ padding: '1rem 1.5rem', borderBottom: '1px solid #dee2e6', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f1f5fb', cursor: isDragging ? 'grabbing' : 'grab' }}>
          <div><h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Gestão de Documentos</h3><p style={{ margin: 0, color: 'var(--gcs-gray-dark)', fontWeight: 'bold' }}>Empreendimento: {empreendimento.nome}</p></div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}><X size={24} color="var(--gcs-gray-dark)"/></button>
        </div>
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <Tabs defaultActiveKey="1" tabPosition="left" style={{ height: '100%' }}>
            <TabPane tab={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Landmark size={18}/> Fundiário</span>} key="1">
              <div style={{ padding:'1rem 1.5rem', overflowY:'auto', height:'calc(90vh - 140px)' }}>
                <DocumentSection 
                    title="Certidão de Inteiro Teor da Matrícula" icon={<FileText size={20} />} empreendimentoId={empreendimento.id}
                    apiEndpoint="/api/agrogestor/consulta-certidao" refreshTrigger={refreshTrigger} onAdd={() => setOpenCertidao(true)} onEdit={handleAbrirModalEdicao} 
                    onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT}
                />
                <DocumentSection 
                    title="CCIR (Certificado de Cadastro de Imóvel Rural)" icon={<FileStack size={20} />} empreendimentoId={empreendimento.id}
                    apiEndpoint="/api/agrogestor/consulta-ccir" refreshTrigger={refreshTrigger} onAdd={() => alert('A implementar')} onEdit={handleAbrirModalEdicao} 
                    onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT}
                />
                <DocumentSection 
                    title="ITR (Imposto sobre a Propriedade Territorial Rural)" icon={<Recycle size={20} />} empreendimentoId={empreendimento.id}
                    apiEndpoint="/api/agrogestor/consulta-itr" refreshTrigger={refreshTrigger} onAdd={() => alert('A implementar')} onEdit={handleAbrirModalEdicao} 
                    onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT}
                />
                <DocumentSection 
                    title="GEO (Georreferenciamento)" icon={<Trees size={20} />} empreendimentoId={empreendimento.id}
                    apiEndpoint="/api/agrogestor/consulta-geo" refreshTrigger={refreshTrigger} onAdd={() => alert('A implementar')} onEdit={handleAbrirModalEdicao} 
                    onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT}
                />
                <DocumentSection 
                    title="KML (Arquivo de Limites)" icon={<FileUp size={20} />} empreendimentoId={empreendimento.id}
                    apiEndpoint="/api/agrogestor/consulta-kml" refreshTrigger={refreshTrigger} onAdd={() => alert('A implementar')} onEdit={handleAbrirModalEdicao} 
                    onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT}
                />
              </div>
            </TabPane>
            <TabPane tab={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Trees size={18}/> Ambiental</span>} key="2">
              <div style={{ padding:'1rem 1.5rem', overflowY:'auto', height:'calc(90vh - 140px)' }}>
                {/* As seções desta aba permanecem estáticas por enquanto */}
              </div>
            </TabPane>
            <TabPane tab={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Building size={18}/> Obrigações e Cadastros</span>} key="3">
              <div style={{ padding:'1rem 1.5rem', overflowY:'auto', height:'calc(90vh - 140px)' }}>
                {/* As seções desta aba permanecem estáticas por enquanto */}
              </div>
            </TabPane>
          </Tabs>
        </div>
        <div style={{ padding:'1rem 1.5rem', borderTop:'1px solid #dee2e6', display:'flex', justifyContent:'flex-end', backgroundColor:'#f8f9fa' }}>
          <Button onClick={onClose} size="large">Fechar</Button>
        </div>
      </div>
      <ModalCertidaoInteiroTeor open={openCertidao} onClose={() => setOpenCertidao(false)} empreendimento={empreendimento} onSuccess={() => { setRefreshTrigger(t => t + 1) }}/>
      <ModalEditarCertidao visible={isEditModalVisible} onClose={() => setIsEditModalVisible(false)} documento={documentoParaEditar} onSuccess={() => { setRefreshTrigger(t => t + 1); }}/>
      <ModalConfirmarExclusao visible={isDeleteModalVisible} onClose={() => setIsDeleteModalVisible(false)} onConfirm={handleConfirmarExclusao} loading={isDeleting} />
      <NotificationModal visible={notification.visible} type={notification.type} message={notification.message} onClose={() => setNotification({ ...notification, visible: false })} />
    </>
  );
};

export default ModalGestao;