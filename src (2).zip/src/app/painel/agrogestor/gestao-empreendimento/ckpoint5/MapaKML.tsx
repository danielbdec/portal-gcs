// MapaKML.tsx
"use client";

import React, { useEffect, useState, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Polygon } from '@react-google-maps/api';
import { kml } from '@tmcw/togeojson';
import { Spin } from 'antd';

// Estilos e configurações do mapa
const containerStyle = { width: '100%', height: '400px', borderRadius: '8px' };
const center = { lat: -15.77972, lng: -47.92972 };
const polygonOptions = {
    fillColor: "#007bff",
    fillOpacity: 0.3,
    strokeColor: "#007bff",
    strokeOpacity: 1,
    strokeWeight: 2,
    clickable: false,
    draggable: false,
    editable: false,
    geodesic: false,
    zIndex: 1
};

interface MapaKMLProps {
  urlKML: string;
}

const MapaKML: React.FC<MapaKMLProps> = ({ urlKML }) => {
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [paths, setPaths] = useState<google.maps.LatLngLiteral[][]>([]);

  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""
  });

  useEffect(() => {
    if (!urlKML) return;

    const fetchAndProcessKML = async () => {
      try {
        const response = await fetch(urlKML);
        if (!response.ok) throw new Error('Falha ao buscar o arquivo KML.');
        
        const kmlText = await response.text();
        const parser = new DOMParser();
        const kmlDoc = parser.parseFromString(kmlText, 'text/xml');
        
        if (kmlDoc.getElementsByTagName('parsererror').length) {
            throw new Error('Arquivo KML parece ser inválido ou mal-formado.');
        }

        const geoJson = kml(kmlDoc);

        if (!geoJson || !geoJson.features || geoJson.features.length === 0) {
            throw new Error('O arquivo KML não contém nenhuma geometria para exibir.');
        }
        
        const allPaths: google.maps.LatLngLiteral[][] = [];
        const bounds = new window.google.maps.LatLngBounds();

        geoJson.features.forEach((feature: any) => {
          let geometryCoords: any[] = [];
          
          if (feature.geometry?.type === 'Polygon') {
              geometryCoords = feature.geometry.coordinates[0]; // Pega o anel exterior do polígono
          } else if (feature.geometry?.type === 'LineString') {
              geometryCoords = feature.geometry.coordinates;
          }

          if (geometryCoords.length > 0) {
            const path = geometryCoords.map(coord => {
              const latLng = { lat: coord[1], lng: coord[0] };
              bounds.extend(latLng); // Estende os limites para incluir cada ponto
              return latLng;
            });
            allPaths.push(path);
          }
        });

        setPaths(allPaths);

        // Se o mapa já estiver carregado, ajusta o zoom
        if (map) {
          map.fitBounds(bounds);
        }

      } catch (err: any) {
        console.error("Erro no processamento do KML:", err);
      }
    };

    fetchAndProcessKML();
  }, [urlKML, map]); // Adiciona 'map' como dependência para ajustar o zoom quando ele carregar

  const onMapLoad = useCallback((mapInstance: google.maps.Map) => {
    setMap(mapInstance);
  }, []);

  const onMapUnmount = useCallback(() => {
    setMap(null);
  }, []);

  if (loadError) return <div>Erro ao carregar o mapa. Verifique a chave de API.</div>;
  if (!isLoaded) return <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}><Spin /></div>;

  return (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={center}
      zoom={4}
      onLoad={onMapLoad}
      onUnmount={onMapUnmount}
      options={{ mapTypeControl: true, streetViewControl: false, fullscreenControl: false }}
    >
      {paths.map((path, index) => (
        <Polygon key={index} paths={path} options={polygonOptions} />
      ))}
    </GoogleMap>
  );
};

export default MapaKML;