"use client";

import { useEffect, useState, useMemo } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Tooltip, Button, Typography, Input } from "antd";
import * as XLSX from 'xlsx';
import {
    PieChart, Pie, Cell, Legend, ResponsiveContainer, Sector
} from "recharts";
import {
    RefreshCcw, Search, Filter, X, FileDown, Lock, FolderArchive, FolderGit2
} from "lucide-react";
import React from "react";
import "antd/dist/reset.css";

import ModalGestao from "./ModalGestao"; 

const { Title } = Typography;

interface EmpreendimentoCompleto {
  id: number | null;
  key: string;
  nome: string | null;
  cnpj_cpf: string | null;
  unidade: string | null;
  estado: string | null;
  numero_matricula?: string | null;
}

const LoadingSpinner = ({ text }: { text: string }) => (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem', textAlign: 'center' }}>
        <div style={{ width: '40px', height: '40px', border: '4px solid var(--gcs-gray-medium)', borderTop: '4px solid var(--gcs-blue)', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
        <div style={{ marginTop: '1rem', fontWeight: 'bold', color: 'var(--gcs-blue)' }}>
            {text}
        </div>
    </div>
);

const AcessoNegado = () => {
  const router = useRouter();
  return (
    <div className="content-card" style={{ textAlign: 'center', padding: '3rem', maxWidth: '600px', margin: 'auto' }}>
      <Lock size={48} color="var(--gcs-orange)" />
      <h2 style={{ marginTop: '1.5rem', color: 'var(--gcs-blue)' }}>Acesso Negado</h2>
      <p style={{ color: 'var(--gcs-gray-dark)', maxWidth: '400px', margin: '1rem auto' }}>
        Você não tem as permissões necessárias para visualizar este módulo.
      </p>
      <button onClick={() => router.push('/painel')} className="btn btn-green" style={{ marginTop: '1rem' }}>
        Voltar ao Painel
      </button>
    </div>
  );
};

const FilterPopover = ({
    empreendimentos, onApplyFilters, initialFilters
}: { empreendimentos: EmpreendimentoCompleto[], onApplyFilters: (filters: any) => void, initialFilters: any }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [estado, setEstado] = useState(initialFilters.estado || 'Todos');
    const [unidade, setUnidade] = useState(initialFilters.unidade || 'Todas');
    const popoverRef = React.useRef<HTMLDivElement>(null);
    const estadosUnicos = useMemo(() => ['Todos', ...Array.from(new Set(empreendimentos.map(e => e.estado).filter(Boolean)))], [empreendimentos]);
    const unidadesUnicas = useMemo(() => ['Todos', ...Array.from(new Set(empreendimentos.map(e => e.unidade).filter(Boolean)))], [empreendimentos]);
    const handleApply = () => { onApplyFilters({ estado, unidade }); setIsOpen(false); };
    const handleClear = () => { setEstado('Todos'); setUnidade('Todas'); onApplyFilters({ estado: 'Todos', unidade: 'Todas' }); setIsOpen(false); };
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => { if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) setIsOpen(false); };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [popoverRef]);

    return (
        <div style={{ position: 'relative' }} ref={popoverRef}>
            <button onClick={() => setIsOpen(!isOpen)} title="Filtros Avançados" className="btn btn-outline-gray" style={{padding: '9px'}}><Filter size={20} /></button>
            {isOpen && (<div style={{ position: 'absolute', top: '100%', right: 0, marginTop: '8px', width: '300px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 8px 24px rgba(0,0,0,0.15)', border: '1px solid var(--gcs-border-color)', zIndex: 100, padding: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}><h4 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Filtros Avançados</h4><button onClick={() => setIsOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={18} color="var(--gcs-gray-dark)" /></button></div>
                <div style={{ marginBottom: '1rem' }}><label className="modal-label">Estado</label><select value={estado} onChange={(e) => setEstado(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--gcs-border-color)' }}>{estadosUnicos.map(f => <option key={f} value={f}>{f}</option>)}</select></div>
                <div style={{ marginBottom: '1.5rem' }}><label className="modal-label">Unidade</label><select value={unidade} onChange={(e) => setUnidade(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--gcs-border-color)' }}>{unidadesUnicas.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}><button onClick={handleClear} className="btn btn-outline-gray" style={{padding: '8px 16px'}}>Limpar</button><button onClick={handleApply} className="btn btn-green" style={{padding: '8px 16px'}}>Aplicar</button></div>
            </div>)}
        </div>
    );
};

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;
  return (<g><Sector cx={cx} cy={cy} innerRadius={innerRadius} outerRadius={outerRadius + 8} startAngle={startAngle} endAngle={endAngle} fill={fill}/></g>);
};

export default function AgrogestorPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [authStatus, setAuthStatus] = useState<'loading' | 'authorized' | 'unauthorized'>('loading');
  const [empreendimentos, setEmpreendimentos] = useState<EmpreendimentoCompleto[]>([]);
  const [busca, setBusca] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [advancedFilters, setAdvancedFilters] = useState({ estado: 'Todos', unidade: 'Todas' });
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [isGestaoModalOpen, setIsGestaoModalOpen] = useState(false);
  const [selectedEmpreendimento, setSelectedEmpreendimento] = useState<EmpreendimentoCompleto | null>(null);

  useEffect(() => {
    if (status === 'loading') { setAuthStatus('loading'); return; }
    if (status === 'authenticated') {
      const user = session.user;
      const hasAccess = user?.is_admin === true || user?.funcoes?.includes('agrogestor.empreendimentos');
      if (hasAccess) { setAuthStatus('authorized'); fetchEmpreendimentos(); } else { setAuthStatus('unauthorized'); }
    } else { router.push('/login'); }
  }, [status, session, router]);

  const fetchEmpreendimentos = async () => {
      setLoading(true);
      try {
        const response = await fetch('/api/agrogestor/consulta-empreendimento', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}), });
        if (!response.ok) { throw new Error('Falha ao buscar dados'); }
        const data: any[] = await response.json();
        const empreendimentosComChave = data.map((emp, index) => ({ ...emp, key: emp.id ? emp.id.toString() : `fallback-key-${index}` }));
        setEmpreendimentos(empreendimentosComChave);
      } catch (error: any) {
        console.error("Erro ao buscar empreendimentos:", error);
        alert(error.message || "Não foi possível carregar os empreendimentos.");
      } finally { setLoading(false); }
    };

  const kpiData = useMemo(() => ({ totalEmpreendimentos: empreendimentos.length, totalDocsAlerta: 0 }), [empreendimentos]);
  const dadosGraficoEstados = useMemo(() => {
    const counts: Record<string, number> = {};
    empreendimentos.forEach(emp => { if(emp.estado) { counts[emp.estado] = (counts[emp.estado] || 0) + 1; } });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [empreendimentos]);

  const coresGrafico = ["#00314A", "#5FB246", "#F58220", "#007bff", "#6c757d"];

  const empreendimentosFiltrados = useMemo(() => {
    let dadosFiltrados = [...(empreendimentos || [])];
    if (busca) {
        const termo = busca.toLowerCase();
        dadosFiltrados = dadosFiltrados.filter(emp => (emp.nome?.toLowerCase() ?? '').includes(termo) || (emp.cnpj_cpf ?? '').includes(termo));
    }
    if (advancedFilters.estado && advancedFilters.estado !== 'Todos') {
        dadosFiltrados = dadosFiltrados.filter(emp => emp.estado === advancedFilters.estado);
    }
    if (advancedFilters.unidade && advancedFilters.unidade !== 'Todas') {
        dadosFiltrados = dadosFiltrados.filter(emp => emp.unidade === advancedFilters.unidade);
    }
    return dadosFiltrados;
  }, [empreendimentos, busca, advancedFilters]);

  const handleExportXLSX = () => { /* ... (código mantido) */ };
  const handleOpenGestaoModal = (empreendimento: EmpreendimentoCompleto) => { setSelectedEmpreendimento(empreendimento); setIsGestaoModalOpen(true); };
  const handleCloseGestaoModal = () => { setIsGestaoModalOpen(false); setSelectedEmpreendimento(null); };

  if (authStatus === 'loading') return <LoadingSpinner text="A verificar permissões..." />;
  if (authStatus === 'unauthorized') return <AcessoNegado />;
  
  return (<>
    <style>{`
        :root { 
            --gcs-blue: #00314A; --gcs-green: #5FB246; --gcs-orange: #F58220;
            --gcs-orange-light: #FDBA74; --gcs-red: #d9534f; --gcs-red-light: #ff6f61;
            --gcs-gray-light: #f8f9fa; --gcs-gray-medium: #e9ecef; --gcs-gray-dark: #6c757d; 
            --gcs-border-color: #dee2e6;
            
            --gcs-download-color: var(--gcs-blue); /* Alterado para usar o azul principal */
            --gcs-edit-color: #F58220;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .btn { cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s ease-in-out; border: 1px solid transparent; padding: 10px 20px; border-radius: 8px; }
        .btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .btn-green { background-color: var(--gcs-green); color: white; }
        .btn-outline-gray { background-color: #fff; color: var(--gcs-gray-dark); border-color: var(--gcs-border-color); }
        .btn-outline-blue { background-color: #fff; color: var(--gcs-blue); border-color: var(--gcs-border-color); }
        .kpi-card, .chart-card, .main-content-card, .content-card { background-color: #fff; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); border: 1px solid var(--gcs-border-color); }
        .modal-label { display: block; margin-bottom: 6px; font-size: 14px; font-weight: 500; color: #333; }

        /* CLASSES DE BOTÃO PARA SOBRESCREVER O TEMA */
        .btn-action-download, .btn-action-edit, .btn-action-delete {
            color: white !important;
        }
        .btn-action-download {
            background-color: var(--gcs-download-color) !important;
            border-color: var(--gcs-download-color) !important;
        }
        .btn-action-download:hover {
            background-color: #002233 !important; /* Um tom mais escuro de azul para o hover */
            border-color: #002233 !important;
        }
        .btn-action-edit {
            background-color: var(--gcs-edit-color) !important;
            border-color: var(--gcs-edit-color) !important;
        }
        .btn-action-edit:hover {
            background-color: #d46a00 !important;
            border-color: #d46a00 !important;
        }
        .btn-action-delete {
            background-color: var(--gcs-red) !important;
            border-color: var(--gcs-red) !important;
        }
        .btn-action-delete:hover {
            background-color: #c9302c !important;
            border-color: #c9302c !important;
        }
    `}</style>

    <div className="main-container" style={{ padding: "2rem", backgroundColor: "#E9ECEF", minHeight: "100vh" }}>
      <div className="header-wrapper" style={{ display: 'flex', alignItems: 'stretch', gap: '1.5rem', marginBottom: '1.5rem' }}>
        <div className="chart-card" style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
            <h4 style={{ margin: 0, color: 'var(--gcs-gray-dark)', fontWeight: 500, fontSize: '1rem' }}>Empreendimentos por Estado</h4>
            <div style={{ width: 280, height: 160 }}>
                <ResponsiveContainer width="100%" height="100%"><PieChart>
                    <Pie activeIndex={activeIndex} activeShape={renderActiveShape} data={dadosGraficoEstados} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={3} onMouseEnter={(_, index) => setActiveIndex(index)} onMouseLeave={() => setActiveIndex(null)}>
                        {dadosGraficoEstados.map((entry, index) => (<Cell key={`cell-${index}`} fill={coresGrafico[index % coresGrafico.length]} />))}
                    </Pie>
                    <Legend layout="horizontal" align="center" verticalAlign="bottom" iconSize={10} wrapperStyle={{ fontSize: '12px' }}/>
                </PieChart></ResponsiveContainer>
            </div>
        </div>
        <div className="main-content-card" style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '1.5rem' }}>
            <h2 className="page-title" style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold', color: 'var(--gcs-blue)', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><FolderArchive size={32} /> <span>Gestão de Documentos</span></h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <Input placeholder="Buscar por nome ou CNPJ/CPF..." value={busca} onChange={(e) => setBusca(e.target.value)} style={{ padding: "12px 16px", width: "350px", borderRadius: "8px" }}/>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button onClick={fetchEmpreendimentos} title="Atualizar Lista" className="btn btn-outline-gray" style={{padding: '9px'}}> <RefreshCcw size={20} /> </button>
                    <FilterPopover empreendimentos={empreendimentos} onApplyFilters={setAdvancedFilters} initialFilters={advancedFilters} />
                    <button onClick={handleExportXLSX} title="Exportar para Excel" className="btn btn-outline-blue" style={{padding: '9px'}}> <FileDown size={20} /> </button>
                </div>
            </div>
        </div>
        <div className="kpi-card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-around' }}>
            <div style={{ textAlign: 'center' }}><h4 style={{ color: 'var(--gcs-gray-dark)', margin: 0, fontWeight: 500 }}>Empreendimentos</h4><p style={{ fontSize: '2.2rem', margin: 0, color: 'var(--gcs-blue)', fontWeight: 'bold' }}>{kpiData.totalEmpreendimentos}</p></div>
            <hr style={{ width: '80%', border: 'none', borderTop: '1px solid var(--gcs-border-color)' }} />
            <div style={{ textAlign: 'center' }}><h4 style={{ color: 'var(--gcs-gray-dark)', margin: 0, fontWeight: 500 }}>Docs em Alerta</h4><p style={{ fontSize: '2.2rem', margin: 0, color: 'var(--gcs-orange)', fontWeight: 'bold' }}>{kpiData.totalDocsAlerta}</p></div>
        </div>
      </div>
      <div className="content-card">
        <h3 style={{margin: 0, color: 'var(--gcs-blue)', marginBottom: '1.5rem'}}>Lista de Empreendimentos</h3>
        {loading ? <LoadingSpinner text="Carregando..." /> : (
            <div style={{ border: '1px solid #dee2e6', borderRadius: '8px', overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
                    <thead style={{ backgroundColor: '#00314A', color: 'white' }}>
                        <tr>
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>ID</th>
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>Empreendimento</th>
                            {/* =====> 1. CABEÇALHO DA NOVA COLUNA <===== */}
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>Matrícula</th>
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>CPF / CNPJ</th>
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>Unidade</th>
                            <th style={{ padding: '12px 16px', textAlign: 'left' }}>Estado</th>
                            <th style={{ padding: '12px 16px', textAlign: 'center' }}>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        {empreendimentosFiltrados.length > 0 ? (
                            empreendimentosFiltrados.map((item, index) => (
                                <tr key={item.key} style={{ backgroundColor: index % 2 === 0 ? '#fff' : '#f8f9fa', borderTop: '1px solid #dee2e6' }}>
                                    <td style={{ padding: '12px 16px' }}>{item.id || 'N/A'}</td>
                                    <td style={{ padding: '12px 16px' }}>{item.nome || 'N/A'}</td>
                                    {/* =====> 2. DADO DA NOVA COLUNA <===== */}
                                    <td style={{ padding: '12px 16px' }}>{item.numero_matricula || 'N/A'}</td>
                                    <td style={{ padding: '12px 16px' }}>{item.cnpj_cpf || 'N/A'}</td>
                                    <td style={{ padding: '12px 16px' }}>{item.unidade || 'N/A'}</td>
                                    <td style={{ padding: '12px 16px' }}>{item.estado || 'N/A'}</td>
                                    <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                                        <Tooltip title="Gestão de Documentos">
                                            <Button 
                                                type="primary" 
                                                style={{backgroundColor: 'var(--gcs-blue)'}}
                                                icon={<FolderGit2 size={16} />} 
                                                onClick={() => handleOpenGestaoModal(item)}
                                            >
                                                Gestão
                                            </Button>
                                        </Tooltip>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                {/* =====> 3. AJUSTE DO COLSPAN <===== */}
                                <td colSpan={7} style={{ padding: '40px', textAlign: 'center', color: '#6c757d' }}>
                                    Nenhum dado para exibir.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        )}
      </div>
    </div>
    <ModalGestao visible={isGestaoModalOpen} onClose={handleCloseGestaoModal} empreendimento={selectedEmpreendimento}/>
  </>);
}