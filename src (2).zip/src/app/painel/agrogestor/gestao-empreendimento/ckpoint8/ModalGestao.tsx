"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { Tabs, Button, Card, Empty, Tag, Tooltip, Spin } from "antd";
import {
  X, FileText, Plus, Edit, Trash2, Landmark, Waves, Trees, FileStack,
  CalendarCheck, ShieldCheck, Building, Siren, Recycle, FileUp, Download, AlertTriangle, Map,
  ClipboardList, MapPin, Info, CheckCircle2
} from 'lucide-react';
import "antd/dist/reset.css";
import NotificationModal from "./NotificationModal";
import dynamic from 'next/dynamic';

const { TabPane } = Tabs;

const MapaKML = dynamic(() => import('./MapaKML'), {
  ssr: false,
  loading: () => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '400px' }}>
      <Spin size="large" />
      <span style={{ marginLeft: '1rem' }}>Carregando mapa...</span>
    </div>
  )
});

/* ========================================================================
    Tipos e Interfaces
    ======================================================================== */
export interface Empreendimento {
  id: number;
  nome: string;
  cnpj_cpf: string;
  numero_matricula?: string | null;
}

type DocumentoStatus = 'Vigente' | 'Vencido' | 'Não Aplicável';

interface Documento {
  id: number | string;
  tipo: string; 
  numero: string;
  orgaoEmissor?: string;
  dataEmissao: string;
  dataValidade?: string;
  status: DocumentoStatus;
  nomeArquivo?: string;
  id_arquivo?: number;
  relKey?: string;
  observacao?: string;
}

interface ModalGestaoProps {
  visible: boolean;
  onClose: () => void;
  empreendimento: Empreendimento | null;
}

// Funções auxiliares
const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), max);

const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return 'N/A';
    try {
        const date = new Date(dateString);
        return new Intl.DateTimeFormat('pt-BR', { timeZone: 'UTC' }).format(date);
    } catch (e) {
        return 'Data Inválida';
    }
};

const isEmptyDate = (d?: string | null) => {
  if (!d) return true;
  const s = String(d).trim().toUpperCase();
  return s === "N/A" || s === "NA" || s === "NULL" || s === "";
};

const getStatusStyleProps = (dataValidade: string | null | undefined): { 
    text: DocumentoStatus;
    icon: React.ReactNode;
    tagStyles: React.CSSProperties;
    cardStyles: React.CSSProperties;
} => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    if (!isEmptyDate(dataValidade)) {
        const validade = new Date(dataValidade as string);
        validade.setHours(0, 0, 0, 0);

        if (validade < hoje) {
            // Vencido
            return {
                text: 'Vencido',
                icon: <AlertTriangle size={14} style={{ marginRight: '4px' }} />,
                tagStyles: {
                    backgroundColor: '#E03131',
                    color: 'white',
                    fontWeight: 'bold',
                    padding: '4px 8px',
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    fontSize: '13px'
                },
                cardStyles: {
                    borderLeft: '4px solid #E03131'
                }
            };
        }
        // Vigente
        return {
            text: 'Vigente',
            icon: <CheckCircle2 size={14} style={{ marginRight: '4px' }} />,
            tagStyles: {
                backgroundColor: '#2F9E44',
                color: 'white',
                fontWeight: 'bold',
                padding: '4px 8px',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                fontSize: '13px'
            },
            cardStyles: {
                borderLeft: '4px solid #2F9E44'
            }
        };
    }
    
    // Não Aplicável
    return {
        text: 'Não Aplicável',
        icon: <Info size={14} style={{ marginRight: '4px' }} />,
        tagStyles: {
            backgroundColor: '#F1F3F5',
            color: '#495057',
            padding: '2px 6px',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'center',
        },
        cardStyles: {}
    };
};

/* ========================================================================
    Modal Genérico de Upload (Reutilizável)
    ======================================================================== */
const ModalUploadGenerico: React.FC<{
  title: string;
  tipoDocumento: string;
  modulo: string;
  allowedExtensions?: string[];
  extensionsLabel?: string;
  open: boolean;
  onClose: () => void;
  empreendimento: Empreendimento;
  onSuccess?: () => void;
}> = ({ title, tipoDocumento, modulo, allowedExtensions = [".pdf", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".zip"], extensionsLabel = "PDF/JPG/PNG/TIF/ZIP", open, onClose, empreendimento, onSuccess }) => {
  const [numero, setNumero] = useState<string>("");
  const [orgao, setOrgao] = useState<string>("");
  const [dataEmissao, setDataEmissao] = useState<string>("");
  const [dataValidade, setDataValidade] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [observacao, setObservacao] = useState<string>("");
  const [sending, setSending] = useState<boolean>(false);
  const [notifVisible, setNotifVisible] = useState<boolean>(false);
  const [notifType, setNotifType] = useState<"success" | "error">("success");
  const [notifMsg, setNotifMsg] = useState<string>("");
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (open && modalRef.current) {
      const { clientWidth, clientHeight } = modalRef.current;
      setPosition({ x: window.innerWidth / 2 - clientWidth / 2, y: window.innerHeight / 2 - clientHeight / 2 });
    }
  }, [open]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!modalRef.current || (e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    const modalRect = modalRef.current.getBoundingClientRect();
    dragOffsetRef.current = { x: e.clientX - modalRect.left, y: e.clientY - modalRect.top };
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || !modalRef.current) return;
    e.preventDefault();
    const modalRect = modalRef.current.getBoundingClientRect();
    const x = clamp(e.clientX - dragOffsetRef.current.x, 8, window.innerWidth - modalRect.width - 8);
    const y = clamp(e.clientY - dragOffsetRef.current.y, 8, window.innerHeight - modalRect.height - 8);
    setPosition({ x, y });
  };

  const handleMouseUp = () => { setIsDragging(false); };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [open, onClose]);
  
  useEffect(() => {
    if (!open) {
      setNumero(""); setOrgao(""); setDataEmissao(""); setDataValidade(""); setFile(null); setObservacao("");
      setSending(false); setNotifVisible(false);
    }
  }, [open]);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    if (!f) { setFile(null); return; }
    const okExt = allowedExtensions.some((ext) => f.name.toLowerCase().endsWith(ext));
    if (!okExt) {
      setNotifType("error"); setNotifMsg(`Extensão não permitida. Use ${extensionsLabel}.`); setNotifVisible(true); return;
    }
    if (f.size > 30 * 1024 * 1024) {
      setNotifType("error"); setNotifMsg("Arquivo acima de 30MB."); setNotifVisible(true); return;
    }
    setFile(f);
  };

  const submit = async () => {
    if (!file) { setNotifType("error"); setNotifMsg("Selecione um arquivo."); setNotifVisible(true); return; }
    if (!numero || !dataEmissao) { setNotifType("error"); setNotifMsg("Preencha Número do Documento e Data de Emissão."); setNotifVisible(true); return; }
    try {
      setSending(true);
      const url = `${process.env.NEXT_PUBLIC_BASE_PATH ?? ""}/api/agrogestor/uploads`;
      const fd = new FormData();
      fd.append("empreendimentoId", String(empreendimento.id));
      fd.append("modulo", modulo);
      fd.append("tipo", tipoDocumento);
      fd.append("numero_documento", numero);
      fd.append("orgao", orgao);
      fd.append("data_emissao", dataEmissao);
      fd.append("data_validade", dataValidade);
      fd.append("observacao", observacao);
      fd.append("file", file);
      
      const resp = await fetch(url, { method: "POST", body: fd });
      
      const rawResult = await resp.json().catch(() => ({ 
          status: 'error', 
          error: `Falha ao processar a resposta do servidor (${resp.status})` 
      }));

      const result = Array.isArray(rawResult) ? rawResult[0] : rawResult;

      if (!resp.ok || !result || result.status !== 'ok') {
        const errorMessage = result?.error || `Ocorreu um erro desconhecido (${resp.status})`;
        throw new Error(errorMessage);
      }
      
      setNotifType("success");
      setNotifMsg(result.message || `${title} enviado para processamento com sucesso!`);
    } catch (err: any) {
      setNotifType("error");
      setNotifMsg(err?.message || "Erro ao enviar.");
    } finally {
      setSending(false);
      setNotifVisible(true);
    }
  };

  const handleCloseNotification = () => {
    setNotifVisible(false);
    if (notifType === 'success') {
      onSuccess?.();
      onClose();
    }
  };

  if (!open) return null;

  return (
    <>
      <div style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.6)", zIndex: 2100 }} />
      <div 
        ref={modalRef}
        style={{ position: "fixed", top: `${position.y}px`, left: `${position.x}px`, width: "95%", maxWidth: 640, background: "#fff", borderRadius: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.2)", zIndex: 2101, overflow: "hidden", display: "flex", flexDirection: "column" }}
      >
        <div 
            onMouseDown={handleMouseDown}
            style={{ 
                padding: '1rem 1.5rem', 
                borderBottom: '1px solid #dee2e6', 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                backgroundColor: '#f1f5fb',
                cursor: isDragging ? 'grabbing' : 'grab'
            }}
        >
          <div>
            <h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Adicionar {title}</h3>
            <p style={{ margin: '4px 0 0 0', color: 'var(--gcs-gray-dark)', fontWeight: 'bold', fontSize: '14px' }}>
              Empreendimento: {empreendimento.nome}
              {empreendimento.numero_matricula && ` | Matrícula: ${empreendimento.numero_matricula}`}
            </p>
          </div>
          <button onClick={() => { if (!sending) onClose(); }} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }} title="Fechar" disabled={sending}><X size={24} color="var(--gcs-gray-dark)"/></button>
        </div>
        <div style={{ padding: "16px 18px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px 16px", opacity: sending ? 0.6 : 1, pointerEvents: sending ? "none" : "auto" }}>
          <div><label className="modal-label">Número do Documento *</label><input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="Número de identificação" style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Órgão Emissor</label><input value={orgao} onChange={(e) => setOrgao(e.target.value)} placeholder="Órgão responsável" style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Data de Emissão *</label><input type="date" value={dataEmissao} onChange={(e) => setDataEmissao(e.target.value)} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div><label className="modal-label">Data de Validade</label><input type="date" value={dataValidade} onChange={(e) => setDataValidade(e.target.value)} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)" }} /></div>
          <div style={{ gridColumn: "1 / span 2" }}><label className="modal-label">Arquivo ({extensionsLabel} até 30MB) *</label><input type="file" onChange={handleFile} accept={allowedExtensions.join(',')} />{file && (<div style={{ marginTop: 6, fontSize: 12, color: "#555" }}> {file.name} — {(file.size / 1024 / 1024).toFixed(2)} MB </div>)}</div>
          <div style={{ gridColumn: "1 / span 2" }}>
            <label className="modal-label">Observação</label>
            <textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} maxLength={250} placeholder="Observações sobre o documento..." rows={3} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid var(--gcs-border-color)", resize: "vertical" }} />
            <div style={{ textAlign: 'right', fontSize: '12px', color: '#888', marginTop: '4px' }}>{250 - observacao.length} caracteres restantes</div>
          </div>
        </div>
        <div style={{ padding: "14px 18px", borderTop: "1px solid var(--gcs-border-color)", display: "flex", justifyContent: "flex-end", gap: 8 }}><button className="btn btn-outline-gray" onClick={() => { if (!sending) onClose(); }} disabled={sending}>Fechar</button><button className="btn btn-green" onClick={submit} disabled={sending}>{sending ? "Enviando..." : "Salvar & Enviar"}</button></div>
        {sending && (<div style={{ position: "absolute", inset: 0, background: "rgba(255,255,255,0.7)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, zIndex: 2102 }}><Spin size="large" /><div style={{ color: "#333", fontWeight: 600 }}>Enviando arquivo…</div></div>)}
      </div>
      <NotificationModal visible={notifVisible} type={notifType} message={notifMsg} onClose={handleCloseNotification} />
    </>
  );
};


/* ========================================================================
    Modal de Edição de Documento
    ======================================================================== */
const ModalEditarDocumento: React.FC<{
    visible: boolean;
    onClose: () => void;
    documento: Documento | null;
    empreendimento: Empreendimento | null;
    modulo: string;
    onSuccess: () => void;
}> = ({ visible, onClose, documento, empreendimento, modulo, onSuccess }) => {
    const [numero, setNumero] = useState("");
    const [orgao, setOrgao] = useState("");
    const [dataEmissao, setDataEmissao] = useState("");
    const [dataValidade, setDataValidade] = useState("");
    const [observacao, setObservacao] = useState("");
    const [loading, setLoading] = useState(false);
    const [notification, setNotification] = useState({ visible: false, type: 'success' as 'success' | 'error', message: '' });
    
    const inputStyle: React.CSSProperties = {
        width: '100%', padding: '10px', borderRadius: '6px',
        border: '1px solid #dee2e6', fontSize: '1rem'
    };

    useEffect(() => {
        if (documento) {
            setNumero(documento.numero || "");
            setOrgao(documento.orgaoEmissor || "");
            setObservacao(documento.observacao || "");
            try { setDataEmissao(documento.dataEmissao ? new Date(documento.dataEmissao).toISOString().split('T')[0] : ""); } catch { setDataEmissao(""); }
            try { setDataValidade(documento.dataValidade ? new Date(documento.dataValidade).toISOString().split('T')[0] : ""); } catch { setDataValidade(""); }
        }
    }, [documento]);

    useEffect(() => {
        if (!visible) return;
        const handleKeyDown = (e: KeyboardEvent) => {
          if (e.key === 'Escape') {
            onClose();
          }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => {
          window.removeEventListener('keydown', handleKeyDown);
        };
    }, [visible, onClose]);

    if (!visible || !documento) return null;

    const handleAlterar = async () => {
        setLoading(true);
        try {
            const response = await fetch('/api/agrogestor/altera-documento', { 
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_certidao: documento.id,
                    modulo: modulo,
                    numero_documento: numero,
                    orgao: orgao,
                    data_emissao: dataEmissao,
                    data_validade: dataValidade,
                    observacao: observacao,
                }),
            });
            
            const rawResult = await response.json().catch(() => ({ status: 'error', error: 'Falha ao processar a resposta do servidor.' }));
            const result = Array.isArray(rawResult) ? rawResult[0] : rawResult;

            if (!response.ok || !result || result.status !== 'ok') {
                throw new Error(result?.error || 'Falha ao alterar o documento.');
            }

            setNotification({ visible: true, type: 'success', message: 'Documento alterado com sucesso!' });
        } catch (error: any) {
            setNotification({ visible: true, type: 'error', message: error.message });
        } finally {
            setLoading(false);
        }
    };
    
    const handleCloseNotification = () => {
        setNotification({ ...notification, visible: false });
        if (notification.type === 'success') {
            onSuccess();
            onClose(); 
        }
    }

    return (
        <>
            <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2200 }} />
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', zIndex: 2201, width: '90%', maxWidth: '640px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', overflow: 'hidden' }}>
                <div 
                    style={{ 
                        padding: '1rem 1.5rem', 
                        borderBottom: '1px solid #dee2e6', 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'center', 
                        backgroundColor: '#f1f5fb',
                        cursor: 'grab'
                    }}
                >
                  <div>
                    <h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Alterar Documento</h3>
                    {empreendimento &&
                        <p style={{ margin: '4px 0 0 0', color: 'var(--gcs-gray-dark)', fontWeight: 'bold', fontSize: '14px' }}>
                          Empreendimento: {empreendimento.nome}
                          {empreendimento.numero_matricula && ` | Matrícula: ${empreendimento.numero_matricula}`}
                        </p>
                    }
                  </div>
                  <button onClick={onClose} disabled={loading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}><X size={24} color="var(--gcs-gray-dark)"/></button>
                </div>
                <div style={{ padding: '1.5rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem 1.5rem' }}>
                    <div><label className="modal-label">Número do Documento</label><input value={numero} onChange={e => setNumero(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Órgão Emissor</label><input value={orgao} onChange={e => setOrgao(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Data de Emissão</label><input type="date" value={dataEmissao} onChange={e => setDataEmissao(e.target.value)} style={inputStyle} /></div>
                    <div><label className="modal-label">Data de Validade</label><input type="date" value={dataValidade} onChange={e => setDataValidade(e.target.value)} style={inputStyle} /></div>
                    <div style={{ gridColumn: '1 / span 2' }}>
                        <label className="modal-label">Observação</label>
                        <textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} maxLength={250} rows={3} style={{ ...inputStyle, resize: 'vertical' }} />
                        <div style={{ textAlign: 'right', fontSize: '12px', color: '#888', marginTop: '4px' }}>{250 - observacao.length} caracteres restantes</div>
                    </div>
                </div>
                <div style={{ padding: "14px 18px", borderTop: "1px solid var(--gcs-border-color)", display: "flex", justifyContent: "flex-end", gap: '0.5rem' }}>
                    <Button onClick={onClose} disabled={loading}>Cancelar</Button>
                    <Button onClick={handleAlterar} loading={loading} className="btn-action-edit">Alterar</Button>
                </div>
            </div>
            <NotificationModal visible={notification.visible} type={notification.type} message={notification.message} onClose={handleCloseNotification} />
        </>
    );
};


/* ========================================================================
    Modal de Confirmação de Exclusão
    ======================================================================== */
const ModalConfirmarExclusao: React.FC<{
    visible: boolean;
    onClose: () => void;
    onConfirm: () => void;
    loading: boolean;
}> = ({ visible, onClose, onConfirm, loading }) => {
    useEffect(() => {
        if (!visible) return;
        const handleKeyDown = (e: KeyboardEvent) => {
          if (e.key === 'Escape') {
            onClose();
          }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => {
          window.removeEventListener('keydown', handleKeyDown);
        };
    }, [visible, onClose]);

    if (!visible) return null;
    return (
        <>
            <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2300 }} />
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 2301, width: '90%', maxWidth: '450px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', padding: '2rem', textAlign: 'center' }}>
                <AlertTriangle size={48} color="var(--gcs-orange)" style={{ marginBottom: '1rem' }} />
                <h3 style={{ margin: '0 0 0.5rem 0', color: 'var(--gcs-blue)' }}>Confirmar Exclusão</h3>
                <p style={{ color: 'var(--gcs-gray-dark)', marginBottom: '2rem' }}>Tem certeza que deseja excluir este documento? Esta ação não pode ser desfeita.</p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                    <Button onClick={onClose} disabled={loading}>Cancelar</Button>
                    <Button type="primary" danger onClick={onConfirm} loading={loading}>Excluir</Button>
                </div>
            </div>
        </>
    );
};

/* ========================================================================
    Componente reutilizável DocumentSection
    ======================================================================== */
const DocumentSection: React.FC<{
  title: string;
  icon: React.ReactNode;
  documents: Documento[];
  loading: boolean;
  onAdd: () => void;
  onEdit: (doc: Documento) => void;
  onDelete: (doc: Documento) => void;
  onDownload: (doc: Documento) => void;
  onViewMap?: (doc: Documento) => void;
  headBg?: string;
  downloadingDocId?: number | string | null;
}> = React.memo(({
  title, icon, documents, loading, onAdd, onEdit, onDelete, onDownload, onViewMap,
  headBg, downloadingDocId
}) => {
    return (
        <Card
          title={<div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}><>{icon}</><span style={{ color: 'var(--gcs-blue)', fontWeight: 700, fontSize: '1.1rem' }}>{title}</span></div>}
          style={{ marginBottom: '1.5rem' }}
          headStyle={{ background: headBg ?? undefined, borderTopLeftRadius: 8, borderTopRightRadius: 8 }}
          extra={<Button icon={<Plus size={16} />} onClick={onAdd} className="btn-outline-gcs-blue">Adicionar</Button>}
        >
          {loading ? (<div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100px'}}><Spin /></div>) 
          : (!documents || documents.length === 0) ? (<Empty 
                description={
                    <span style={{ color: 'var(--gcs-gray-dark)', fontStyle: 'italic' }}>
                        {`Nenhum documento do tipo "${title}" cadastrado.`}
                    </span>
                }
                image={Empty.PRESENTED_IMAGE_SIMPLE} 
            />) 
          : (<div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {documents.map((doc) => {
                  const { text, icon, tagStyles, cardStyles } = getStatusStyleProps(doc.dataValidade);
                  return (
                  <Card key={doc.id} bordered size="small" style={cardStyles}>
                      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flex: 1 }}>
                              <FileText size={32} color="var(--gcs-blue)" style={{ marginTop: '5px' }} />
                              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, auto)', gap: '8px 24px', flex: 1, whiteSpace: 'nowrap' }}>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>N° Documento:</strong> {doc.numero || '-'}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Órgão Emissor:</strong> {doc.orgaoEmissor || '-'}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Data Emissão:</strong> {formatDate(doc.dataEmissao)}</p>
                                  <p style={{ margin: 0 }}><strong style={{color: 'var(--gcs-gray-dark)'}}>Data Validade:</strong> {formatDate(doc.dataValidade)}</p>
                                  {doc.observacao && (
                                      <p style={{ margin: 0, gridColumn: '1 / span 2', marginTop: '8px', paddingTop: '8px', borderTop: '1px dotted #ccc', whiteSpace: 'normal' }}>
                                          <strong>Observação:</strong> {doc.observacao}
                                      </p>
                                  )}
                              </div>
                          </div>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px', flexShrink: 0 }}>
                              <div style={tagStyles}>
                                  {icon}
                                  <span>{text}</span>
                              </div>
                              <div style={{display: 'flex', gap: '8px'}}>
                                  {(doc.nomeArquivo?.toLowerCase().endsWith('.kml') || doc.nomeArquivo?.toLowerCase().endsWith('.kmz')) && onViewMap &&
                                    <Tooltip title="Visualizar no Mapa">
                                        <Button 
                                            icon={<Map size={16} />} 
                                            onClick={() => onViewMap(doc)}
                                            className="btn-action-map"
                                        />
                                    </Tooltip>
                                  }
                                  <Tooltip title={doc.nomeArquivo || "Baixar Arquivo"}>
                                    <Button 
                                        icon={<Download size={16} />} 
                                        onClick={() => onDownload(doc)} 
                                        loading={downloadingDocId === doc.id}
                                        className="btn-action-download"
                                    />
                                  </Tooltip>
                                  <Tooltip title="Editar Documento">
                                    <Button 
                                        icon={<Edit size={16} />} 
                                        onClick={() => onEdit(doc)} 
                                        className="btn-action-edit"
                                    />
                                  </Tooltip>
                                  <Tooltip title="Excluir Documento">
                                    <Button 
                                        icon={<Trash2 size={16} />} 
                                        onClick={() => onDelete(doc)} 
                                        className="btn-action-delete"
                                    />
                                  </Tooltip>
                              </div>
                          </div>
                      </div>
                  </Card>
              )})}
            </div>
          )}
        </Card>
    );
});
DocumentSection.displayName = 'DocumentSection';


/* ========================================================================
    Modal principal: Gestão de Documentos
    ======================================================================== */
const ModalGestao: React.FC<ModalGestaoProps> = ({ visible, onClose, empreendimento }) => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [openModals, setOpenModals] = useState<Record<string, boolean>>({});
  const [isMapaModalVisible, setIsMapaModalVisible] = useState(false);
  const [selectedKmlUrl, setSelectedKmlUrl] = useState<string | null>(null);
  const currentKmlUrlRef = useRef<string | null>(null);
  const [documentos, setDocumentos] = useState<Record<string, Documento[]>>({});
  const [loading, setLoading] = useState(true);
  const [downloadingDocId, setDownloadingDocId] = useState<number | string | null>(null);

  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [documentoParaEditar, setDocumentoParaEditar] = useState<Documento | null>(null);
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [documentoParaExcluir, setDocumentoParaExcluir] = useState<Documento | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [notification, setNotification] = useState({ visible: false, type: 'success' as 'success' | 'error', message: '' });
  
  const [moduloSelecionado, setModuloSelecionado] = useState<string>("");

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (visible && modalRef.current) {
      const { clientWidth, clientHeight } = modalRef.current;
      setPosition({ x: window.innerWidth / 2 - clientWidth / 2, y: window.innerHeight / 2 - clientHeight / 2 });
    }
  }, [visible]);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!modalRef.current || (e.target as HTMLElement).closest('button, .ant-tabs-tab')) return;
    setIsDragging(true);
    const modalRect = modalRef.current.getBoundingClientRect();
    dragOffsetRef.current = { x: e.clientX - modalRect.left, y: e.clientY - modalRect.top };
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging || !modalRef.current) return;
    e.preventDefault();
    const modalRect = modalRef.current.getBoundingClientRect();
    const x = clamp(e.clientX - dragOffsetRef.current.x, 8, window.innerWidth - modalRect.width - 8);
    const y = clamp(e.clientY - dragOffsetRef.current.y, 8, window.innerHeight - modalRect.height - 8);
    setPosition({ x, y });
  }, [isDragging]);

  const handleMouseUp = useCallback(() => { setIsDragging(false); }, []);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, handleMouseMove, handleMouseUp]);

  useEffect(() => {
    if (!visible) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [visible, onClose]);
  
  const handleOpenModal = useCallback((modalName: string) => setOpenModals(prev => ({ ...prev, [modalName]: true })), []);
  const handleCloseModal = useCallback((modalName: string) => setOpenModals(prev => ({ ...prev, [modalName]: false })), []);
  
  const handleSuccessUpload = useCallback(() => {
    setRefreshTrigger(t => t + 1);
  }, []);
  
  useEffect(() => {
    if (visible && empreendimento) {
      const fetchAllDocuments = async () => {
        setLoading(true);
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout
        
        try {
          const response = await fetch("/api/agrogestor/consulta-certidao", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ empreendimento_id: empreendimento.id }),
            signal: controller.signal
          });

          clearTimeout(timeoutId);

          if (response.status === 204) {
            setDocumentos({});
            return;
          }
          if (!response.ok) throw new Error(`Falha na API: ${response.statusText}`);
          
          const data: any[] = await response.json();
          
          const formattedData = data.map((doc: any) => ({ 
              id: doc.id_certidao,
              tipo: doc.tipo,
              numero: doc.numero_documento, 
              orgaoEmissor: doc.orgao, 
              dataEmissao: doc.data_emissao, 
              dataValidade: doc.data_validade, 
              nomeArquivo: doc.nome_arquivo,
              relKey: doc.relKey,
              observacao: doc.observacao || doc.observacoes
          }));

          const groupedDocs = formattedData.reduce((acc, doc) => {
            const { tipo } = doc;
            if (!acc[tipo]) {
              acc[tipo] = [];
            }
            acc[tipo].push(doc);
            return acc;
          }, {} as Record<string, Documento[]>);

          setDocumentos(groupedDocs);

        } catch (error: any) {
          if (error.name === 'AbortError') {
            console.error('Busca de documentos excedeu o tempo limite.');
          } else {
            console.error(`Erro ao carregar documentos:`, error);
          }
          setDocumentos({});
        } finally {
          setLoading(false);
        }
      };

      fetchAllDocuments();
    }
  }, [visible, empreendimento, refreshTrigger]);
  
  const handleOpenMapaModal = useCallback(async (doc: Documento) => {
    if (!doc.relKey || !doc.nomeArquivo) return;
    setIsMapaModalVisible(true); 
    try {
        const response = await fetch('/api/agrogestor/download-arquivo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ relKey: doc.relKey, nome_arquivo: doc.nomeArquivo }),
        });
        if (!response.ok) throw new Error('Não foi possível carregar o arquivo KML.');
        const blob = await response.blob();
        if (currentKmlUrlRef.current) URL.revokeObjectURL(currentKmlUrlRef.current);
        const url = URL.createObjectURL(blob);
        currentKmlUrlRef.current = url; 
        setSelectedKmlUrl(url);
    } catch (error: any) {
        setIsMapaModalVisible(false); 
    }
  }, []);

  const handleCloseMapaModal = useCallback(() => {
    setIsMapaModalVisible(false);
    setSelectedKmlUrl(null);
    if (currentKmlUrlRef.current) {
        URL.revokeObjectURL(currentKmlUrlRef.current);
        currentKmlUrlRef.current = null;
    }
  }, []);

  const handleDownload = useCallback(async (doc: Documento) => {
    if (!doc.relKey || !doc.nomeArquivo) return;
    setDownloadingDocId(doc.id);
    try {
        const response = await fetch('/api/agrogestor/download-arquivo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ relKey: doc.relKey, nome_arquivo: doc.nomeArquivo }),
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: 'Não foi possível baixar o arquivo.' }));
            throw new Error(errorData.message || 'Não foi possível baixar o arquivo.');
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = doc.nomeArquivo;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    } catch (error: any) {
        setNotification({ visible: true, type: 'error', message: error.message });
    } finally {
        setDownloadingDocId(null);
    }
  }, []);

  const handleAbrirModalEdicao = useCallback((doc: Documento, modulo: string) => {
      setDocumentoParaEditar(doc);
      setModuloSelecionado(modulo);
      setIsEditModalVisible(true);
  }, []);

  const handleAbrirModalExclusao = useCallback((doc: Documento, modulo: string) => {
    setDocumentoParaExcluir(doc);
    setModuloSelecionado(modulo);
    setIsDeleteModalVisible(true);
  }, []);

  const handleConfirmarExclusao = useCallback(async () => {
    if (!documentoParaExcluir) return;
    setIsDeleting(true);
    try {
        const response = await fetch('/api/agrogestor/inativa-documento', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              id_certidao: documentoParaExcluir.id,
              modulo: moduloSelecionado
            }),
        });
        
        const rawResult = await response.json().catch(() => ({ status: 'error', error: 'Falha ao processar a resposta do servidor.' }));
        const result = Array.isArray(rawResult) ? rawResult[0] : rawResult;

        if (!response.ok || !result || result.status !== 'ok') {
            throw new Error(result?.error || 'Falha ao excluir o documento.');
        }

        setNotification({ visible: true, type: 'success', message: 'Documento excluído com sucesso!' });
        setRefreshTrigger(t => t + 1);
    } catch (error: any) {
        setNotification({ visible: true, type: 'error', message: error.message });
    } finally {
        setIsDeleting(false);
        setIsDeleteModalVisible(false);
    }
  }, [documentoParaExcluir, moduloSelecionado]);
  
  if (!visible || !empreendimento) return null;

  const HEAD_HIGHLIGHT = "rgba(0, 102, 204, 0.10)";

  return (
    <>
      <div style={{ position: 'fixed', top:0, left:0, width:'100vw', height:'100vh', backgroundColor:'rgba(0,0,0,0.6)', zIndex: 1000 }} />
      <div 
        ref={modalRef}
        style={{ 
            position: 'fixed', 
            top: `${position.y}px`, 
            left: `${position.x}px`, 
            backgroundColor: 'white', 
            borderRadius: '12px', 
            zIndex: 1001, 
            width: '95%', 
            maxWidth: '1200px', 
            height: '90vh', 
            display: 'flex', 
            flexDirection: 'column' 
        }}>
        <div 
            onMouseDown={handleMouseDown}
            style={{ 
                padding: '1rem 1.5rem', 
                borderBottom: '1px solid #dee2e6', 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                backgroundColor: '#f1f5fb',
                cursor: isDragging ? 'grabbing' : 'grab'
            }}
        >
          <div>
            <h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Gestão de Documentos</h3>
            <p style={{ margin: 0, color: 'var(--gcs-gray-dark)', fontWeight: 'bold' }}>
              Empreendimento: {empreendimento.nome}
              {empreendimento.numero_matricula && ` | Matrícula: ${empreendimento.numero_matricula}`}
            </p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}><X size={24} color="var(--gcs-gray-dark)"/></button>
        </div>
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <Tabs defaultActiveKey="1" tabPosition="left" style={{ height: '100%' }} animated={{ inkBar: true, tabPane: true }}>
            <TabPane tab={<span style={{ display:'flex', alignItems:'center', gap:8 }}><Landmark size={18}/> Fundiário</span>} key="1">
              <div style={{ padding:'1rem 1.5rem', overflowY:'auto', height:'calc(90vh - 140px)' }}>
                <DocumentSection title="Certidão de Inteiro Teor da Matrícula" icon={<FileText size={20}/>} documents={documentos['certidao_inteiro_teor'] || []} loading={loading} onAdd={() => handleOpenModal('certidao')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
                <DocumentSection title="Certidão de ITR" icon={<Recycle size={20}/>} documents={documentos['itr'] || []} loading={loading} onAdd={() => handleOpenModal('itr')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
                <DocumentSection title="CCIR" icon={<FileStack size={20}/>} documents={documentos['ccir'] || []} loading={loading} onAdd={() => handleOpenModal('ccir')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
                <DocumentSection title="GEO" icon={<Trees size={20}/>} documents={documentos['geo'] || []} loading={loading} onAdd={() => handleOpenModal('geo')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
                <DocumentSection title="KML" icon={<FileUp size={20}/>} documents={documentos['kml'] || []} loading={loading} onAdd={() => handleOpenModal('kml')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} onViewMap={handleOpenMapaModal} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
                <DocumentSection title="CIB" icon={<FileStack size={20}/>} documents={documentos['cib'] || []} loading={loading} onAdd={() => handleOpenModal('cib')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} downloadingDocId={downloadingDocId} headBg={HEAD_HIGHLIGHT} />
              </div>
            </TabPane>
            <TabPane tab={<span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Trees size={18} /> Ambiental</span>} key="2">
              <div style={{ padding: '1rem 1.5rem', overflowY: 'auto', height: 'calc(90vh - 140px)' }}>
                <DocumentSection title="ASV (Autorização de Supressão Vegetal)" icon={<Trees size={20} />} documents={documentos['asv'] || []} loading={loading} onAdd={() => handleOpenModal('asv')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
                <DocumentSection title="Licença Ambiental (Licença estadual, municipal e federal)" icon={<ShieldCheck size={20} />} documents={documentos['licenca'] || []} loading={loading} onAdd={() => handleOpenModal('licenca')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
                <DocumentSection title="Outorga" icon={<Waves size={20} />} documents={documentos['outorga'] || []} loading={loading} onAdd={() => handleOpenModal('outorga')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
                <DocumentSection title="APPO (Autorização para Perfuração de Poço)" icon={<Waves size={20} />} documents={documentos['appo'] || []} loading={loading} onAdd={() => handleOpenModal('appo')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
                <DocumentSection title="CAR (Cadastro Ambiental Rural)" icon={<FileText size={20} />} documents={documentos['car'] || []} loading={loading} onAdd={() => handleOpenModal('car')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
                <DocumentSection title="CEFIR (Cadastro Estadual Florestal de Imóveis Rurais)" icon={<FileText size={20} />} documents={documentos['cefir'] || []} loading={loading} onAdd={() => handleOpenModal('cefir')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT}/>
              </div>
            </TabPane>
            <TabPane tab={<span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Building size={18} /> Cadastral / Obrigações</span>} key="3">
                <div style={{ padding:'1rem 1.5rem', overflowY:'auto', height:'calc(90vh - 140px)' }}>
                    <DocumentSection title="ADA" icon={<FileText size={20} />} documents={documentos['ada'] || []} loading={loading} onAdd={() => handleOpenModal('ada')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="ITR (Cadastral)" icon={<Recycle size={20} />} documents={documentos['itr_cadastral'] || []} loading={loading} onAdd={() => handleOpenModal('itr_cadastral')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="Relatórios" icon={<FileStack size={20} />} documents={documentos['relatorio'] || []} loading={loading} onAdd={() => handleOpenModal('relatorio')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="Alvarás" icon={<CalendarCheck size={20} />} documents={documentos['alvara'] || []} loading={loading} onAdd={() => handleOpenModal('alvara')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="Inventário de Resíduos" icon={<Trash2 size={20} />} documents={documentos['inventario_residuos'] || []} loading={loading} onAdd={() => handleOpenModal('inventario_residuos')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="Certificado Bombeiros" icon={<Siren size={20} />} documents={documentos['certificado_bombeiros'] || []} loading={loading} onAdd={() => handleOpenModal('certificado_bombeiros')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="CTF – Ibama" icon={<ShieldCheck size={20} />} documents={documentos['ctf_ibama'] || []} loading={loading} onAdd={() => handleOpenModal('ctf_ibama')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="RAPP – Ibama" icon={<ClipboardList size={20} />} documents={documentos['rapp_ibama'] || []} loading={loading} onAdd={() => handleOpenModal('rapp_ibama')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                    <DocumentSection title="Certificado de Uso de Solo" icon={<MapPin size={20} />} documents={documentos['certificado_uso_solo'] || []} loading={loading} onAdd={() => handleOpenModal('certificado_uso_solo')} onEdit={handleAbrirModalEdicao} onDelete={handleAbrirModalExclusao} onDownload={handleDownload} headBg={HEAD_HIGHLIGHT} />
                </div>
            </TabPane>
          </Tabs>
        </div>
        <div style={{ padding:'1rem 1.5rem', borderTop:'1px solid #dee2e6', display:'flex', justifyContent:'flex-end' }}>
          <Button onClick={onClose} size="large" className="btn-gcs-blue">Fechar</Button>
        </div>
      </div>
      
      {/* Modais de Upload - Fundiário */}
      <ModalUploadGenerico title="Certidão de Inteiro Teor" tipoDocumento="certidao_inteiro_teor" modulo="fundiario" open={openModals['certidao']} onClose={() => handleCloseModal('certidao')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="CCIR" tipoDocumento="ccir" modulo="fundiario" open={openModals['ccir']} onClose={() => handleCloseModal('ccir')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Certidão de ITR" tipoDocumento="itr" modulo="fundiario" open={openModals['itr']} onClose={() => handleCloseModal('itr')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="GEO" tipoDocumento="geo" modulo="fundiario" open={openModals['geo']} onClose={() => handleCloseModal('geo')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="KML" tipoDocumento="kml" modulo="fundiario" open={openModals['kml']} onClose={() => handleCloseModal('kml')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} allowedExtensions={[".kml", ".kmz"]} extensionsLabel="KML / KMZ" />
      <ModalUploadGenerico title="CIB" tipoDocumento="cib" modulo="fundiario" open={openModals['cib']} onClose={() => handleCloseModal('cib')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />

      {/* Modais de Upload - Ambiental */}
      <ModalUploadGenerico title="ASV" tipoDocumento="asv" modulo="ambiental" open={openModals['asv']} onClose={() => handleCloseModal('asv')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Licenciamento Ambiental" tipoDocumento="licenca" modulo="ambiental" open={openModals['licenca']} onClose={() => handleCloseModal('licenca')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Outorga" tipoDocumento="outorga" modulo="ambiental" open={openModals['outorga']} onClose={() => handleCloseModal('outorga')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="APPO" tipoDocumento="appo" modulo="ambiental" open={openModals['appo']} onClose={() => handleCloseModal('appo')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="CAR" tipoDocumento="car" modulo="ambiental" open={openModals['car']} onClose={() => handleCloseModal('car')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="CEFIR" tipoDocumento="cefir" modulo="ambiental" open={openModals['cefir']} onClose={() => handleCloseModal('cefir')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      
      {/* Modais de Upload - Cadastral/Obrigacoes */}
      <ModalUploadGenerico title="ADA" tipoDocumento="ada" modulo="cadastral_obrigacoes" open={openModals['ada']} onClose={() => handleCloseModal('ada')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="ITR (Cadastral)" tipoDocumento="itr_cadastral" modulo="cadastral_obrigacoes" open={openModals['itr_cadastral']} onClose={() => handleCloseModal('itr_cadastral')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Relatórios" tipoDocumento="relatorio" modulo="cadastral_obrigacoes" open={openModals['relatorio']} onClose={() => handleCloseModal('relatorio')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Alvará" tipoDocumento="alvara" modulo="cadastral_obrigacoes" open={openModals['alvara']} onClose={() => handleCloseModal('alvara')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Inventário de Resíduos" tipoDocumento="inventario_residuos" modulo="cadastral_obrigacoes" open={openModals['inventario_residuos']} onClose={() => handleCloseModal('inventario_residuos')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Certificado Bombeiros" tipoDocumento="certificado_bombeiros" modulo="cadastral_obrigacoes" open={openModals['certificado_bombeiros']} onClose={() => handleCloseModal('certificado_bombeiros')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="CTF – Ibama" tipoDocumento="ctf_ibama" modulo="cadastral_obrigacoes" open={openModals['ctf_ibama']} onClose={() => handleCloseModal('ctf_ibama')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="RAPP – Ibama" tipoDocumento="rapp_ibama" modulo="cadastral_obrigacoes" open={openModals['rapp_ibama']} onClose={() => handleCloseModal('rapp_ibama')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />
      <ModalUploadGenerico title="Certificado de Uso de Solo" tipoDocumento="certificado_uso_solo" modulo="cadastral_obrigacoes" open={openModals['certificado_uso_solo']} onClose={() => handleCloseModal('certificado_uso_solo')} empreendimento={empreendimento} onSuccess={handleSuccessUpload} />

      {/* Modais de Ação */}
      <ModalEditarDocumento visible={isEditModalVisible} onClose={() => setIsEditModalVisible(false)} documento={documentoParaEditar} empreendimento={empreendimento} modulo={moduloSelecionado} onSuccess={() => { setIsEditModalVisible(false); setRefreshTrigger(t => t + 1); }} />
      <ModalConfirmarExclusao visible={isDeleteModalVisible} onClose={() => setIsDeleteModalVisible(false)} onConfirm={handleConfirmarExclusao} loading={isDeleting} />
      <NotificationModal visible={notification.visible} type={notification.type} message={notification.message} onClose={() => setNotification({ ...notification, visible: false })} />

      {/* Modal do Mapa */}
      {isMapaModalVisible && selectedKmlUrl && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2400 }} onClick={handleCloseMapaModal} />
          <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 2401, width: '90%', maxWidth: '800px', backgroundColor: 'white', borderRadius: '12px', display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid #dee2e6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, color: 'var(--gcs-blue)' }}><Map size={20}/> Visualizador de Limites</h3>
                <button onClick={handleCloseMapaModal} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={24}/></button>
            </div>
            <div style={{ padding: '1.5rem' }}>
                <MapaKML urlKML={selectedKmlUrl} />
            </div>
             <div style={{ padding: '1rem 1.5rem', borderTop: '1px solid #dee2e6', display: 'flex', justifyContent: 'flex-end' }}>
                <Button onClick={handleCloseMapaModal}>Fechar</Button>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default ModalGestao;