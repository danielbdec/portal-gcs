"use client";

import React, { useEffect, useState, useCallback, useRef } from "react";
import { FaSearch, FaSpinner, FaPencilAlt } from "react-icons/fa";
import { Sparkles } from "lucide-react";

// --- INTERFACES ESPECÍFICAS PARA ESTE MODAL ---

// Interface para os dados do item que vêm do componente pai (ModalDetalhes)
interface ItemNota {
    item_xml: number;
    descricao_xml: string;
    valor_unitario_xml?: number;
    descricao_pedido: string | null;
    num_pedido: string | null;
}

// Interface para o retorno da API de busca de pedido
interface PedidoEncontrado {
    Pedido: string;
    Produto: string;
    UM: string;
    "Seg. UM": string;
    Saldo: number;
    Valor: number;
    Registro: number; // R_E_C_N_O_
}

// Interface para gerenciar o estado de cada linha na tabela deste modal
interface ItemPedidoManual {
    item_xml: number;
    descricao_xml: string;
    valor_unitario_xml: number | null;
    num_pedido: string | null;
    descricao_pedido_api: string | null;
    valor_pedido_api: number | null;
    registro_pedido: number | null; // R_E_C_N_O_ oculto
}

// --- SUB-COMPONENTE: MODAL DE BUSCA DE PEDIDO ---

const PedidoSearchModal = ({ isOpen, onClose, onSelect, searchResults, isLoading, error, activeItemInfo }: {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (pedido: PedidoEncontrado) => void;
    searchResults: PedidoEncontrado[];
    isLoading: boolean;
    error: string | null;
    activeItemInfo: { item: string; descricao: string; } | null;
}) => {
    const modalRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);

    const handleMouseDown = (e: React.MouseEvent) => {
        if (modalRef.current) {
            const target = e.target as HTMLElement;
            if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'BUTTON' || target.tagName === 'SELECT') {
                return;
            }
            setIsDragging(true);
            const modalRect = modalRef.current.getBoundingClientRect();
            setOffset({
                x: e.clientX - modalRect.left,
                y: e.clientY - modalRect.top
            });
            e.preventDefault();
        }
    };

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!isDragging) return;
        const newX = e.clientX - offset.x;
        const newY = e.clientY - offset.y;
        setPosition({ x: newX, y: newY });
    }, [isDragging, offset]);

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
    }, []);

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, handleMouseMove, handleMouseUp]);

    useEffect(() => {
        if (isOpen && modalRef.current) {
            const modal = modalRef.current;
            const initialX = (window.innerWidth - modal.offsetWidth) / 1.6;
            const initialY = 100;
            setPosition({ x: initialX > 0 ? initialX : 20, y: initialY });
        }
    }, [isOpen]);

    if (!isOpen) return null;

    let title = "Selecionar Pedido de Compra";
    if (activeItemInfo) {
        const truncatedDesc = activeItemInfo.descricao.length > 30
            ? `${activeItemInfo.descricao.substring(0, 30)}...`
            : activeItemInfo.descricao;
        title = `Selecionar Pedido - Item ${activeItemInfo.item}: ${truncatedDesc}`;
    }

    return (
        <>
            <div onClick={onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2147483650 }}></div>
            <div
                ref={modalRef}
                style={{
                    position: 'fixed',
                    top: position.y,
                    left: position.x,
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    zIndex: 2147483651,
                    width: '90%',
                    maxWidth: '700px',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
                }}
            >
                <div
                    onMouseDown={handleMouseDown}
                    style={{
                        padding: '1.5rem',
                        borderBottom: '1px solid #dee2e6',
                        cursor: 'move',
                        backgroundColor: '#f1f5fb',
                        borderTopLeftRadius: '8px',
                        borderTopRightRadius: '8px'
                    }}
                >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h4 style={{ margin: 0, fontSize: '1.1rem' }}>{title}</h4>
                        <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>&times;</button>
                    </div>
                </div>
                <div style={{ padding: '1.5rem' }}>
                    {error && <div style={{ color: '#dc3545', marginBottom: '1rem', padding: '1rem', background: '#f8d7da', borderRadius: '5px' }}>{error}</div>}
                    <div style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #eee', borderRadius: '5px' }}>
                        {isLoading ? (
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '3rem' }}>
                                <FaSpinner className="animate-spin" size={24} color="#1b4c89" />
                            </div>
                        ) : searchResults.length > 0 ? (
                            searchResults.map((p) => (
                                <div
                                    key={p.Registro}
                                    onClick={() => onSelect(p)}
                                    style={{ padding: '12px', cursor: 'pointer', borderBottom: '1px solid #eee', backgroundColor: '#fff', transition: 'background-color 0.2s' }}
                                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f0f8ff'}
                                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#fff'}
                                >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <div>
                                            <strong style={{ color: '#1b4c89' }}>Pedido:</strong> {p.Pedido}
                                        </div>
                                        <div style={{ fontSize: '0.9em' }}>
                                            <strong>Saldo:</strong> {p.Saldo} {p.UM.trim()}
                                        </div>
                                    </div>
                                    <div style={{ fontSize: '0.9em', color: '#6c757d', marginTop: '4px' }}>{p.Produto}</div>
                                    <div style={{ fontSize: '0.8em', color: '#888', textAlign: 'right' }}>
                                        <strong>Valor:</strong> {p.Valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                    </div>
                                </div>
                            ))
                        ) : (
                            !error && <div style={{ padding: '20px', textAlign: 'center', color: '#6c757d' }}>Não existem pedidos disponíveis para este item.</div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};


// --- COMPONENTE PRINCIPAL: MODAL DE PEDIDOS ---

const ManualPedidoModal = ({
    isOpen,
    onClose,
    onSave,
    items,
    chave
}: {
    isOpen: boolean,
    onClose: () => void,
    onSave: (updates: ItemPedidoManual[]) => Promise<void>,
    items: ItemNota[],
    chave: string
}) => {
    // Novo estado para gerenciar todos os dados dos itens
    const [itensManuais, setItensManuais] = useState<ItemPedidoManual[]>([]);
    const [isSaving, setIsSaving] = useState(false);
    const [isAILoading, setIsAILoading] = useState(false);
    
    // Estados para o modal de busca de pedido
    const [isPedidoSearchModalOpen, setIsPedidoSearchModalOpen] = useState(false);
    const [isPedidoSearchLoading, setIsPedidoSearchLoading] = useState(false);
    const [pedidoSearchError, setPedidoSearchError] = useState<string | null>(null);
    const [pedidoSearchResults, setPedidoSearchResults] = useState<PedidoEncontrado[]>([]);
    const [activeSearchItem, setActiveSearchItem] = useState<ItemPedidoManual | null>(null);

    // Referências e estados para arrastar o modal
    const modalRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);

    // Inicializa o estado do modal quando ele é aberto ou os itens mudam
    useEffect(() => {
        if (isOpen) {
            const initialItensManuais = items.map(item => ({
                item_xml: item.item_xml,
                descricao_xml: item.descricao_xml,
                valor_unitario_xml: item.valor_unitario_xml ?? null,
                num_pedido: item.num_pedido,
                descricao_pedido_api: item.descricao_pedido, // Pré-popula com o que a IA já encontrou
                valor_pedido_api: null, // Será preenchido pela busca
                registro_pedido: null, // R_E_C_N_O_ será preenchido pela busca
            }));
            setItensManuais(initialItensManuais);
        }
    }, [isOpen, items]);

    const handleSave = async () => {
        setIsSaving(true);
        // Envia o estado completo para a função onSave
        await onSave(itensManuais);
        setIsSaving(false);
    };
    
    // Atualiza o número do pedido quando o usuário digita
    const handleUpdatePedido = (itemXml: number, value: string) => {
        setItensManuais(prevItens => 
            prevItens.map(item => {
                if (item.item_xml === itemXml) {
                    return { 
                        ...item, 
                        num_pedido: value,
                        // Limpa os dados da API pois a entrada foi manual
                        descricao_pedido_api: null,
                        valor_pedido_api: null,
                        registro_pedido: null,
                    };
                }
                return item;
            })
        );
    };

    const handleAIAssist = async () => {
        setIsAILoading(true);
        console.log("Chamando assistente de IA para preencher pedidos...");
        await new Promise(resolve => setTimeout(resolve, 1500));
        alert('Assistente de IA: Funcionalidade a ser implementada.');
        setIsAILoading(false);
    };

    // Abre o modal de busca e busca os pedidos para o item selecionado
    const handleSearchPedido = async (item: ItemPedidoManual) => {
        setActiveSearchItem(item);
        setIsPedidoSearchModalOpen(true);
        setIsPedidoSearchLoading(true);
        setPedidoSearchError(null);
        setPedidoSearchResults([]);

        try {
            const response = await fetch('/api/nfe/nfe-busca-pedido-manual-item', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    chave: chave,
                    item_xml: item.item_xml 
                }),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Erro ao buscar pedidos.');
            }
            
            setPedidoSearchResults(Array.isArray(data) ? data : []);

        } catch (err: any) {
            setPedidoSearchError(err.message);
        } finally {
            setIsPedidoSearchLoading(false);
        }
    };

    // Atualiza o estado com os dados do pedido selecionado
    const handleSelectPedido = (pedido: PedidoEncontrado) => {
        if (activeSearchItem !== null) {
            setItensManuais(prevItens => 
                prevItens.map(item => {
                    if (item.item_xml === activeSearchItem.item_xml) {
                        return {
                            ...item,
                            num_pedido: pedido.Pedido,
                            descricao_pedido_api: pedido.Produto,
                            valor_pedido_api: pedido.Valor,
                            registro_pedido: pedido.Registro, // <<-- ARMAZENANDO O R_E_C_N_O_
                        };
                    }
                    return item;
                })
            );
        }
        setIsPedidoSearchModalOpen(false);
        setActiveSearchItem(null);
    };

    const handleCloseSearchModal = () => {
        setIsPedidoSearchModalOpen(false);
        setActiveSearchItem(null);
    }

    // Funções para arrastar o modal
    const handleMouseDown = (e: React.MouseEvent) => {
        if (modalRef.current) {
            const target = e.target as HTMLElement;
            if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'BUTTON' || target.tagName === 'SELECT') {
                return;
            }
            setIsDragging(true);
            const modalRect = modalRef.current.getBoundingClientRect();
            setOffset({
                x: e.clientX - modalRect.left,
                y: e.clientY - modalRect.top
            });
            e.preventDefault();
        }
    };

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!isDragging) return;
        const newX = e.clientX - offset.x;
        const newY = e.clientY - offset.y;
        setPosition({ x: newX, y: newY });
    }, [isDragging, offset]);

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
    }, []);

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, handleMouseMove, handleMouseUp]);

    useEffect(() => {
        if (isOpen && modalRef.current) {
            const modal = modalRef.current;
            const initialX = (window.innerWidth - modal.offsetWidth) / 2;
            const initialY = 80;
            setPosition({ x: initialX > 0 ? initialX : 20, y: initialY });
        }
    }, [isOpen]);

    if (!isOpen) return null;

    return (
        <>
            <div onClick={isSaving ? undefined : onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2147483648 }}></div>
            <div 
                ref={modalRef}
                style={{ 
                    position: 'fixed', 
                    top: position.y,
                    left: position.x,
                    backgroundColor: 'white', 
                    borderRadius: '8px', 
                    zIndex: 2147483649, 
                    width: '95%', 
                    maxWidth: '1200px', // Aumentado para caber as novas colunas
                    display: 'flex', 
                    flexDirection: 'column', 
                    maxHeight: '90vh',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
                }}
            >
                <div 
                    onMouseDown={handleMouseDown}
                    style={{
                        padding: '1.5rem',
                        borderBottom: '1px solid #dee2e6',
                        flexShrink: 0,
                        cursor: 'move',
                        backgroundColor: '#f1f5fb',
                        borderTopLeftRadius: '8px',
                        borderTopRightRadius: '8px'
                    }}
                >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>Informar Pedidos Manualmente</span>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                            <button
                                onClick={handleAIAssist}
                                disabled={isSaving || isAILoading}
                                title="Usar assistente de IA para preencher os pedidos"
                                style={{
                                    background: '#fff',
                                    border: '2px solid #facc15',
                                    padding: '8px 16px',
                                    borderRadius: '8px',
                                    cursor: (isSaving || isAILoading) ? 'not-allowed' : 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    color: '#00314A',
                                    fontWeight: 600,
                                    fontSize: '0.9rem',
                                    transition: 'all 0.2s ease',
                                    opacity: (isSaving || isAILoading) ? 0.6 : 1,
                                }}
                                onMouseEnter={(e) => { if (!isSaving && !isAILoading) e.currentTarget.style.background = '#fffbea'; }}
                                onMouseLeave={(e) => { if (!isSaving && !isAILoading) e.currentTarget.style.background = '#fff'; }}
                            >
                                {isAILoading ? (
                                    <FaSpinner className="animate-spin" />
                                ) : (
                                    <Sparkles size={18} color="#f59e0b" />
                                )}
                                <span>{isAILoading ? "Aguarde..." : "Preencher com IA"}</span>
                            </button>
                            <button onClick={isSaving || isAILoading ? undefined : onClose} disabled={isSaving || isAILoading} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: (isSaving || isAILoading) ? 'not-allowed' : 'pointer' }}>&times;</button>
                        </div>
                    </div>
                </div>

                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', overflow: 'hidden', flexGrow: 1 }}>
                    <div style={{ overflowY: 'auto', flexGrow: 1 }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                            <thead style={{ backgroundColor: '#f1f5fb', color: '#1b4c89', position: 'sticky', top: 0, zIndex: 1 }}>
                                <tr>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '5%' }}>Item</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'left', width: '25%' }}>Descrição XML</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '12%' }}>Valor Unit. (XML)</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '18%' }}>Pedido</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'left', width: '25%' }}>Descrição Pedido (API)</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '10%' }}>Valor Pedido (API)</th>
                                    <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '8%' }}>Diferença</th>
                                </tr>
                            </thead>
                            <tbody>
                                {itensManuais.map((item, index) => {
                                    const diferenca = (item.valor_pedido_api ?? 0) - (item.valor_unitario_xml ?? 0);
                                    let corDiferenca = '#333';
                                    if(diferenca > 0.001) corDiferenca = '#dc3545'; // Vermelho para maior
                                    if(diferenca < -0.001) corDiferenca = '#28a745'; // Verde para menor

                                    return (
                                        <tr key={index} style={{ backgroundColor: activeSearchItem?.item_xml === item.item_xml ? '#fffbea' : (index % 2 === 0 ? '#fff' : '#f9f9f9') }}>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'center', fontWeight: 'bold' }}>{item.item_xml}</td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6' }}>{item.descricao_xml}</td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace' }}>
                                                {item.valor_unitario_xml?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) ?? 'N/A'}
                                            </td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'center' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                                                    <input
                                                        type="text"
                                                        value={item.num_pedido || ''}
                                                        onChange={(e) => handleUpdatePedido(item.item_xml, e.target.value)}
                                                        style={{ width: '100%', padding: '8px', borderRadius: '5px', border: '1px solid #ccc' }}
                                                    />
                                                    <button
                                                        onClick={() => handleSearchPedido(item)}
                                                        title="Buscar Pedido"
                                                        disabled={isSaving || (isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml)}
                                                        style={{ background: '#eaf2fa', border: '1px solid #a3b8d1', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: (isSaving || (isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml)) ? 'not-allowed' : 'pointer', flexShrink: 0 }}
                                                    >
                                                        {isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml ? <FaSpinner className="animate-spin" size={12} color="#1b4c89"/> : <FaSearch size={12} color="#1b4c89" />}
                                                    </button>
                                                </div>
                                            </td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6' }}>{item.descricao_pedido_api ?? ''}</td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace' }}>
                                                {item.valor_pedido_api !== null ? item.valor_pedido_api.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : ''}
                                            </td>
                                            <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace', fontWeight: 'bold', color: corDiferenca }}>
                                                {item.valor_pedido_api !== null ? diferenca.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : ''}
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '1rem', marginTop: '1rem', flexShrink: 0 }}>
                        <button onClick={onClose} disabled={isSaving} style={{ padding: '10px 20px', borderRadius: '5px', border: '1px solid #ccc', background: '#f1f1f1', cursor: isSaving ? 'not-allowed' : 'pointer', fontWeight: 'bold' }}>Cancelar</button>
                        <button onClick={handleSave} disabled={isSaving} style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: '#28a745', color: 'white', cursor: isSaving ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}>
                            {isSaving ? <><FaSpinner className="animate-spin" /> Salvando...</> : 'Salvar Alterações'}
                        </button>
                    </div>
                </div>
            </div>
            <PedidoSearchModal
                isOpen={isPedidoSearchModalOpen}
                onClose={handleCloseSearchModal}
                onSelect={handleSelectPedido}
                searchResults={pedidoSearchResults}
                isLoading={isPedidoSearchLoading}
                error={pedidoSearchError}
                activeItemInfo={activeSearchItem ? { item: String(activeSearchItem.item_xml), descricao: activeSearchItem.descricao_xml } : null}
            />
        </>
    );
};

export default ManualPedidoModal;