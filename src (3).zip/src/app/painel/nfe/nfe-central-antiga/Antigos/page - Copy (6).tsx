"use client";

import { useEffect, useState } from "react";
import { RefreshCcw, ChevronDownCircle, ChevronUpCircle } from "lucide-react";

interface Nota {
  filial: string;
  dt_recebimento: string;
  hr_Recebimento: string;
  grp_empresa: string;
  nf: string;
  serie: string;
  nome_fornecedor: string;
  chave: string;
  status_nf: string;
  dt_atualizacao: string;
  observacao: string;
}

export default function ConsultaNotas() {
  const [notas, setNotas] = useState<Nota[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<string>("Todos");
  const [busca, setBusca] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [dropdownOpen, setDropdownOpen] = useState(null);
  const [paginaAtual, setPaginaAtual] = useState<number>(1);
  const itensPorPagina = 20;

  const fetchNotas = async () => {
      try {
        const response = await fetch("/api/nfe-consulta-notas-cabecalho", {
          method: "POST",
        });
        const data = await response.json();
        setNotas(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Erro ao buscar as notas:", error);
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
    fetchNotas();
  }, []);

  const filtrarNotas = (notas || []).filter((nota) => {
    const termo = busca.toLowerCase();
    const statusOk = filtroStatus === "Todos" || nota.status_nf === filtroStatus;
    const buscaOk =
      nota.nome_fornecedor.toLowerCase().includes(termo) ||
      nota.nf.includes(termo) ||
      nota.chave.includes(termo);

    return statusOk && buscaOk;
  });

  const totalPaginas = Math.ceil(filtrarNotas.length / itensPorPagina);
  const notasPaginadas = filtrarNotas.slice((paginaAtual - 1) * itensPorPagina, paginaAtual * itensPorPagina);

  const coresStatus: Record<string, string> = {
    "Erro": "#dc3545",
    "Aguardando": "#f7941d",
    "Importado": "#28a745"
  };

  const statusDisponiveis = ["Todos", "Erro", "Aguardando", "Importado"];

  return (<>
<style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
    <div style={{ padding: "2rem", backgroundColor: "#f9fbf7", minHeight: "100vh" }}>
      <h2 style={{
        textAlign: 'center',
        marginBottom: '2rem',
        fontSize: '2rem',
        fontWeight: 'bold',
        background: 'linear-gradient(90deg, #1b4c89, #6fb1fc)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Consulta de Notas Fiscais de Entrada
      </h2>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "1rem" }}>
        <button
          onClick={() => {
            setLoading(true);
            fetchNotas();
          }}
          className="btn-verde"
        >
          <RefreshCcw size={16} title="Atualizar Notas Fiscais" />
        </button>
      </div>


      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flexWrap: "wrap", marginBottom: "1.5rem", gap: "1rem" }}>
        <input
          type="text"
          placeholder="Buscar por fornecedor, nota ou chave"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          style={{ padding: "12px", fontSize: "16px", borderRadius: "8px", border: "1px solid #ccc", width: "400px" }}
        />
      <button
          onClick={() => {}}
          className="btn-verde"
          
        >
          🔍 Pesquisar
        </button>
      </div>

      <div style={{ display: "flex", justifyContent: "center", gap: "1rem", marginBottom: "2rem", flexWrap: "wrap" }}>
        {statusDisponiveis.map((status) => (
          <button
            key={status}
            onClick={() => setFiltroStatus(status)}
            style={{
              backgroundColor: filtroStatus === status ? (coresStatus[status] || "#ccc") : "#f1f1f1",
              color: filtroStatus === status ? "#fff" : "#333",
              border: "none",
              padding: "10px 16px",
              borderRadius: "20px",
              fontWeight: "bold",
              cursor: "pointer"
            }}
          >
            {status}
          </button>
        ))}
      </div>

      {loading ? (
        
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '2rem' }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '4px solid #ccc',
            borderTop: '4px solid var(--cor-primaria)',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <div style={{ marginTop: '1rem', fontWeight: 'bold', color: 'var(--cor-primaria)' }}>
            Carregando notas...
          </div>
        </div>

      ) : filtrarNotas.length === 0 ? (
        <div style={{ textAlign: "center", color: "#999", marginTop: "4rem", fontStyle: "italic" }}>
          Nenhuma nota encontrada para o filtro atual.
        </div>
      ) : (
        <>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", backgroundColor: "#fff", borderRadius: "8px", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
              <thead style={{ backgroundColor: "#1b4c89", color: "#fff", textAlign: "left" }}>
                <tr>
                  <th style={{ padding: "12px" }}>Filial</th>
                  <th style={{ padding: "12px" }}>Nota</th>
                  <th style={{ padding: "12px" }}>Série</th>
                  <th style={{ padding: "12px" }}>Fornecedor</th>
                  <th style={{ padding: "12px" }}>Recebimento</th>
                  <th style={{ padding: "12px" }}>Status</th>
                  <th style={{ padding: "12px" }}>Observação</th>
<th style={{ padding: "12px" }}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {notasPaginadas.map((nota, index) => (
                  <tr
                    key={index}
                    style={{
                      backgroundColor: index % 2 === 0 ? "#ffffff" : "#f5f5f5",
                      borderBottom: "1px solid #ddd"
                    }}
                  >
                    <td style={{ padding: "10px" }}>{nota.filial}</td>
                    <td style={{ padding: "10px" }}>NF-{nota.nf}</td>
                    <td style={{ padding: "10px" }}>{nota.serie}</td>
                    <td style={{ padding: "10px" }}>
                      <span style={{
                        display: "inline-block",
                        padding: "4px 10px",
                        borderRadius: "12px",
                        backgroundColor: "#e0e0e0",
                        color: "#333",
                        fontSize: "12px",
                        fontWeight: "bold"
                      }}>
                        {nota.nome_fornecedor}
                      </span>
                    </td>
                    <td style={{ padding: "10px" }}>{nota.dt_recebimento} {nota.hr_Recebimento}</td>
                    <td style={{ padding: "10px" }}>
                      <span style={{
                        display: "inline-block",
                        padding: "4px 10px",
                        borderRadius: "16px",
                        backgroundColor: coresStatus[nota.status_nf] || "#999",
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: "12px"
                      }}>
                        {nota.status_nf}
                      </span>
                    </td>
                    <td style={{ padding: "10px", fontSize: "13px", color: "#666" }}>{nota.observacao || "Sem observação"}</td>


<td style={{ padding: "10px", position: "relative", verticalAlign: "top" }}>
  <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
    <button
      onClick={() => setDropdownOpen(dropdownOpen === index ? null : index)}
      title="Mais opções"
      style={{
        background: "none",
        border: "none",
        cursor: "pointer",
        padding: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "transform 0.2s ease-in-out",
        marginBottom: dropdownOpen === index ? "6px" : "0"
      }}
      onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.15)"}
      onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
    >
      {dropdownOpen === index ? (
        <ChevronUpCircle size={20} color="#1b4c89" />
      ) : (
        <ChevronDownCircle size={20} color="#1b4c89" />
      )}
    </button>

    {dropdownOpen === index && (
      <div style={{
        background: "#fff",
        border: "1px solid #ccc",
        borderRadius: "6px",
        padding: "6px 10px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
        zIndex: 1
      }}>
        <button
          onClick={() => alert('Abrir modal de detalhes')}
          style={{
            background: "#1b4c89",
            color: "#fff",
            border: "none",
            padding: "6px 10px",
            borderRadius: "5px",
            cursor: "pointer"
          }}
        >
          Detalhes
        </button>
      </div>
    )}
  </div>
</td>


                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: "1.5rem", textAlign: "center" }}>
            <button
              onClick={() => setPaginaAtual((prev) => Math.max(prev - 1, 1))}
              disabled={paginaAtual === 1}
              className="btn-verde"
            >
              ◀ Anterior
            </button>
            <span style={{ fontWeight: "bold", margin: "0 1rem" }}>
              Página {paginaAtual} de {totalPaginas}
            </span>
            <button
              onClick={() => setPaginaAtual((prev) => Math.min(prev + 1, totalPaginas))}
              disabled={paginaAtual === totalPaginas}
              className="btn-verde"
            >
              Próxima ▶
            </button>
          </div>
        </>
      )}
    </div>
  </>);
}