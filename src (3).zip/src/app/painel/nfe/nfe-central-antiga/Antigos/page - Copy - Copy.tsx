"use client";

import { useEffect, useState, useMemo, useRef } from "react";
import { Pagination } from "antd";
import * as XLSX from 'xlsx';
import { 
    RefreshCcw, FileText, FaExclamationTriangle, Search, Building2, Hash, 
    Truck, Calendar, BadgeCheck, MessageSquare, User, Settings2, ChevronsUpDown, 
    ArrowUp, ArrowDown, Filter, X, FileDown 
} from "lucide-react"; 
import ModalDetalhes from "./ModalDetalhes";
import React from "react";
import "antd/dist/reset.css";

interface Nota {
  filial: string;
  dt_recebimento: string;
  hr_Recebimento: string;
  grp_empresa: string;
  nf: string;
  serie: string;
  nome_fornecedor: string;
  chave: string;
  status_nf: string;
  dt_atualizacao: string;
  observacao: string;
  comprador: string;
}

const FilterPopover = ({ 
    notas, 
    onApplyFilters,
    initialFilters
}: { 
    notas: Nota[], 
    onApplyFilters: (filters: any) => void,
    initialFilters: any
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const [filial, setFilial] = useState(initialFilters.filial || 'Todas');
    const [responsavel, setResponsavel] = useState(initialFilters.responsavel || 'Todos');
    const popoverRef = useRef<HTMLDivElement>(null);

    const filiaisUnicas = useMemo(() => ['Todas', ...Array.from(new Set(notas.map(n => n.filial).filter(Boolean)))], [notas]);
    const responsaveisUnicos = useMemo(() => ['Todos', ...Array.from(new Set(notas.map(n => n.comprador).filter(Boolean)))], [notas]);

    const handleApply = () => {
        onApplyFilters({ filial, responsavel });
        setIsOpen(false);
    };

    const handleClear = () => {
        setFilial('Todas');
        setResponsavel('Todos');
        onApplyFilters({ filial: 'Todas', responsavel: 'Todos' });
        setIsOpen(false);
    };
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [popoverRef]);

    return (
        <div style={{ position: 'relative' }} ref={popoverRef}>
            <button onClick={() => setIsOpen(!isOpen)} title="Filtros Avançados" className="btn btn-outline-gray" style={{padding: '9px'}}>
              <Filter size={20} />
            </button>

            {isOpen && (
                <div style={{
                    position: 'absolute',
                    top: '100%',
                    right: 0,
                    marginTop: '8px',
                    width: '300px',
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
                    border: '1px solid var(--gcs-border-color)',
                    zIndex: 100,
                    padding: '1rem'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                        <h4 style={{ margin: 0, color: 'var(--gcs-blue)' }}>Filtros Avançados</h4>
                        <button onClick={() => setIsOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={18} color="var(--gcs-gray-dark)" /></button>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                        <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 500 }}>Filial</label>
                        <select value={filial} onChange={(e) => setFilial(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--gcs-border-color)' }}>
                            {filiaisUnicas.map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                    </div>

                    <div style={{ marginBottom: '1.5rem' }}>
                        <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 500 }}>Responsável</label>
                        <select value={responsavel} onChange={(e) => setResponsavel(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--gcs-border-color)' }}>
                            {responsaveisUnicos.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                        <button onClick={handleClear} className="btn btn-outline-gray" style={{padding: '8px 16px'}}>Limpar</button>
                        <button onClick={handleApply} className="btn btn-green" style={{padding: '8px 16px'}}>Aplicar</button>
                    </div>
                </div>
            )}
        </div>
    );
};


const ConfirmationModal = ({
    isOpen,
    onClose,
    onConfirm,
    message,
    title = "Confirmação Necessária",
    icon = <FaExclamationTriangle size={40} color="#f7941d" />,
    confirmText = "OK, Entendi",
    confirmColor = "#dc3545",
    showCancelButton = true
}: {
    isOpen: boolean,
    onClose: () => void,
    onConfirm: () => void,
    message: string,
    title?: string,
    icon?: React.ReactNode,
    confirmText?: string,
    confirmColor?: string,
    showCancelButton?: boolean
}) => {
    if (!isOpen) return null;
    return (
        <>
            <div onClick={onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2147483648 }}></div>
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '2rem', borderRadius: '8px', boxShadow: '0 4px 20px rgba(0,0,0,0.2)', zIndex: 2147483649, maxWidth: '450px', textAlign: 'center' }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                    {icon}
                </div>
                <h3 style={{ marginTop: 0, marginBottom: '1rem', color: '#333' }}>{title}</h3>
                <p style={{ color: '#666', lineHeight: 1.6 }}>{message}</p>
                <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                    {showCancelButton && (
                        <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: '5px', border: '1px solid #ccc', background: '#f1f1f1', cursor: 'pointer', fontWeight: 'bold' }}>Cancelar</button>
                    )}
                    <button onClick={onConfirm} style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: confirmColor, color: 'white', cursor: 'pointer', fontWeight: 'bold' }}>{confirmText}</button>
                </div>
            </div>
        </>
    );
};


export default function ConsultaNotas() {
  const [notas, setNotas] = useState<Nota[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<string>("Todos");
  const [busca, setBusca] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [notaSelecionada, setNotaSelecionada] = useState<Nota | null>(null);
  const [modalAberto, setModalAberto] = useState(false);
  const [paginaAtual, setPaginaAtual] = useState<number>(1);
  const itensPorPagina = 10; // Reduzido para melhor visualização em mobile
  const [sortConfig, setSortConfig] = useState<{ key: keyof Nota | null; direction: 'asc' | 'desc' }>({ key: null, direction: 'asc' });
  const [advancedFilters, setAdvancedFilters] = useState({ filial: 'Todas', responsavel: 'Todos' });

  const abrirModalDetalhes = (nota: any) => {
    if (!nota.chave) {
      console.warn("Nota sem chave:", nota);
      return;
    }
    setNotaSelecionada(nota);
    setModalAberto(true);
  };

  const fetchNotas = async () => {
      try {
        setLoading(true);
        const response = await fetch("/api/nfe-consulta-notas-cabecalho", {
          method: "POST",
        });
        const data = await response.json();
        setNotas(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Erro ao buscar as notas:", error);
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
    fetchNotas();
  }, []);
  
  const statusDisponiveis = ["Todos", "Erro", "Erro I.A.", "Aguardando", "Importado", "Pendente", "Manual", "Erro ExecAuto"];

  const notasFiltradasOrdenadas = useMemo(() => {
    let notasFiltradas = (notas || []).filter((nota) => {
      const termo = busca.toLowerCase();
      const statusOk = filtroStatus === "Todos" || nota.status_nf?.trim().toLowerCase() === filtroStatus.toLowerCase();
      const buscaOk =
        nota.nome_fornecedor.toLowerCase().includes(termo) ||
        nota.nf.includes(termo) ||
        nota.chave.includes(termo);
      
      const filialOk = advancedFilters.filial === 'Todas' || nota.filial === advancedFilters.filial;
      const responsavelOk = advancedFilters.responsavel === 'Todos' || nota.comprador === advancedFilters.responsavel;

      return statusOk && buscaOk && filialOk && responsavelOk;
    });

    if (sortConfig.key) {
      notasFiltradas.sort((a, b) => {
        const aValue = a[sortConfig.key!];
        const bValue = b[sortConfig.key!];
        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return notasFiltradas;
  }, [notas, busca, filtroStatus, sortConfig, advancedFilters]);
  
  const requestSort = (key: keyof Nota) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const statusCounts = useMemo(() => {
      const counts: Record<string, number> = { Todos: notas.length };
      statusDisponiveis.slice(1).forEach(status => {
          counts[status] = notas.filter(n => n.status_nf?.trim().toLowerCase() === status.toLowerCase()).length;
      });
      return counts;
  }, [notas]);

  const totalPaginas = Math.ceil(notasFiltradasOrdenadas.length / itensPorPagina);
  const notasPaginadas = notasFiltradasOrdenadas.slice((paginaAtual - 1) * itensPorPagina, paginaAtual * itensPorPagina);

  const coresStatus: Record<string, string> = {
    "Erro": "#dc3545",
    "Erro I.A.": "#ff6f61",
    "Aguardando": "#f7941d",
    "Importado": "#28a745",
    "Pendente": "#6c757d",
    "Manual": "#343a40",
    "Erro ExecAuto": "#8B0000"
  };

  const SortIcon = ({ columnKey }: { columnKey: keyof Nota }) => {
    if (sortConfig.key !== columnKey) {
      return <ChevronsUpDown size={14} style={{ marginLeft: '4px', color: '#ffffff80' }} />;
    }
    if (sortConfig.direction === 'asc') {
      return <ArrowUp size={14} style={{ marginLeft: '4px' }} />;
    }
    return <ArrowDown size={14} style={{ marginLeft: '4px' }} />;
  };

  const handleExportXLSX = () => {
    const headers = ["Filial", "Nota", "Série", "Fornecedor", "Recebimento", "Status", "Observação", "Responsável", "Chave"];
    
    const data = notasFiltradasOrdenadas.map(nota => [
        nota.filial,
        nota.nf,
        nota.serie,
        nota.nome_fornecedor,
        `${nota.dt_recebimento} ${nota.hr_Recebimento}`,
        nota.status_nf,
        nota.observacao || '',
        nota.comprador || '',
        nota.chave
    ]);

    const worksheetData = [headers, ...data];
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    worksheet['!cols'] = [
        { wch: 10 }, { wch: 15 }, { wch: 40 }, { wch: 20 },
        { wch: 15 }, { wch: 50 }, { wch: 25 }, { wch: 50 },
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Notas Fiscais");
    XLSX.writeFile(workbook, "Consulta_Notas_Fiscais.xlsx");
  };

  return (<>
    <style>{`
        :root {
            --gcs-blue: #00314A;
            --gcs-green: #5FB246;
            --gcs-orange: #F58220;
            --gcs-orange-light: #FDBA74;
            --gcs-gray-light: #f8f9fa;
            --gcs-gray-medium: #e9ecef;
            --gcs-gray-dark: #6c757d;
            --gcs-border-color: #dee2e6;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .btn { cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s ease-in-out; border: 1px solid transparent; padding: 10px 20px; border-radius: 8px; }
        .btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .btn:disabled { cursor: not-allowed; opacity: 0.6; }
        .btn-green { background-color: var(--gcs-green); color: white; }
        .btn-green:hover:not(:disabled) { background-color: #4a9d3a; }
        .btn-orange-gradient { background-image: linear-gradient(135deg, var(--gcs-orange), var(--gcs-orange-light)); color: white; padding: 8px 16px; font-size: 14px; border: none; }
        .btn-orange-gradient:hover:not(:disabled) { filter: brightness(1.1); }
        .btn-outline-gray { background-color: #fff; color: var(--gcs-gray-dark); border-color: var(--gcs-border-color); }
        .btn-outline-gray:hover:not(:disabled) { border-color: var(--gcs-gray-dark); background-color: var(--gcs-gray-light); }
        .btn-outline-blue { background-color: #fff; color: var(--gcs-blue); border-color: var(--gcs-border-color); }
        .btn-outline-blue:hover:not(:disabled) { border-color: var(--gcs-blue); background-color: #f1f5fb; }
        .filter-tabs-container { border-bottom: 1px solid var(--gcs-border-color); display: flex; gap: 1.5rem; }
        .tab-button { background: none; border: none; cursor: pointer; padding: 8px 12px 12px 12px; font-size: 1rem; font-weight: 500; color: var(--gcs-gray-dark); position: relative; transition: all 0.2s ease-in-out; }
        .tab-button::after { content: ''; position: absolute; bottom: -2px; right: 0; width: 100%; height: 100%; border-style: solid; border-color: transparent; border-width: 0 3px 3px 0; border-image: linear-gradient(135deg, var(--gcs-orange), var(--gcs-orange-light)) 1; opacity: 0; transform: scale(0.95); transition: all 0.2s ease-in-out; pointer-events: none; filter: drop-shadow(1px 1px 1px rgba(0,0,0,0.2)); }
        .tab-button:hover:not(.active) { transform: translateY(-2px); color: var(--gcs-blue); }
        .tab-button.active { color: var(--gcs-orange); font-weight: 600; transform: translateY(-2px); }
        .tab-button.active::after { opacity: 1; transform: scale(1); }
        .th-sortable { cursor: pointer; transition: color 0.2s ease-in-out; user-select: none; display: flex; align-items: center; }
        .th-sortable:hover { color: #ffffffd0; }
        .ant-pagination-item-active { background-color: var(--gcs-blue) !important; border-color: var(--gcs-blue) !important; }
        .ant-pagination-item-active a { color: white !important; }

        /* ✅ INÍCIO DOS ESTILOS DE RESPONSIVIDADE PARA MOBILE */
        @media (max-width: 768px) {
            .main-container {
                padding: 1rem;
            }
            .page-title {
                font-size: 1.5rem;
                margin-bottom: 2rem;
            }
            .controls-container {
                flex-direction: column;
                align-items: stretch;
            }
            .search-input {
                width: 100%;
            }
            .filter-tabs-container {
                gap: 0.5rem;
                overflow-x: auto; /* Permite rolar as abas se não couberem */
                justify-content: flex-start;
            }
            .tab-button {
                white-space: nowrap;
                padding: 8px 10px 12px 10px;
            }
            
            /* Lógica para transformar a tabela em cards */
            .responsive-table thead {
                display: none; /* Esconde o cabeçalho da tabela */
            }
            .responsive-table tbody,
            .responsive-table tr,
            .responsive-table td {
                display: block;
                width: 100%;
            }
            .responsive-table tr {
                margin-bottom: 1rem;
                border: 1px solid var(--gcs-border-color);
                border-radius: 8px;
                padding: 0.5rem 1rem;
            }
            .responsive-table td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.8rem 0;
                border-bottom: 1px solid var(--gcs-gray-medium);
            }
            .responsive-table tr td:last-child {
                border-bottom: none;
            }
            .responsive-table td::before {
                content: attr(data-label);
                font-weight: bold;
                color: var(--gcs-blue);
                margin-right: 1rem;
            }
            /* Ajustes para células específicas */
            .td-status, .td-actions {
                justify-content: flex-start; /* Alinha o conteúdo à esquerda */
            }
            .td-actions .btn {
                width: 100%; /* Faz o botão de detalhes ocupar a largura toda */
            }
        }
        /* FIM DOS ESTILOS DE RESPONSIVIDADE */
    `}</style>

    <div className="main-container" style={{ padding: "2rem", backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
      
      <h2 className="page-title" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', marginBottom: '2.5rem', fontSize: '2rem', fontWeight: 'bold', color: 'var(--gcs-blue)' }}>
        <FileText size={32} color="var(--gcs-blue)" />
        <span>Consulta de Notas Fiscais de Entrada</span>
      </h2>
      
      <div className="controls-container" style={{ display: "flex", justifyContent: "center", alignItems: "center", flexWrap: "wrap", marginBottom: "2.5rem", gap: "1rem" }}>
        <input
          type="text"
          placeholder="Buscar por fornecedor, nota ou chave"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="search-input"
          style={{ padding: "12px 16px", fontSize: "1rem", borderRadius: "8px", border: "1px solid var(--gcs-border-color)", width: "450px" }}
        />
        <button className="btn btn-green">
          Pesquisar
        </button>
        <button onClick={fetchNotas} title="Atualizar Notas Fiscais" className="btn btn-outline-gray" style={{padding: '9px'}}>
          <RefreshCcw size={20} />
        </button>
        <FilterPopover 
            notas={notas} 
            onApplyFilters={setAdvancedFilters} 
            initialFilters={advancedFilters}
        />
        <button onClick={handleExportXLSX} title="Exportar para Excel" className="btn btn-outline-blue" style={{padding: '9px'}}>
          <FileDown size={20} />
        </button>
      </div>

      <div className="filter-tabs-container" style={{ justifyContent: "center", marginBottom: "2.5rem" }}>
        {statusDisponiveis.map((status) => {
          const isSelected = filtroStatus === status;
          return (
            <button key={status} onClick={() => setFiltroStatus(status)} className={`tab-button ${isSelected ? 'active' : ''}`}>
              {status} ({statusCounts[status] || 0})
            </button>
          )
        })}
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '2rem' }}>
          <div style={{ width: '40px', height: '40px', border: '4px solid var(--gcs-gray-medium)', borderTop: '4px solid var(--gcs-blue)', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
          <div style={{ marginTop: '1rem', fontWeight: 'bold', color: 'var(--gcs-blue)' }}>
            Carregando notas...
          </div>
        </div>
      ) : notasFiltradasOrdenadas.length === 0 ? (
        <div style={{ textAlign: "center", color: "var(--gcs-gray-dark)", marginTop: "4rem", fontSize: '1.1rem' }}>
          Nenhuma nota encontrada para os filtros aplicados.
        </div>
      ) : (
        <>
          <div className="responsive-table-wrapper" style={{ overflowX: "auto", border: "1px solid var(--gcs-border-color)", borderRadius: "12px" }}>
            <table className="responsive-table" style={{ width: "100%", borderCollapse: "collapse", backgroundColor: "#fff", fontSize: '14px' }}>
              <thead style={{ backgroundColor: "var(--gcs-blue)", color: "#fff", textAlign: "left" }}>
                <tr>
                  <th style={{ padding: "16px 12px", borderTopLeftRadius: '12px' }}><div onClick={() => requestSort('filial')} className="th-sortable"><Building2 size={16} style={{marginRight: '8px'}} /> Filial <SortIcon columnKey="filial" /></div></th>
                  <th style={{ padding: "16px 12px" }}><div onClick={() => requestSort('nf')} className="th-sortable"><Hash size={16} style={{marginRight: '8px'}} /> Nota / Série <SortIcon columnKey="nf" /></div></th>
                  <th style={{ padding: "16px 12px" }}><div onClick={() => requestSort('nome_fornecedor')} className="th-sortable"><Truck size={16} style={{marginRight: '8px'}} /> Fornecedor <SortIcon columnKey="nome_fornecedor" /></div></th>
                  <th style={{ padding: "16px 12px" }}><div onClick={() => requestSort('dt_recebimento')} className="th-sortable"><Calendar size={16} style={{marginRight: '8px'}} /> Recebimento <SortIcon columnKey="dt_recebimento" /></div></th>
                  <th style={{ padding: "16px 12px", textAlign: 'center' }}><div className="th-sortable" style={{justifyContent: 'center'}}><BadgeCheck size={16} style={{marginRight: '8px'}} /> Status</div></th>
                  <th style={{ padding: "16px 12px" }}><div className="th-sortable"><MessageSquare size={16} style={{marginRight: '8px'}} /> Observação</div></th>
                  <th style={{ padding: "16px 12px" }}><div onClick={() => requestSort('comprador')} className="th-sortable"><User size={16} style={{marginRight: '8px'}} /> Responsável <SortIcon columnKey="comprador" /></div></th>
                  <th style={{ padding: "16px 12px", textAlign: 'center', borderTopRightRadius: '12px' }}><div className="th-sortable" style={{justifyContent: 'center'}}><Settings2 size={16} style={{marginRight: '8px'}} /> Ações</div></th>
                </tr>
              </thead>
              <tbody>
                {notasPaginadas.map((nota, index) => (
                  <tr
                    key={index}
                    style={{ 
                      borderTop: "1px solid var(--gcs-border-color)",
                      backgroundColor: index % 2 === 0 ? "#ffffff" : "var(--gcs-gray-light)"
                    }}
                  >
                    {/* ✅ ATRIBUTOS "data-label" ADICIONADOS PARA O MODO MOBILE */}
                    <td data-label="Filial" style={{ padding: '14px 12px', verticalAlign: 'middle' }}>{nota.filial}</td>
                    <td data-label="Nota / Série" style={{ padding: '14px 12px', verticalAlign: 'middle', whiteSpace: "nowrap" }}>
                        <span style={{fontWeight: 'bold', color: '#343a40'}}>{nota.nf}</span>
                        <span style={{color: 'var(--gcs-gray-dark)'}}> / {nota.serie}</span>
                    </td>
                    <td data-label="Fornecedor" style={{ padding: '14px 12px', verticalAlign: 'middle', fontSize: '13px' }}>{nota.nome_fornecedor}</td>
                    <td data-label="Recebimento" style={{ padding: '14px 12px', verticalAlign: 'middle' }}>{nota.dt_recebimento} {nota.hr_Recebimento}</td>
                    <td data-label="Status" className="td-status" style={{ padding: '14px 12px', verticalAlign: 'middle', textAlign: 'center' }}>
                      <span style={{
                        padding: "6px 12px",
                        borderRadius: "20px",
                        backgroundColor: coresStatus[nota.status_nf] || "#999",
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: "12px",
                      }}>
                        {nota.status_nf}
                      </span>
                    </td>
                    <td data-label="Observação" style={{ padding: '14px 12px', verticalAlign: 'middle', fontSize: "13px", color: "var(--gcs-gray-dark)", maxWidth: '200px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={nota.observacao}>{nota.observacao || "-"}</td>
                    <td data-label="Responsável" style={{ padding: '14px 12px', verticalAlign: 'middle', fontSize: '13px' }}>
                      {nota.comprador ? nota.comprador : <span style={{ color: 'var(--gcs-gray-dark)' }} title="Sem responsável">—</span>}
                    </td>
                    <td data-label="Ações" className="td-actions" style={{ padding: '14px 12px', verticalAlign: 'middle', textAlign: 'center' }}>
                        <button
                          onClick={() => abrirModalDetalhes(nota)}
                          title="Ver Detalhes da Nota"
                          className="btn btn-orange-gradient"
                        >
                          <Search size={14} /> Detalhes
                        </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
 
          <div style={{ marginTop: "2rem", display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <Pagination
              current={paginaAtual}
              total={notasFiltradasOrdenadas.length}
              pageSize={itensPorPagina}
              onChange={(page) => setPaginaAtual(page)}
              showSizeChanger={false}
            />
          </div>
        </>
      )}
    </div>

    <ModalDetalhes
      chave={notaSelecionada?.chave || ""}
      visivel={modalAberto}
      onClose={() => setModalAberto(false)}
      nomeFornecedor={notaSelecionada?.nome_fornecedor}
      statusNF={notaSelecionada?.status_nf || ""}
      onActionSuccess={fetchNotas}
    />
  </>);

}