"use client";

import { useEffect, useState } from "react";
import { RefreshCcw, FileText, FaExclamationTriangle } from "lucide-react"; 
import ModalDetalhes from "./ModalDetalhes";
import React from "react";

interface Nota {
  filial: string;
  dt_recebimento: string;
  hr_Recebimento: string;
  grp_empresa: string;
  nf: string;
  serie: string;
  nome_fornecedor: string;
  chave: string;
  status_nf: string;
  dt_atualizacao: string;
  observacao: string;
  comprador: string;
}

const ConfirmationModal = ({
    isOpen,
    onClose,
    onConfirm,
    message,
    title = "Confirmação Necessária",
    icon = <FaExclamationTriangle size={40} color="#f7941d" />,
    confirmText = "OK, Entendi",
    confirmColor = "#dc3545",
    showCancelButton = true
}: {
    isOpen: boolean,
    onClose: () => void,
    onConfirm: () => void,
    message: string,
    title?: string,
    icon?: React.ReactNode,
    confirmText?: string,
    confirmColor?: string,
    showCancelButton?: boolean
}) => {
    if (!isOpen) return null;
    return (
        <>
            <div onClick={onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2147483648 }}></div>
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '2rem', borderRadius: '8px', boxShadow: '0 4px 20px rgba(0,0,0,0.2)', zIndex: 2147483649, maxWidth: '450px', textAlign: 'center' }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                    {icon}
                </div>
                <h3 style={{ marginTop: 0, marginBottom: '1rem', color: '#333' }}>{title}</h3>
                <p style={{ color: '#666', lineHeight: 1.6 }}>{message}</p>
                <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                    {showCancelButton && (
                        <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: '5px', border: '1px solid #ccc', background: '#f1f1f1', cursor: 'pointer', fontWeight: 'bold' }}>Cancelar</button>
                    )}
                    <button onClick={onConfirm} style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: confirmColor, color: 'white', cursor: 'pointer', fontWeight: 'bold' }}>{confirmText}</button>
                </div>
            </div>
        </>
    );
};


export default function ConsultaNotas() {
  const [notas, setNotas] = useState<Nota[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<string>("Todos");
  const [busca, setBusca] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [notaSelecionada, setNotaSelecionada] = useState<Nota | null>(null);
  const [modalAberto, setModalAberto] = useState(false);
  const [paginaAtual, setPaginaAtual] = useState<number>(1);
  const itensPorPagina = 20;

  const abrirModalDetalhes = (nota: any) => {
    if (!nota.chave) {
      console.warn("Nota sem chave:", nota);
      return;
    }
    setNotaSelecionada(nota);
    setModalAberto(true);
  };

  const fetchNotas = async () => {
      try {
        setLoading(true);
        const response = await fetch("/api/nfe-consulta-notas-cabecalho", {
          method: "POST",
        });
        const data = await response.json();
        setNotas(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Erro ao buscar as notas:", error);
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
    fetchNotas();
  }, []);

  const filtrarNotas = (notas || []).filter((nota) => {
    const termo = busca.toLowerCase();
    const statusOk = filtroStatus === "Todos" || nota.status_nf?.trim().toLowerCase() === filtroStatus.toLowerCase();
    const buscaOk =
      nota.nome_fornecedor.toLowerCase().includes(termo) ||
      nota.nf.includes(termo) ||
      nota.chave.includes(termo);

    return statusOk && buscaOk;
  });

  const totalPaginas = Math.ceil(filtrarNotas.length / itensPorPagina);
  const notasPaginadas = filtrarNotas.slice((paginaAtual - 1) * itensPorPagina, paginaAtual * itensPorPagina);

  const coresStatus: Record<string, string> = {
    "Erro": "#dc3545",
    "Erro I.A.": "#ff6f61",
    "Aguardando": "#f7941d",
    "Importado": "#28a745",
    "Pendente": "#6c757d",
    "Manual": "#343a40",
    "Erro ExecAuto": "#8B0000"
  };

  const statusDisponiveis = ["Todos", "Erro", "Erro I.A.", "Aguardando", "Importado", "Pendente", "Manual", "Erro ExecAuto"];

  return (<>
    <style>{`
        :root {
            --gcs-blue: #00314A;
            --gcs-blue-light: #1b4c89;
            --gcs-green: #5FB246;
            --gcs-orange: #F58220;
            --gcs-orange-light: #FDBA74;
            --gcs-gray-light: #f8f9fa;
            --gcs-gray-medium: #e9ecef;
            --gcs-gray-dark: #6c757d;
            --gcs-border-color: #dee2e6;
        }

        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        .btn {
            cursor: pointer;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease-in-out;
            border: 1px solid transparent;
            padding: 10px 20px;
            border-radius: 8px;
        }
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .btn:disabled {
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .btn-green {
            background-color: var(--gcs-green);
            color: white;
        }
        .btn-green:hover:not(:disabled) {
            background-color: #4a9d3a;
        }

        .btn-orange-gradient {
            background-image: linear-gradient(135deg, var(--gcs-orange), var(--gcs-orange-light));
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border: none;
        }
        .btn-orange-gradient:hover:not(:disabled) {
            filter: brightness(1.1);
        }
        
        .btn-outline-gray {
            background-color: #fff;
            color: var(--gcs-gray-dark);
            border-color: var(--gcs-border-color);
        }
        .btn-outline-gray:hover:not(:disabled) {
            border-color: var(--gcs-gray-dark);
            background-color: var(--gcs-gray-light);
        }

        .filter-tabs-container {
            border-bottom: 1px solid var(--gcs-border-color);
            display: flex;
            gap: 1.5rem;
        }
        .tab-button {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px 12px 12px 12px;
            font-size: 1rem;
            font-weight: 500;
            color: var(--gcs-gray-dark);
            position: relative;
            transition: all 0.2s ease-in-out;
        }
        .tab-button::after {
            content: '';
            position: absolute;
            bottom: -2px;
            right: 0;
            width: 100%;
            height: 100%;
            border-style: solid;
            border-color: transparent;
            border-width: 0 3px 3px 0;
            border-image: linear-gradient(135deg, var(--gcs-orange), var(--gcs-orange-light)) 1;
            opacity: 0;
            transform: scale(0.95);
            transition: all 0.2s ease-in-out;
            pointer-events: none;
        }
        .tab-button:hover:not(.active) {
            transform: translateY(-2px);
            color: var(--gcs-blue);
        }
        .tab-button.active {
            color: var(--gcs-orange);
            font-weight: 600;
            transform: translateY(-2px);
        }
        .tab-button.active::after {
            opacity: 1;
            transform: scale(1);
        }
    `}</style>

    <div style={{ padding: "2rem", backgroundColor: "#FFFFFF", minHeight: "100vh" }}>
      
      <h2 style={{
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        gap: '0.75rem',
        marginBottom: '2.5rem', 
        fontSize: '2rem', 
        fontWeight: 'bold', 
        color: 'var(--gcs-blue)',
      }}>
        <FileText size={32} color="var(--gcs-blue)" />
        <span>Consulta de Notas Fiscais de Entrada</span>
      </h2>
      
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flexWrap: "wrap", marginBottom: "2.5rem", gap: "1rem" }}>
        <input
          type="text"
          placeholder="Buscar por fornecedor, nota ou chave"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          style={{ padding: "12px 16px", fontSize: "1rem", borderRadius: "8px", border: "1px solid var(--gcs-border-color)", width: "450px" }}
        />
        <button className="btn btn-green">
          Pesquisar
        </button>
        <button onClick={fetchNotas} title="Atualizar Notas Fiscais" className="btn btn-outline-gray" style={{padding: '9px'}}>
          <RefreshCcw size={20} />
        </button>
      </div>

      <div className="filter-tabs-container" style={{ display: "flex", justifyContent: "center", marginBottom: "2.5rem" }}>
        {statusDisponiveis.map((status) => {
          const isSelected = filtroStatus === status;
          return (
            <button
              key={status}
              onClick={() => setFiltroStatus(status)}
              className={`tab-button ${isSelected ? 'active' : ''}`}
            >
              {status}
            </button>
          )
        })}
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '2rem' }}>
          <div style={{
            width: '40px', height: '40px', border: '4px solid var(--gcs-gray-medium)',
            borderTop: '4px solid var(--gcs-blue)', borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <div style={{ marginTop: '1rem', fontWeight: 'bold', color: 'var(--gcs-blue)' }}>
            Carregando notas...
          </div>
        </div>
      ) : filtrarNotas.length === 0 ? (
        <div style={{ textAlign: "center", color: "var(--gcs-gray-dark)", marginTop: "4rem", fontSize: '1.1rem' }}>
          Nenhuma nota encontrada para os filtros aplicados.
        </div>
      ) : (
        <>
          <div style={{ overflowX: "auto", border: "1px solid var(--gcs-border-color)", borderRadius: "12px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", backgroundColor: "#fff", fontSize: '14px' }}>
              {/* ✅ CABEÇALHO DE VOLTA PARA O AZUL INSTITUCIONAL */}
              <thead style={{ backgroundColor: "var(--gcs-blue)", color: "#fff", textAlign: "left" }}>
                <tr>
                  <th style={{ padding: "16px", borderTopLeftRadius: '12px' }}>Filial</th>
                  <th style={{ padding: "16px" }}>Nota / Série</th>
                  <th style={{ padding: "16px" }}>Fornecedor</th>
                  <th style={{ padding: "16px" }}>Recebimento</th>
                  <th style={{ padding: "16px", textAlign: 'center' }}>Status</th>
                  <th style={{ padding: "16px" }}>Observação</th>
                  <th style={{ padding: "16px" }}>Responsável</th>
                  <th style={{ padding: "16px", textAlign: 'center', borderTopRightRadius: '12px' }}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {notasPaginadas.map((nota, index) => (
                  <tr
                    key={index}
                    style={{ 
                      borderTop: "1px solid var(--gcs-border-color)",
                      backgroundColor: index % 2 === 0 ? "#ffffff" : "var(--gcs-gray-light)"
                    }}
                  >
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle' }}>{nota.filial}</td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', whiteSpace: "nowrap" }}>
                        <span style={{fontWeight: 'bold', color: '#343a40'}}>{nota.nf}</span>
                        <span style={{color: 'var(--gcs-gray-dark)'}}> / {nota.serie}</span>
                    </td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', fontSize: '13px' }}>{nota.nome_fornecedor}</td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle' }}>{nota.dt_recebimento} {nota.hr_Recebimento}</td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', textAlign: 'center' }}>
                      <span style={{
                        padding: "6px 12px",
                        borderRadius: "20px",
                        backgroundColor: coresStatus[nota.status_nf] || "#999",
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: "12px",
                      }}>
                        {nota.status_nf}
                      </span>
                    </td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', fontSize: "13px", color: "var(--gcs-gray-dark)", maxWidth: '200px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={nota.observacao}>{nota.observacao || "-"}</td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', fontSize: '13px' }}>{nota.comprador || "N/A"}</td>
                    <td style={{ padding: '14px 16px', verticalAlign: 'middle', textAlign: 'center' }}>
                        <button
                          onClick={() => abrirModalDetalhes(nota)}
                          title="Ver Detalhes da Nota"
                          className="btn btn-orange-gradient"
                        >
                          <FileText size={14} /> Detalhes
                        </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: "2rem", display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '1rem' }}>
            <button
              onClick={() => setPaginaAtual((prev) => Math.max(prev - 1, 1))}
              disabled={paginaAtual === 1}
              className="btn btn-outline-gray"
            >
              Anterior
            </button>
            <span style={{ fontWeight: "bold", color: '#495057' }}>
              Página {paginaAtual} de {totalPaginas}
            </span>
            <button
              onClick={() => setPaginaAtual((prev) => Math.min(prev + 1, totalPaginas))}
              disabled={paginaAtual === totalPaginas}
              className="btn btn-outline-gray"
            >
              Próxima
            </button>
          </div>
        </>
      )}
    </div>

    <ModalDetalhes
      chave={notaSelecionada?.chave || ""}
      visivel={modalAberto}
      onClose={() => setModalAberto(false)}
      nomeFornecedor={notaSelecionada?.nome_fornecedor}
      statusNF={notaSelecionada?.status_nf || ""}
      onActionSuccess={fetchNotas}
    />
  </>);

}