"use client";

/**
 * ModalDetalhes.tsx — COMPLETO
 * ---------------------------------------------------------
 * Container principal do detalhamento da NF-e.
 * - Mantém estado/fluxo
 * - Abre modais de TES e Pedido (arquivos separados)
 * - Usa ConfirmationModal e FormattedOriginalMessage (notificações)
 *
 * Dependências locais (na mesma pasta):
 *   - ModalTes.tsx
 *   - ModalPedido.tsx
 *   - ModalNotificacoes.tsx  (exporta ConfirmationModal, FormattedOriginalMessage)
 *
 * Ajuste endpoints conforme seu backend (constantes abaixo).
 */

import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import ModalTes from "./ModalTes";
import ModalPedido from "./ModalPedido";
import { ConfirmationModal, FormattedOriginalMessage } from "./ModalNotificacoes";

/** =========================
 *  TIPOS BÁSICOS (mínimos)
 *  ========================= */
export type StatusTES = "PROCESSADA" | "PENDENTE" | "ERRO";

export interface ModalDetalhesProps {
  visivel: boolean;
  onClose: () => void;
  onActionSuccess?: () => void;

  /** Contexto da NF */
  chave: string;
  nomeFornecedor?: string;
  statusNF?: string;         // ex: "Em Processamento", "Erro ExecAuto", "Finalizada"
  statusCompras?: string;    // ex: "CONCLUÍDO" | "PENDENTE" | "EM FILA"
  status_tes?: StatusTES;
  observacao?: string;
}

export type ItemNota = {
  item_xml: number;
  descricao_xml: string;
  descricao_pedido?: string | null;
  unidade_pedido?: string | null;
  num_pedido?: string | null;
};

export type TesItem = {
  id: number;
  nItem: number;
  tes_codigo: string;
};

export type TesData = {
  chave: string;
  total_itens: number;
  itens: TesItem[];
};

export type ErroExecAuto = {
  dt_movimentacao: string;
  campo: string;
  motivo: string;
  mensagem_original: string | null; // pode vir texto ou JSON string
};

/** =========================
 *  ENDPOINTS (AJUSTE AQUI)
 *  ========================= */
const ENDPOINT_DETALHES = "/api/nfe/nfe-detalhes"; // GET ?chave=...
const ENDPOINT_SALVAR_TES = "/api/nfe/nfe-salva-tes-manual"; // POST { updates: [{id, tes}] }
const ENDPOINT_SALVAR_PED = "/api/nfe/nfe-salva-pedido-manual"; // POST { chave, updates: { [itemXml]: "000123" | null } }
const ENDPOINT_ENVIAR_UNID = "/api/nfe/nfe-enviar-unidade"; // POST { chave }

/** =========================
 *  COMPONENTE PRINCIPAL
 *  ========================= */
export default function ModalDetalhes({
  visivel,
  onClose,
  onActionSuccess,
  chave,
  nomeFornecedor,
  statusNF: statusNFProp,
  statusCompras: statusComprasProp,
  status_tes: statusTESProp,
  observacao,
}: ModalDetalhesProps) {
  /** -----------------------------
   *  ESTADO GERAL/LOCAL
   *  ----------------------------- */
  const [loading, setLoading] = useState(false);
  const [itens, setItens] = useState<ItemNota[]>([]);
  const [tesData, setTesData] = useState<TesData | null>(null);
  const [errosExecAuto, setErrosExecAuto] = useState<ErroExecAuto[]>([]);
  const [statusNF, setStatusNF] = useState<string>(statusNFProp || "");
  const [statusCompras, setStatusCompras] = useState<string | undefined>(statusComprasProp);
  const [statusTES, setStatusTES] = useState<StatusTES | undefined>(statusTESProp);

  const [apiMessageTes, setApiMessageTes] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [savingTes, setSavingTes] = useState(false);

  const [savingPed, setSavingPed] = useState(false);

  /** modais */
  const [openTes, setOpenTes] = useState(false);
  const [openPed, setOpenPed] = useState(false);

  /** confirmações */
  const [openConfirmEnviar, setOpenConfirmEnviar] = useState(false);

  /** anchor para drag do modal principal (opcional) */
  const modalRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [off, setOff] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);

  /** -----------------------------
   *  CARREGAR DADOS
   *  ----------------------------- */
  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const url = `${ENDPOINT_DETALHES}?chave=${encodeURIComponent(chave)}`;
      const resp = await fetch(url);
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Erro ao buscar detalhes da NF.");

      // Estrutura esperada (ajuste conforme seu backend):
      // {
      //   itens: ItemNota[],
      //   tesData: TesData | null,
      //   errosExecAuto: ErroExecAuto[],
      //   statusNF: string,
      //   statusCompras?: string,
      //   statusTES?: "PROCESSADA" | "PENDENTE" | "ERRO"
      // }
      setItens(Array.isArray(data?.itens) ? data.itens : []);
      setTesData(data?.tesData ?? null);
      setErrosExecAuto(Array.isArray(data?.errosExecAuto) ? data.errosExecAuto : []);
      if (data?.statusNF) setStatusNF(String(data.statusNF));
      if (data?.statusCompras) setStatusCompras(String(data.statusCompras));
      if (data?.statusTES) setStatusTES(data.statusTES as StatusTES);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [chave]);

  useEffect(() => {
    if (visivel) fetchAll();
  }, [visivel, fetchAll]);

  /** -----------------------------
   *  AÇÕES
   *  ----------------------------- */
  const handleSalvarTesManuais = async (updates: { id: number; tes: string }[]) => {
    setSavingTes(true);
    setApiMessageTes(null);
    try {
      const resp = await fetch(ENDPOINT_SALVAR_TES, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ updates }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Falha ao salvar TES.");

      setApiMessageTes({ type: "success", text: "TES atualizadas com sucesso." });
      await fetchAll();
      setOpenTes(false);
      onActionSuccess && onActionSuccess();
    } catch (e: any) {
      setApiMessageTes({ type: "error", text: e.message || "Erro ao salvar TES." });
    } finally {
      setSavingTes(false);
    }
  };

  const handleSalvarPedidosManuais = async (updates: Record<number, string | null>) => {
    setSavingPed(true);
    try {
      const resp = await fetch(ENDPOINT_SALVAR_PED, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chave, updates }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Falha ao salvar pedidos.");

      await fetchAll();
      setOpenPed(false);
      onActionSuccess && onActionSuccess();
    } catch (e: any) {
      alert(e.message || "Erro ao salvar pedidos.");
    } finally {
      setSavingPed(false);
    }
  };

  const enviarParaUnidade = async () => {
    try {
      const resp = await fetch(ENDPOINT_ENVIAR_UNID, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chave }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Falha ao enviar para a unidade.");
      setOpenConfirmEnviar(false);
      await fetchAll();
      onActionSuccess && onActionSuccess();
      alert("Nota enviada para a unidade com sucesso.");
    } catch (e: any) {
      alert(e.message || "Erro ao enviar a nota.");
    }
  };

  /** -----------------------------
   *  DRAG DO MODAL PRINCIPAL
   *  ----------------------------- */
  const onMouseDown = (e: React.MouseEvent) => {
    if (!modalRef.current) return;
    const t = e.target as HTMLElement;
    if (["INPUT", "TEXTAREA", "BUTTON", "SELECT", "A"].includes(t.tagName)) return;
    setDragging(true);
    const r = modalRef.current.getBoundingClientRect();
    setOff({ x: e.clientX - r.left, y: e.clientY - r.top });
    e.preventDefault();
  };

  const onMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!dragging) return;
      setPos({ x: e.clientX - off.x, y: e.clientY - off.y });
    },
    [dragging, off]
  );

  const onMouseUp = useCallback(() => setDragging(false), []);

  useEffect(() => {
    if (dragging) {
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  }, [dragging, onMouseMove, onMouseUp]);

  useEffect(() => {
    if (visivel && modalRef.current) {
      const m = modalRef.current;
      const x = (window.innerWidth - m.offsetWidth) / 2.4;
      const y = 50;
      setPos({ x: x > 0 ? x : 20, y });
    }
  }, [visivel]);

  /** -----------------------------
   *  DERIVADOS
   *  ----------------------------- */
  const temErroExecAuto = useMemo(() => {
    return (errosExecAuto || []).length > 0;
  }, [errosExecAuto]);

  const mensagemOriginalPrimeiroErro = useMemo(() => {
    return errosExecAuto?.[0]?.mensagem_original || null;
  }, [errosExecAuto]);

  /** -----------------------------
   *  RENDER
   *  ----------------------------- */

  if (!visivel) return null;

  return (
    <>
      {/* BACKDROP */}
      <div
        onClick={onClose}
        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 2147483600 }}
      />

      {/* MODAL CONTAINER */}
      <div
        ref={modalRef}
        style={{
          position: "fixed",
          top: pos.y,
          left: pos.x,
          zIndex: 2147483601,
          width: "95%",
          maxWidth: 1200,
          background: "#fff",
          borderRadius: 10,
          boxShadow: "0 10px 30px rgba(0,0,0,.25)",
          display: "flex",
          flexDirection: "column",
          maxHeight: "92vh",
        }}
      >
        {/* HEADER (arrastável) */}
        <div
          onMouseDown={onMouseDown}
          style={{
            padding: "16px 18px",
            background: "linear-gradient(90deg, #1b4c89 0%, #3569aa 100%)",
            color: "#fff",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
            cursor: "move",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
            <div>
              <div style={{ fontSize: "1.05rem", fontWeight: 700 }}>
                Detalhes da Nota • {nomeFornecedor || "Fornecedor"} • {formatChave(chave)}
              </div>
              <div style={{ opacity: 0.9, fontSize: ".9rem" }}>
                Status NF: <b>{statusNF || "—"}</b>
                {typeof statusCompras === "string" && (
                  <>
                    {"  •  "}Compras: <b>{statusCompras}</b>
                  </>
                )}
                {statusTES && (
                  <>
                    {"  •  "}Fiscal: <b>{statusTES}</b>
                  </>
                )}
              </div>
            </div>
            <button
              onClick={onClose}
              style={{
                border: "none",
                background: "rgba(255,255,255,.12)",
                color: "#fff",
                fontSize: "1.4rem",
                width: 36,
                height: 36,
                borderRadius: "50%",
                cursor: "pointer",
              }}
              title="Fechar"
            >
              &times;
            </button>
          </div>
        </div>

        {/* BODY */}
        <div style={{ padding: 16, overflow: "hidden", display: "flex", gap: 16, height: "100%" }}>
          {/* COLUNA ESQUERDA: ITENS / AÇÕES */}
          <div style={{ flex: 1.2, minWidth: 420, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* AÇÕES PRINCIPAIS */}
            <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
              <button
                onClick={() => setOpenTes(true)}
                disabled={loading}
                title="Informar TES manualmente"
                style={btnPrimary}
              >
                TES Manual
              </button>
              <button
                onClick={() => setOpenPed(true)}
                disabled={loading}
                title="Informar Pedidos manualmente"
                style={btnSecondary}
              >
                Pedido Manual
              </button>
              <button
                onClick={() => setOpenConfirmEnviar(true)}
                disabled={loading}
                title="Enviar nota para unidade"
                style={btnSuccess}
              >
                Enviar p/ Unidade
              </button>
            </div>

            {/* LISTA DE ITENS */}
            <div style={{ border: "1px solid #e9ecef", borderRadius: 8, overflow: "hidden", flex: 1, minHeight: 220 }}>
              <div style={{ background: "#f7f9fc", padding: "10px 12px", borderBottom: "1px solid #e9ecef", color: "#1b4c89", fontWeight: 700 }}>
                Itens da NF (XML) — {itens.length} item(ns)
              </div>
              <div style={{ overflowY: "auto", maxHeight: "48vh" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                  <thead>
                    <tr style={{ background: "#f1f5fb", color: "#1b4c89" }}>
                      <th style={thBase}>Item</th>
                      <th style={thLeft}>Descrição XML</th>
                      <th style={thBase}>Pedido</th>
                      <th style={thBase}>TES</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr><td colSpan={4} style={{ padding: 14, textAlign: "center", color: "#6c757d" }}>Carregando...</td></tr>
                    ) : itens.length === 0 ? (
                      <tr><td colSpan={4} style={{ padding: 14, textAlign: "center", color: "#6c757d" }}>Nenhum item para exibir.</td></tr>
                    ) : (
                      itens.map((it, idx) => {
                        const infoTES = tesData?.itens.find(t => t.nItem === it.item_xml);
                        return (
                          <tr key={`${it.item_xml}-${idx}`} style={{ background: idx % 2 ? "#fafafa" : "#fff" }}>
                            <td style={tdCenterBold}>{it.item_xml}</td>
                            <td style={tdLeft}>{it.descricao_xml}</td>
                            <td style={tdCenter}>{it.num_pedido || "—"}</td>
                            <td style={tdCenter}>
                              <b>{infoTES?.tes_codigo || "—"}</b>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* COLUNA DIREITA: ERROS/OBSERVAÇÕES */}
          <div style={{ flex: 0.8, minWidth: 320, display: "flex", flexDirection: "column", gap: 12 }}>
            {/* OBSERVAÇÃO */}
            <div style={{ border: "1px solid #e9ecef", borderRadius: 8, padding: 12 }}>
              <div style={{ fontWeight: 700, marginBottom: 6, color: "#1b4c89" }}>Observação</div>
              <div style={{ fontSize: ".95rem", color: "#333", whiteSpace: "pre-wrap" }}>
                {observacao?.trim() ? observacao : <span style={{ color: "#6c757d" }}>—</span>}
              </div>
            </div>

            {/* ERRO EXEC AUTO */}
            <div style={{ border: "1px solid #e9ecef", borderRadius: 8, padding: 12, flex: 1, overflow: "hidden" }}>
              <div style={{ fontWeight: 700, marginBottom: 6, color: temErroExecAuto ? "#dc3545" : "#1b4c89" }}>
                {temErroExecAuto ? "Erro ExecAuto (detalhes)" : "Sem erros de execução"}
              </div>
              <div style={{ overflowY: "auto", maxHeight: "36vh" }}>
                {temErroExecAuto ? (
                  <>
                    {errosExecAuto.map((e, i) => (
                      <div key={`${e.dt_movimentacao}-${i}`} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: "1px dashed #eee" }}>
                        <div style={{ fontSize: ".85rem", color: "#6c757d" }}>{e.dt_movimentacao}</div>
                        <div style={{ fontWeight: 600 }}>{e.campo} — {e.motivo}</div>
                      </div>
                    ))}
                    <div style={{ marginTop: 6 }}>
                      <div style={{ fontWeight: 700, marginBottom: 6 }}>Mensagem original:</div>
                      <FormattedOriginalMessage message={mensagemOriginalPrimeiroErro} />
                    </div>
                  </>
                ) : (
                  <div style={{ color: "#6c757d" }}>Nenhuma ocorrência de erro para esta nota.</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* FOOTER */}
        <div
          style={{
            padding: 12,
            borderTop: "1px solid #e9ecef",
            display: "flex",
            justifyContent: "flex-end",
            gap: 10,
            background: "#fff",
            borderBottomLeftRadius: 10,
            borderBottomRightRadius: 10,
          }}
        >
          <button onClick={onClose} style={btnGhost}>Fechar</button>
        </div>
      </div>

      {/* ========= MODAIS FILHOS ========= */}
      <ModalTes
        open={openTes}
        onClose={() => setOpenTes(false)}
        onSave={handleSalvarTesManuais}
        items={itens.map(({ item_xml, descricao_xml }) => ({ item_xml, descricao_xml }))}
        tesData={tesData}
        loading={savingTes}
        apiMessage={apiMessageTes}
      />

      <ModalPedido
        open={openPed}
        onClose={() => setOpenPed(false)}
        onSave={handleSalvarPedidosManuais}
        items={itens}
        chave={chave}
      />

      <ConfirmationModal
        open={openConfirmEnviar}
        onClose={() => setOpenConfirmEnviar(false)}
        onConfirm={enviarParaUnidade}
        title="Enviar Nota"
        message={`Confirma o envio da nota ${formatChave(chave)} para a unidade?`}
        confirmText="Enviar"
        confirmColor="#1b4c89"
      />
    </>
  );
}

/** =========================
 *  HELPERS DE ESTILO
 *  ========================= */
const btnBase: React.CSSProperties = {
  padding: "10px 14px",
  borderRadius: 8,
  border: "none",
  fontWeight: 700,
  cursor: "pointer",
};

const btnPrimary: React.CSSProperties = {
  ...btnBase,
  background: "#1b4c89",
  color: "#fff",
};
const btnSecondary: React.CSSProperties = {
  ...btnBase,
  background: "#0d6efd",
  color: "#fff",
};
const btnSuccess: React.CSSProperties = {
  ...btnBase,
  background: "#28a745",
  color: "#fff",
};
const btnGhost: React.CSSProperties = {
  ...btnBase,
  background: "#f1f1f1",
  color: "#333",
  border: "1px solid #ddd",
};

const thBase: React.CSSProperties = { padding: 10, border: "1px solid #e9ecef", textAlign: "center", fontWeight: 800 };
const thLeft: React.CSSProperties = { ...thBase, textAlign: "left" };
const tdCenter: React.CSSProperties = { padding: 10, border: "1px solid #f1f1f1", textAlign: "center" };
const tdCenterBold: React.CSSProperties = { ...tdCenter, fontWeight: 700 };
const tdLeft: React.CSSProperties = { padding: 10, border: "1px solid #f1f1f1", textAlign: "left" };

/** =========================
 *  OUTROS HELPERS
 *  ========================= */
function formatChave(chave: string) {
  if (!chave) return "—";
  const c = chave.replace(/\D/g, "");
  if (c.length !== 44) return chave;
  return `${c.slice(0, 4)} ${c.slice(4, 8)} ${c.slice(8, 12)} ${c.slice(12, 16)} ${c.slice(16, 20)} ${c.slice(20, 24)} ${c.slice(24, 28)} ${c.slice(28, 32)} ${c.slice(32, 36)} ${c.slice(36, 40)} ${c.slice(40)}`;
}
