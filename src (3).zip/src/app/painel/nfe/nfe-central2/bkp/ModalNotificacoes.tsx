"use client";
import React from "react";
import { FaExclamationTriangle } from "react-icons/fa";

/** Modal de confirmação genérico */
export function ConfirmationModal({
  open,
  onClose,
  onConfirm,
  message,
  title = "Confirmação",
  confirmText = "Confirmar",
  confirmColor = "#dc3545",
  showCancel = true,
  icon = <FaExclamationTriangle size={36} color="#f59e0b" />,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  message: string;
  title?: string;
  confirmText?: string;
  confirmColor?: string;
  showCancel?: boolean;
  icon?: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2147483648 }} />
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "#fff", borderRadius: 8, zIndex: 2147483649, maxWidth: 460, width: "92%", padding: "1.4rem" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>{icon}</div>
        <h3 style={{ margin: "0 0 .5rem", textAlign: "center" }}>{title}</h3>
        <p style={{ color: "#555", lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{message}</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 12, marginTop: 16 }}>
          {showCancel && (
            <button onClick={onClose} style={{ padding: "10px 18px", borderRadius: 6, border: "1px solid #ced4da", background: "#f1f1f1", fontWeight: 700 }}>
              Cancelar
            </button>
          )}
          <button onClick={onConfirm} style={{ padding: "10px 18px", borderRadius: 6, border: "none", background: confirmColor, color: "#fff", fontWeight: 700 }}>
            {confirmText}
          </button>
        </div>
      </div>
    </>
  );
}

/** Exibe texto original/JSON de erro formatado */
export function FormattedOriginalMessage({ message }: { message: string | null }) {
  if (!message) {
    return <pre style={preStyle}>N/A</pre>;
  }
  try {
    const data = JSON.parse(message);
    const details = data.detalhes || "";
    const lines = String(details).split("\\n");
    return (
      <div style={{ fontFamily: "monospace", fontSize: ".9rem", color: "#721c24", lineHeight: 1.6 }}>
        {data.erro && <div style={{ fontWeight: "bold", marginBottom: 8 }}>{data.erro}</div>}
        {lines.map((line: string, i: number) => {
          if (line.trim() === "") return <div key={i} style={{ height: "0.5rem" }} />;
          if (line.includes(":-")) {
            const [k, ...rest] = line.split(":-");
            const key = k.trim();
            const value = rest.join(":-").trim();
            return (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10 }}>
                <span style={{ color: "#555" }}>{key}</span>
                <span style={{ fontWeight: "bold" }}>{value}</span>
              </div>
            );
          }
          return <div key={i}>{line.trim()}</div>;
        })}
      </div>
    );
  } catch {
    return <pre style={preStyle}>{message.replace(/\\n/g, "\n")}</pre>;
  }
}

const preStyle: React.CSSProperties = {
  background: "#f8d7da",
  padding: "0.75rem",
  borderRadius: 6,
  whiteSpace: "pre-wrap",
  wordBreak: "break-word",
  fontSize: ".9rem",
  color: "#721c24",
  marginTop: ".5rem",
};
