"use client";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { FaSearch, FaSpinner, Sparkles } from "react-icons/fa";

/** Tipos mínimos */
export type ItemNota = { item_xml: number; descricao_xml: string; num_pedido?: string | null };
export type PedidoEncontrado = { Pedido: string; Produto: string; UM: string; "Seg. UM"?: string; Saldo: number; Valor: number; Registro: number };

type Props = {
  open: boolean;
  onClose: () => void;
  onSave: (updates: Record<number, string | null>) => Promise<void>;
  items: ItemNota[];
  chave: string;
  /** endpoint POST { chave, item_xml } -> PedidoEncontrado[] */
  endpointBuscaPedido?: string;
};

export default function ModalPedido({
  open,
  onClose,
  onSave,
  items,
  chave,
  endpointBuscaPedido = "/api/nfe/nfe-busca-pedido-manual-item",
}: Props) {
  const [values, setValues] = useState<Record<number, string | null>>({});
  const [saving, setSaving] = useState(false);

  /** busca pedido por item */
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<PedidoEncontrado[]>([]);
  const [activeItem, setActiveItem] = useState<ItemNota | null>(null);

  /** drag */
  const modalRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [off, setOff] = useState({ x: 0, y: 0 });
  const [drag, setDrag] = useState(false);

  useEffect(() => {
    if (open) {
      const initial = items.reduce((acc, it) => {
        acc[it.item_xml] = it.num_pedido ?? null;
        return acc;
      }, {} as Record<number, string | null>);
      setValues(initial);
    }
  }, [open, items]);

  const updateOne = (itemXml: number, v: string) => setValues((p) => ({ ...p, [itemXml]: v }));

  const handleSave = async () => {
    setSaving(true);
    await onSave(values);
    setSaving(false);
  };

  const doSearchPedido = async (it: ItemNota) => {
    setActiveItem(it);
    setSearchOpen(true);
    setSearchLoading(true);
    setSearchError(null);
    setSearchResults([]);
    try {
      const resp = await fetch(endpointBuscaPedido, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chave, item_xml: it.item_xml }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Erro ao buscar pedidos.");
      setSearchResults(Array.isArray(data) ? data : []);
      if (!Array.isArray(data) || data.length === 0) setSearchError("Nenhum pedido disponível para esta raiz.");
    } catch (e: any) {
      setSearchError(e.message);
    } finally {
      setSearchLoading(false);
    }
  };

  const selectPedido = (p: PedidoEncontrado) => {
    if (activeItem) updateOne(activeItem.item_xml, p.Pedido);
    setSearchOpen(false);
    setActiveItem(null);
  };

  /** drag handlers */
  const onMouseDown = (e: React.MouseEvent) => {
    if (!modalRef.current) return;
    const t = e.target as HTMLElement;
    if (["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(t.tagName)) return;
    setDrag(true);
    const r = modalRef.current.getBoundingClientRect();
    setOff({ x: e.clientX - r.left, y: e.clientY - r.top });
    e.preventDefault();
  };
  const onMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!drag) return;
      setPos({ x: e.clientX - off.x, y: e.clientY - off.y });
    },
    [drag, off]
  );
  const onMouseUp = useCallback(() => setDrag(false), []);
  useEffect(() => {
    if (drag) {
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  }, [drag, onMouseMove, onMouseUp]);
  useEffect(() => {
    if (open && modalRef.current) {
      const m = modalRef.current;
      const x = (window.innerWidth - m.offsetWidth) / 2;
      const y = 80;
      setPos({ x: x > 0 ? x : 20, y });
    }
  }, [open]);

  if (!open) return null;

  return (
    <>
      <div onClick={saving ? undefined : onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 2147483648 }} />
      <div ref={modalRef} style={{ position: "fixed", top: pos.y, left: pos.x, background: "#fff", borderRadius: 8, zIndex: 2147483649, width: "92%", maxWidth: 920, display: "flex", flexDirection: "column", maxHeight: "90vh", boxShadow: "0 10px 30px rgba(0,0,0,.2)" }}>
        <div onMouseDown={onMouseDown} style={{ padding: "1.2rem 1.5rem", borderBottom: "1px solid #e9ecef", background: "#f1f5fb", borderTopLeftRadius: 8, borderTopRightRadius: 8, cursor: "move" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <strong>Informar Pedidos Manualmente</strong>
            <button onClick={saving ? undefined : onClose} style={{ border: "none", background: "none", fontSize: "1.5rem", cursor: saving ? "not-allowed" : "pointer" }}>
              &times;
            </button>
          </div>
        </div>

        <div style={{ padding: "1rem 1.5rem", overflow: "hidden", flexGrow: 1 }}>
          <div style={{ overflowY: "auto", maxHeight: "60vh" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
              <thead style={{ position: "sticky", top: 0, zIndex: 1, background: "#f1f5fb", color: "#1b4c89" }}>
                <tr>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 80, textAlign: "center" }}>Item</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", textAlign: "left" }}>Descrição XML</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 240, textAlign: "center" }}>Pedido</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 60 }} />
                </tr>
              </thead>
              <tbody>
                {items.map((it, idx) => (
                  <tr key={it.item_xml} style={{ background: idx % 2 ? "#fafafa" : "#fff" }}>
                    <td style={{ padding: 10, border: "1px solid #f1f1f1", textAlign: "center", fontWeight: 700 }}>{it.item_xml}</td>
                    <td style={{ padding: 10, border: "1px solid #f1f1f1" }}>{it.descricao_xml}</td>
                    <td style={{ padding: 10, border: "1px solid #f1f1f1" }}>
                      <input value={values[it.item_xml] ?? ""} onChange={(e) => updateOne(it.item_xml, e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 6, border: "1px solid #ced4da" }} />
                    </td>
                    <td style={{ padding: 10, border: "1px solid #f1f1f1", textAlign: "center" }}>
                      <button
                        onClick={() => doSearchPedido(it)}
                        disabled={saving}
                        title="Buscar Pedido"
                        style={{ width: 34, height: 34, borderRadius: "50%", border: "1px solid #a3b8d1", background: "#eaf2fa", display: "flex", alignItems: "center", justifyContent: "center", cursor: saving ? "not-allowed" : "pointer" }}
                      >
                        <FaSearch size={12} color="#1b4c89" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 12 }}>
            <button onClick={onClose} disabled={saving} style={{ padding: "10px 18px", borderRadius: 6, border: "1px solid #ced4da", background: "#f1f1f1", fontWeight: 700, cursor: saving ? "not-allowed" : "pointer" }}>
              Cancelar
            </button>
            <button onClick={handleSave} disabled={saving} style={{ padding: "10px 18px", borderRadius: 6, border: "none", background: "#28a745", color: "#fff", fontWeight: 700, display: "flex", alignItems: "center", gap: 8 }}>
              {saving ? <><FaSpinner className="animate-spin" /> Salvando...</> : "Salvar Alterações"}
            </button>
          </div>
        </div>
      </div>

      {/** modal de busca pedido */}
      {searchOpen && (
        <>
          <div onClick={() => setSearchOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2147483650 }} />
          <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "#fff", borderRadius: 8, zIndex: 2147483651, width: "92%", maxWidth: 760, padding: "1rem 1.2rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <strong>Selecionar Pedido</strong>
              <button onClick={() => setSearchOpen(false)} style={{ border: "none", background: "none", fontSize: "1.4rem", cursor: "pointer" }}>&times;</button>
            </div>

            {searchError && <div style={{ color: "#dc3545", marginBottom: 8 }}>{searchError}</div>}
            <div style={{ border: "1px solid #eee", borderRadius: 6, maxHeight: 420, overflowY: "auto" }}>
              {searchLoading ? (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "3rem" }}>
                  <FaSpinner className="animate-spin" size={22} />
                </div>
              ) : searchResults.length > 0 ? (
                searchResults.map((p) => (
                  <div key={p.Registro} onClick={() => selectPedido(p)} style={{ padding: 12, borderBottom: "1px solid #f3f3f3", cursor: "pointer" }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f0f8ff")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "#fff")}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <div><strong style={{ color: "#1b4c89" }}>Pedido: </strong>{p.Pedido}</div>
                      <div style={{ fontSize: ".9em" }}><strong>Saldo:</strong> {p.Saldo} {p.UM?.trim()}</div>
                    </div>
                    <div style={{ fontSize: ".9em", color: "#6c757d", marginTop: 4 }}>{p.Produto}</div>
                    <div style={{ fontSize: ".85em", color: "#666", textAlign: "right" }}>
                      <strong>Valor:</strong> {p.Valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                    </div>
                  </div>
                ))
              ) : (
                <div style={{ padding: 14, color: "#6c757d" }}>Não há pedidos para exibir.</div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}
