"use client";

import React, { useEffect, useState, useCallback, useRef, useMemo } from "react";
import { FaSearch, FaSpinner, FaPencilAlt, FaExclamationTriangle } from "react-icons/fa";
import { Sparkles } from "lucide-react";
import NotificationModal from "./NotificationModal"; // Importado

// --- INTERFACES ---

// Interface para os dados do item que vêm do componente pai (ModalDetalhes)
interface ItemNota {
    item_xml: number;
    descricao_xml: string;
    valor_unitario_xml?: number;
    descricao_pedido: string | null;
    num_pedido: string | null;
    valor_unitario_ped?: number;
    valor_unitario_bate?: string;
    qtd?: number; // Campo para a quantidade
}

// Interface para o retorno da API de busca de pedido
interface PedidoEncontrado {
    Pedido: string;
    Produto: string;
    UM: string;
    "Seg. UM": string;
    Saldo: number;
    Valor: number;
    Registro: number; // Este é o nosso R_E_C_N_O_
}

// Interface para gerenciar o estado de cada linha na tabela deste modal
export interface ItemPedidoManual {
    item_xml: number;
    descricao_xml: string;
    valor_unitario_xml: number | null;
    num_pedido: string | null;
    descricao_pedido_api: string | null;
    valor_pedido_api: number | null;
    registro_pedido: number | null;
    qtd: number | null; // Campo para a quantidade
}

// --- SUB-COMPONENTES ---

const ConfirmationModal = ({
    isOpen,
    onClose,
    onConfirm,
    message,
    title = "Confirmação Necessária",
    icon = <FaExclamationTriangle size={40} color="#f7941d" />,
    confirmText = "OK, Entendi",
    confirmColor = "#dc3545",
    showCancelButton = true
}: {
    isOpen: boolean,
    onClose: () => void,
    onConfirm: () => void,
    message: string,
    title?: string,
    icon?: React.ReactNode,
    confirmText?: string,
    confirmColor?: string,
    showCancelButton?: boolean
}) => {
    if (!isOpen) return null;
    return (
        <>
            <div onClick={onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2147483652 }}></div>
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '2rem', borderRadius: '8px', boxShadow: '0 4px 20px rgba(0,0,0,0.2)', zIndex: 2147483653, maxWidth: '450px', textAlign: 'center' }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                    {icon}
                </div>
                <h3 style={{ marginTop: 0, marginBottom: '1rem', color: '#333' }}>{title}</h3>
                <p style={{ color: '#666', lineHeight: 1.6 }}>{message}</p>
                <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                    {showCancelButton && (
                        <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: '5px', border: '1px solid #ccc', background: '#f1f1f1', cursor: 'pointer', fontWeight: 'bold' }}>Cancelar</button>
                    )}
                    <button onClick={onConfirm} style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: confirmColor, color: 'white', cursor: 'pointer', fontWeight: 'bold' }}>{confirmText}</button>
                </div>
            </div>
        </>
    );
};

const PedidoSearchModal = ({ isOpen, onClose, onSelect, searchResults, isLoading, error, activeItemInfo }: {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (pedido: PedidoEncontrado) => void;
    searchResults: PedidoEncontrado[];
    isLoading: boolean;
    error: string | null;
    activeItemInfo: { item: string; descricao: string; } | null;
}) => {
    const modalRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    const handleMouseDown = (e: React.MouseEvent) => {
        if (modalRef.current) {
            const target = e.target as HTMLElement;
            if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'BUTTON' || target.tagName === 'SELECT') {
                return;
            }
            setIsDragging(true);
            const modalRect = modalRef.current.getBoundingClientRect();
            setOffset({
                x: e.clientX - modalRect.left,
                y: e.clientY - modalRect.top
            });
            e.preventDefault();
        }
    };

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!isDragging) return;
        const newX = e.clientX - offset.x;
        const newY = e.clientY - offset.y;
        setPosition({ x: newX, y: newY });
    }, [isDragging, offset]);

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
    }, []);

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, handleMouseMove, handleMouseUp]);

    useEffect(() => {
        if (isOpen) {
            setSearchTerm(''); // Reseta a busca ao abrir o modal
            if (modalRef.current) {
                const modal = modalRef.current;
                const initialX = (window.innerWidth - modal.offsetWidth) / 1.6;
                const initialY = 100;
                setPosition({ x: initialX > 0 ? initialX : 20, y: initialY });
            }
        }
    }, [isOpen]);

    const filteredResults = useMemo(() => {
        if (!searchTerm) {
            return searchResults;
        }
        const term = searchTerm.toLowerCase();
        return searchResults.filter(p =>
            p.Pedido.toLowerCase().includes(term) ||
            p.Produto.toLowerCase().includes(term)
        );
    }, [searchResults, searchTerm]);


    if (!isOpen) return null;

    let title = "Selecionar Pedido de Compra";
    if (activeItemInfo) {
        const truncatedDesc = activeItemInfo.descricao.length > 30
            ? `${activeItemInfo.descricao.substring(0, 30)}...`
            : activeItemInfo.descricao;
        title = `Selecionar Pedido - Item ${activeItemInfo.item}: ${truncatedDesc}`;
    }

    return (
        <>
            <div onClick={onClose} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2147483650 }}></div>
            <div
                ref={modalRef}
                style={{
                    position: 'fixed',
                    top: position.y,
                    left: position.x,
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    zIndex: 2147483651,
                    width: '90%',
                    maxWidth: '700px',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
                }}
            >
                <div
                    onMouseDown={handleMouseDown}
                    style={{
                        padding: '1.5rem',
                        borderBottom: '1px solid #dee2e6',
                        cursor: 'move',
                        backgroundColor: '#f1f5fb',
                        borderTopLeftRadius: '8px',
                        borderTopRightRadius: '8px'
                    }}
                >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h4 style={{ margin: 0, fontSize: '1.1rem' }}>{title}</h4>
                        <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>&times;</button>
                    </div>
                </div>
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar por nº do pedido ou descrição..."
                        style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
                        autoFocus
                    />
                    {error && <div style={{ color: '#dc3545', padding: '1rem', background: '#f8d7da', borderRadius: '5px' }}>{error}</div>}
                    <div style={{ maxHeight: '350px', overflowY: 'auto', border: '1px solid #eee', borderRadius: '5px' }}>
                        {isLoading ? (
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '3rem' }}>
                                <FaSpinner className="animate-spin" size={24} color="#1b4c89" />
                            </div>
                        ) : filteredResults.length > 0 ? (
                            filteredResults.map((p) => (
                                <div
                                    key={p.Registro}
                                    onClick={() => onSelect(p)}
                                    style={{ padding: '12px', cursor: 'pointer', borderBottom: '1px solid #eee', backgroundColor: '#fff', transition: 'background-color 0.2s' }}
                                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f0f8ff'}
                                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#fff'}
                                >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <div>
                                            <strong style={{ color: '#1b4c89' }}>Pedido:</strong> {p.Pedido}
                                        </div>
                                        <div style={{ fontSize: '0.9em' }}>
                                            <strong>Saldo:</strong> {p.Saldo} {p.UM?.trim()}
                                        </div>
                                    </div>
                                    <div style={{ fontSize: '0.9em', color: '#6c757d', marginTop: '4px' }}>{p.Produto}</div>
                                    <div style={{ fontSize: '0.8em', color: '#888', textAlign: 'right' }}>
                                        <strong>Valor:</strong> {p.Valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                    </div>
                                </div>
                            ))
                        ) : (
                            !error && <div style={{ padding: '20px', textAlign: 'center', color: '#6c757d' }}>Nenhum resultado encontrado.</div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};


// --- COMPONENTE PRINCIPAL: MODAL DE PEDIDOS ---

const ManualPedidoModal = ({
    isOpen,
    onClose,
    onSave,
    items,
    chave
}: {
    isOpen: boolean,
    onClose: () => void,
    onSave: (updates: ItemPedidoManual[]) => Promise<void>,
    items: ItemNota[],
    chave: string
}) => {
    // Novo estado para gerenciar todos os dados dos itens
    const [itensManuais, setItensManuais] = useState<ItemPedidoManual[]>([]);
    const [isLoadingContent, setIsLoadingContent] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [isAILoading, setIsAILoading] = useState(false);
    const [validationError, setValidationError] = useState<string | null>(null);
    const [errorItemId, setErrorItemId] = useState<number | null>(null);

    // Estado para o modal de confirmação de cancelamento
    const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);

    // Estado para o modal de notificação
    const [notification, setNotification] = useState<{ visible: boolean; type: 'success' | 'error'; message: string }>({ visible: false, type: 'success', message: '' });

    // Estados para o modal de busca de pedido
    const [isPedidoSearchModalOpen, setIsPedidoSearchModalOpen] = useState(false);
    const [isPedidoSearchLoading, setIsPedidoSearchLoading] = useState(false);
    const [pedidoSearchError, setPedidoSearchError] = useState<string | null>(null);
    const [pedidoSearchResults, setPedidoSearchResults] = useState<PedidoEncontrado[]>([]);
    const [activeSearchItem, setActiveSearchItem] = useState<ItemPedidoManual | null>(null);

    // Referências e estados para arrastar o modal
    const modalRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);

    // Reseta os estados internos quando o modal é fechado
    useEffect(() => {
        if (!isOpen) {
            setIsCancelConfirmOpen(false);
            setValidationError(null);
            setErrorItemId(null);
        }
    }, [isOpen]);

    // Inicializa o estado do modal quando ele é aberto ou os itens mudam
    useEffect(() => {
        if (isOpen) {
            setIsLoadingContent(true);
            // Adia a população dos itens para o próximo ciclo de renderização
            // para garantir que o estado "Carregando..." seja exibido primeiro.
            const timer = setTimeout(() => {
                const initialItensManuais = items.map(item => {
                    const shouldPrepopulate = item.num_pedido && item.valor_unitario_bate?.toLowerCase() === 'sim';
                    return {
                        item_xml: item.item_xml,
                        descricao_xml: item.descricao_xml,
                        valor_unitario_xml: item.valor_unitario_xml ?? null,
                        qtd: item.qtd ?? null,
                        num_pedido: shouldPrepopulate ? item.num_pedido : null,
                        descricao_pedido_api: shouldPrepopulate ? item.descricao_pedido : null,
                        valor_pedido_api: shouldPrepopulate ? (item.valor_unitario_ped ?? null) : null,
                        registro_pedido: null,
                    };
                });
                setItensManuais(initialItensManuais);
                setIsLoadingContent(false);
            }, 0);

            return () => clearTimeout(timer); // Limpa o timeout se o componente for desmontado
        }
    }, [isOpen, items]);

    const totalDiferenca = useMemo(() => {
        return itensManuais.reduce((acc, item) => {
            if (item.valor_pedido_api !== null && item.valor_unitario_xml !== null && item.qtd !== null) {
                const diferencaUnitaria = item.valor_pedido_api - item.valor_unitario_xml;
                const diferencaTotalItem = diferencaUnitaria * item.qtd;
                return acc + diferencaTotalItem;
            }
            return acc;
        }, 0);
    }, [itensManuais]);

    let corTotalDiferenca = '#333';
    if (totalDiferenca > 0.001) corTotalDiferenca = '#dc3545'; // Vermelho para maior
    if (totalDiferenca < -0.001) corTotalDiferenca = '#28a745'; // Verde para menor

    const handleSave = async () => {
        setValidationError(null);
        setErrorItemId(null);

        const firstInvalidItem = itensManuais.find(item => !item.num_pedido || item.num_pedido.trim() === '');

        if (firstInvalidItem) {
            setValidationError('Todos os pedidos devem ser informados para salvar as alterações.');
            setErrorItemId(firstInvalidItem.item_xml);
            return;
        }
        
        setIsSaving(true);
        try {
            await onSave(itensManuais);
            setNotification({
                visible: true,
                type: 'success',
                message: 'Alterações nos pedidos foram salvas com sucesso!'
            });
        } catch (error: any) {
            setNotification({
                visible: true,
                type: 'error',
                message: error.message || 'Ocorreu um erro ao salvar as alterações. Tente novamente.'
            });
        } finally {
            setIsSaving(false);
        }
    };

    const handleNotificationClose = () => {
        const success = notification.type === 'success';
        setNotification({ visible: false, type: 'success', message: '' });
        if (success) {
            onClose(); // Fecha o modal principal (ManualPedidoModal) após sucesso
        }
    };

    const clearValidationErrors = () => {
        if (validationError) {
            setValidationError(null);
            setErrorItemId(null);
        }
    };

    // Atualiza o número do pedido quando o usuário digita
    const handleUpdatePedido = (itemXml: number, value: string) => {
        clearValidationErrors();
        setItensManuais(prevItens =>
            prevItens.map(item => {
                if (item.item_xml === itemXml) {
                    return {
                        ...item,
                        num_pedido: value,
                        // Limpa os dados da API pois a entrada foi manual
                        descricao_pedido_api: null,
                        valor_pedido_api: null,
                        registro_pedido: null,
                    };
                }
                return item;
            })
        );
    };

    const handleAIAssist = async () => {
        setIsAILoading(true);
        console.log("Chamando assistente de IA para preencher pedidos...");
        await new Promise(resolve => setTimeout(resolve, 1500));
        setNotification({ visible: true, type: 'error', message: 'Assistente de IA: Funcionalidade a ser implementada.' });
        setIsAILoading(false);
    };

    // Abre o modal de busca e busca os pedidos para o item selecionado
    const handleSearchPedido = async (item: ItemPedidoManual) => {
        setActiveSearchItem(item);
        setIsPedidoSearchModalOpen(true);
        setIsPedidoSearchLoading(true);
        setPedidoSearchError(null);
        setPedidoSearchResults([]);

        try {
            const response = await fetch('/api/nfe/nfe-busca-pedido-manual-item', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chave: chave,
                    item_xml: item.item_xml
                }),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Erro ao buscar pedidos.');
            }

            setPedidoSearchResults(Array.isArray(data) ? data : []);

        } catch (err: any) {
            setPedidoSearchError(err.message);
        } finally {
            setIsPedidoSearchLoading(false);
        }
    };

    // Atualiza o estado com os dados do pedido selecionado
    const handleSelectPedido = (pedido: PedidoEncontrado) => {
        clearValidationErrors();
        if (activeSearchItem !== null) {
            setItensManuais(prevItens =>
                prevItens.map(item => {
                    if (item.item_xml === activeSearchItem.item_xml) {
                        return {
                            ...item,
                            num_pedido: pedido.Pedido,
                            descricao_pedido_api: pedido.Produto,
                            valor_pedido_api: pedido.Valor,
                            registro_pedido: pedido.Registro, // ARMAZENANDO O R_E_C_N_O_
                        };
                    }
                    return item;
                })
            );
        }
        setIsPedidoSearchModalOpen(false);
        setActiveSearchItem(null);
    };

    const handleCloseSearchModal = () => {
        setIsPedidoSearchModalOpen(false);
        setActiveSearchItem(null);
    }

    // Funções para arrastar o modal
    const handleMouseDown = (e: React.MouseEvent) => {
        if (modalRef.current) {
            const target = e.target as HTMLElement;
            if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'BUTTON' || target.tagName === 'SELECT') {
                return;
            }
            setIsDragging(true);
            const modalRect = modalRef.current.getBoundingClientRect();
            setOffset({
                x: e.clientX - modalRect.left,
                y: e.clientY - modalRect.top
            });
            e.preventDefault();
        }
    };

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!isDragging) return;
        const newX = e.clientX - offset.x;
        const newY = e.clientY - offset.y;
        setPosition({ x: newX, y: newY });
    }, [isDragging, offset]);

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
    }, []);

    useEffect(() => {
        if (isDragging) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, handleMouseMove, handleMouseUp]);

    useEffect(() => {
        if (isOpen && modalRef.current) {
            const modal = modalRef.current;
            const initialX = (window.innerWidth - modal.offsetWidth) / 2;
            const initialY = 80;
            setPosition({ x: initialX > 0 ? initialX : 20, y: initialY });
        }
    }, [isOpen]);

    if (!isOpen) return null;

    return (
        <>
            <div onClick={isSaving ? undefined : () => setIsCancelConfirmOpen(true)} style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 2147483648 }}></div>
            <div
                ref={modalRef}
                style={{
                    position: 'fixed',
                    top: position.y,
                    left: position.x,
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    zIndex: 2147483649,
                    width: '95%',
                    maxWidth: '1200px',
                    display: 'flex',
                    flexDirection: 'column',
                    maxHeight: '90vh',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
                }}
            >
                <div
                    onMouseDown={handleMouseDown}
                    style={{
                        padding: '1.5rem',
                        borderBottom: '1px solid #dee2e6',
                        flexShrink: 0,
                        cursor: 'move',
                        backgroundColor: '#f1f5fb',
                        borderTopLeftRadius: '8px',
                        borderTopRightRadius: '8px'
                    }}
                >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>Informar Pedidos Manualmente</span>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                            <button
                                onClick={handleAIAssist}
                                disabled={isSaving || isAILoading}
                                title="Usar assistente de IA para preencher os pedidos"
                                style={{
                                    background: '#fff', border: '2px solid #facc15', padding: '8px 16px', borderRadius: '8px',
                                    cursor: (isSaving || isAILoading) ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center',
                                    gap: '8px', color: '#00314A', fontWeight: 600, fontSize: '0.9rem',
                                    transition: 'all 0.2s ease', opacity: (isSaving || isAILoading) ? 0.6 : 1,
                                }}
                                onMouseEnter={(e) => { if (!isSaving && !isAILoading) e.currentTarget.style.background = '#fffbea'; }}
                                onMouseLeave={(e) => { if (!isSaving && !isAILoading) e.currentTarget.style.background = '#fff'; }}
                            >
                                {isAILoading ? <FaSpinner className="animate-spin" /> : <Sparkles size={18} color="#f59e0b" />}
                                <span>{isAILoading ? "Aguarde..." : "Preencher com IA"}</span>
                            </button>
                            <button onClick={isSaving || isAILoading ? undefined : () => setIsCancelConfirmOpen(true)} disabled={isSaving || isAILoading} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: (isSaving || isAILoading) ? 'not-allowed' : 'pointer' }}>&times;</button>
                        </div>
                    </div>
                </div>

                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem', overflow: 'hidden', flexGrow: 1 }}>
                    {isLoadingContent ? (
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '3rem', color: '#6c757d', minHeight: '200px' }}>
                            <FaSpinner className="animate-spin" size={24} color="#1b4c89" />
                            <span style={{marginLeft: '10px', fontSize: '1.1em'}}>Carregando...</span>
                        </div>
                    ) : (
                        <>
                            <div style={{ overflowY: 'auto', flexGrow: 1 }}>
                                {validationError && (
                                    <div style={{ color: '#dc3545', fontWeight: 'bold', textAlign: 'center', marginBottom: '1rem', background: '#f8d7da', padding: '10px', borderRadius: '5px', border: '1px solid #f5c6cb' }}>
                                        {validationError}
                                    </div>
                                )}
                                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
                                    <thead style={{ backgroundColor: '#f1f5fb', color: '#1b4c89', position: 'sticky', top: 0, zIndex: 1 }}>
                                        <tr>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '5%' }}>Item</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'left', width: '25%' }}>Descrição XML</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '12%' }}>Valor Unit. (XML)</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '18%' }}>Pedido</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'left', width: '25%' }}>Descrição Pedido</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '10%' }}>Valor Pedido</th>
                                            <th style={{ padding: '12px', border: '1px solid #dee2e6', textAlign: 'center', width: '8%' }}>Diferença</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {itensManuais.map((item, index) => {
                                            const diferenca = (item.valor_pedido_api ?? 0) - (item.valor_unitario_xml ?? 0);
                                            let corDiferenca = '#333';
                                            if (diferenca > 0.001) corDiferenca = '#dc3545'; // Vermelho para maior
                                            if (diferenca < -0.001) corDiferenca = '#28a745'; // Verde para menor

                                            return (
                                                <tr key={item.item_xml} style={{ backgroundColor: activeSearchItem?.item_xml === item.item_xml ? '#fffbea' : (index % 2 === 0 ? '#fff' : '#f9f9f9') }}>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'center', fontWeight: 'bold' }}>{item.item_xml}</td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6' }}>{item.descricao_xml}</td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace' }}>
                                                        {item.valor_unitario_xml?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) ?? 'N/A'}
                                                    </td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'center' }}>
                                                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                                                            <input
                                                                type="text"
                                                                value={item.num_pedido || ''}
                                                                onChange={(e) => handleUpdatePedido(item.item_xml, e.target.value)}
                                                                style={{
                                                                    width: '100%',
                                                                    padding: '8px',
                                                                    borderRadius: '5px',
                                                                    border: item.item_xml === errorItemId ? '2px solid #dc3545' : '1px solid #ccc',
                                                                    transition: 'border-color 0.2s',
                                                                    boxShadow: item.item_xml === errorItemId ? '0 0 5px rgba(220, 53, 69, 0.5)' : 'none',
                                                                }}
                                                            />
                                                            <button
                                                                onClick={() => handleSearchPedido(item)}
                                                                title="Buscar Pedido"
                                                                disabled={isSaving || (isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml)}
                                                                style={{ background: '#eaf2fa', border: '1px solid #a3b8d1', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: (isSaving || (isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml)) ? 'not-allowed' : 'pointer', flexShrink: 0 }}
                                                            >
                                                                {isPedidoSearchLoading && activeSearchItem?.item_xml === item.item_xml ? <FaSpinner className="animate-spin" size={12} color="#1b4c89" /> : <FaSearch size={12} color="#1b4c89" />}
                                                            </button>
                                                        </div>
                                                    </td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6' }}>{item.descricao_pedido_api ?? ''}</td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace' }}>
                                                        {item.valor_pedido_api !== null ? item.valor_pedido_api.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : ''}
                                                    </td>
                                                    <td style={{ padding: '10px', border: '1px solid #dee2e6', textAlign: 'right', fontFamily: 'monospace', fontWeight: 'bold', color: corDiferenca }}>
                                                        {item.valor_pedido_api !== null ? diferenca.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : ''}
                                                    </td>
                                                </tr>
                                            )
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', marginTop: '1rem', flexShrink: 0 }}>
                                <div>
                                    <span style={{ fontWeight: 'bold', fontSize: '14px' }}>Total Diferença: </span>
                                    <span style={{ fontFamily: 'monospace', fontWeight: 'bold', fontSize: '14px', color: corTotalDiferenca }}>
                                        {totalDiferenca.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                    </span>
                                </div>
                                <div style={{ display: 'flex', gap: '1rem' }}>
                                    <button onClick={() => setIsCancelConfirmOpen(true)} disabled={isSaving} style={{ padding: '10px 20px', borderRadius: '5px', border: '1px solid #ccc', background: '#f1f1f1', cursor: isSaving ? 'not-allowed' : 'pointer', fontWeight: 'bold' }}>Cancelar</button>
                                    <button onClick={handleSave} disabled={isSaving} style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: '#28a745', color: 'white', cursor: isSaving ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}>
                                        {isSaving ? <><FaSpinner className="animate-spin" /> Salvando...</> : 'Salvar Alterações'}
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>

            <ConfirmationModal
                isOpen={isCancelConfirmOpen}
                onClose={() => setIsCancelConfirmOpen(false)}
                onConfirm={onClose}
                title="Confirmar Cancelamento"
                message="Você tem certeza que deseja cancelar? Todas as alterações não salvas serão perdidas."
                confirmText="Sim, Cancelar"
                confirmColor="#dc3545"
            />
            
            <PedidoSearchModal
                isOpen={isPedidoSearchModalOpen}
                onClose={handleCloseSearchModal}
                onSelect={handleSelectPedido}
                searchResults={pedidoSearchResults}
                isLoading={isPedidoSearchLoading}
                error={pedidoSearchError}
                activeItemInfo={activeSearchItem ? { item: String(activeSearchItem.item_xml), descricao: activeSearchItem.descricao_xml } : null}
            />
            <NotificationModal
                visible={notification.visible}
                type={notification.type}
                message={notification.message}
                onClose={handleNotificationClose}
            />
        </>
    );
};

export default ManualPedidoModal;