import { NextRequest } from "next/server";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();

    // validações simples
    const required = ["empreendimentoId", "tipo", "file"];
    for (const key of required) {
      if (!form.get(key)) {
        return new Response(JSON.stringify({ ok: false, error: `${key} ausente` }), {
          status: 400,
          headers: { "content-type": "application/json" },
        });
      }
    }

    const tipo = String(form.get("tipo"));

    // opções aceitas
    const allowedTipos = [
      "certidao_inteiro_teor",
      "ccir",
      "itr",
      "geo",
      "kml",
      "cib",
    ];

    if (!allowedTipos.includes(tipo)) {
      return new Response(JSON.stringify({ ok: false, error: `tipo inválido (${tipo})` }), {
        status: 400,
        headers: { "content-type": "application/json" },
      });
    }

    // URL fixa do webhook do n8n
    const n8nUrl = "http://localhost:5678/webhook/agrogestor-uploads";

    // repassa o FormData para o n8n
    const forward = new FormData();
    for (const [k, v] of form.entries()) {
      forward.append(k, v as any);
    }

    const resp = await fetch(n8nUrl, { method: "POST", body: forward });
    const text = await resp.text();

    let data: any;
    try {
      data = JSON.parse(text);
    } catch {
      data = { ok: resp.ok, raw: text };
    }

    return new Response(JSON.stringify(data), {
      status: resp.status,
      headers: { "content-type": "application/json" },
    });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || "falha no proxy" }), {
      status: 500,
      headers: { "content-type": "application/json" },
    });
  }
}
