import { useEffect, useState } from "react";
import { FaCheckCircle, FaTimesCircle } from "react-icons/fa";

// Nenhuma alteração nas interfaces
interface ModalDetalhesProps {
  nomeFornecedor?: string;
  chave: string;
  visivel: boolean;
  onClose: () => void;
}

interface ItemNota {
  item_xml: number;
  descricao_xml: string;
  descricao_pedido: string | null;
  unidade_pedido: string | null;
  num_pedido: string | null;
  similaridade_descricao: number;
  valor_unitario_bate: string;
  justificativa: string;
  item_ok: string;
  enviada?: string;
  dt_enviada?: string;
  nome_fornecedor?: string;
  nome_usuario?: string;
}

interface ErroExecAuto {
  dt_movimentacao: string;
  campo: string;
  motivo: string;
  mensagem_original: string;
}

// O componente FormattedOriginalMessage permanece o mesmo
const FormattedOriginalMessage = ({ message }: { message: string | null }) => {
  if (!message) {
    return <pre style={preStyle}>N/A</pre>;
  }

  try {
    const data = JSON.parse(message);
    const details = data.detalhes || "";
    const lines = details.split('\\n');

    return (
      <div style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: '#721c24', lineHeight: '1.6' }}>
        {data.erro && <div style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>{data.erro}</div>}
        {lines.map((line: string, index: number) => {
          if (line.trim() === '') return <div key={index} style={{ height: '0.5rem' }} />;
          if (line.includes(':-')) {
            const parts = line.split(':-');
            const key = parts[0].trim();
            const value = parts[1].trim();
            return (
              <div key={index} style={{ display: 'grid', gridTemplateColumns: '160px 1fr', gap: '10px' }}>
                <span style={{ color: '#555' }}>{key}</span>
                <span style={{ fontWeight: 'bold' }}>{value}</span>
              </div>
            );
          }
          return <div key={index}>{line.trim()}</div>;
        })}
      </div>
    );
  } catch (error) {
    return <pre style={preStyle}>{message.replace(/\\n/g, '\n')}</pre>;
  }
};

const preStyle: React.CSSProperties = {
  background: '#f8d7da',
  padding: '0.75rem',
  borderRadius: '4px',
  whiteSpace: 'pre-wrap',
  wordBreak: 'break-all',
  fontSize: '0.85rem',
  color: '#721c24',
  marginTop: '0.5rem'
};


export default function ModalDetalhes({ chave, visivel, onClose, nomeFornecedor }: ModalDetalhesProps) {
  const [itens, setItens] = useState<ItemNota[]>([]);
  const [numNF, setNumNF] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [respostaInvalida, setRespostaInvalida] = useState(false);
  const [movimentacoes, setMovimentacoes] = useState<any[]>([]);
  const [errosExecAuto, setErrosExecAuto] = useState<ErroExecAuto[]>([]);
  const [activeTab, setActiveTab] = useState<'itens' | 'historico' | 'erros'>('itens');

  useEffect(() => {
    if (!visivel || !chave) return;
    
    setLoading(true);
    setItens([]);
    setMovimentacoes([]);
    setErrosExecAuto([]);
    setActiveTab('itens');

    const fetchDetalhes = async () => {
      try {
        const response = await fetch("/api/nfe-consulta-notas-itens", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chave })
        });
        const data = await response.json();
        if (Array.isArray(data) && data.length > 0 && "itens" in data[0] && Array.isArray(data[0].itens) && data[0].itens.length > 0) {
          setItens(data[0].itens);
          setNumNF(data[0]?.num_nf ?? '');
          setRespostaInvalida(false);
        } else {
          setItens([]);
          setRespostaInvalida(true);
        }
      } catch (error) {
        console.error("Erro ao buscar itens da nota:", error);
        setItens([]);
        setRespostaInvalida(true);
      } finally {
        // Apenas para simular um tempo de carregamento mínimo
        setTimeout(() => setLoading(false), 500);
      }
    };

    const fetchMovimentacoes = async () => {
      try {
        const response = await fetch("/api/nfe-consulta-historico", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chave })
        });
        const data = await response.json();
        setMovimentacoes(data);
      } catch (error) {
        console.error("Erro ao buscar histórico:", error);
        setMovimentacoes([]);
      }
    };

    const fetchErrosExecAuto = async () => {
      try {
        const response = await fetch("/api/nfe-consulta-erro-execauto", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chave })
        });
        const data = await response.json();
        const validErros = Array.isArray(data) ? data.filter((err: any) => err.campo || err.motivo || err.mensagem_original) : [];
        setErrosExecAuto(validErros);
      } catch (error) {
        console.error("Erro ao buscar erros do ExecAuto:", error);
        setErrosExecAuto([]);
      }
    };

    fetchDetalhes();
    fetchMovimentacoes();
    fetchErrosExecAuto();
  }, [visivel, chave]);

  if (!visivel) return null;

  const renderStatusIcon = (value: string) => {
    const isPositive = value?.toLowerCase() === "sim";
    return isPositive ? (
      <FaCheckCircle style={{ color: "green" }} title="Sim" />
    ) : (
      <FaTimesCircle style={{ color: "red" }} title="Não" />
    );
  };

  return (
    <>
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.4)', zIndex: 2147483646 }}></div>
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 2147483647, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ background: '#fff', borderRadius: 12, width: '90%', maxWidth: '1100px', minHeight: '400px', maxHeight: '90vh', display: 'flex', flexDirection: 'column', boxShadow: '0 10px 30px rgba(0,0,0,0.2)', position: 'relative', padding: '1.5rem' }}>
          
          {/* ✅ MUDANÇA AQUI: Renderização condicional do conteúdo do modal */}
          {loading ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexGrow: 1, height: '100%' }}>
              <div style={{ width: '40px', height: '40px', border: '4px solid #ccc', borderTop: '4px solid #1b4c89', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
              <div style={{ marginTop: '1rem', color: '#1b4c89', fontWeight: 'bold', fontSize: '1.1rem' }}>Aguarde... Carregando os dados da Nota Fiscal</div>
            </div>
          ) : (
            <>
              <div style={{ fontSize: '1.2rem', fontWeight: 'bold', marginBottom: '1rem', display: 'flex', justifyContent: 'space-between', flexShrink: 0 }}>
                Detalhes da Nota
                <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}>×</button>
              </div>
              
              {(itens.length > 0) && (
                <div style={{ background: '#f1f5fb', borderRadius: '8px', padding: '0.5rem 1rem', marginBottom: '1rem', border: '1px solid #d0d7e2', flexShrink: 0 }}>
                   <div style={{ display: 'grid', gridTemplateColumns: '160px 1fr 160px 1fr', rowGap: '4px', columnGap: '12px', fontSize: '14px' }}>
                    <div style={{ fontWeight: 'bold' }}>Nota Fiscal:</div><div>{numNF || '-'}</div>
                    <div style={{ fontWeight: 'bold' }}>Nome Fornecedor:</div><div>{nomeFornecedor?.trim() || '-'}</div>
                    <div style={{ fontWeight: 'bold' }}>Chave da Nota:</div><div>{chave}</div>
                    <div style={{ fontWeight: 'bold' }}>Enviado pela Unidade:</div><div>{renderStatusIcon(itens[0]?.enviada ?? '-')}</div>
                    <div style={{ fontWeight: 'bold' }}>Número do Pedido:</div><div>{Array.from(new Set(itens.map(i => i.num_pedido).filter(p => p))).join(', ') || '-'}</div>
                    <div style={{ fontWeight: 'bold' }}>Data do Envio:</div><div>{itens[0]?.dt_enviada ? new Date(itens[0].dt_enviada).toLocaleDateString() : '-'}</div>
                    <div style={{ fontWeight: 'bold' }}>Comprador:</div>
                    <div>{(() => {
                      const nomes = itens.map(i => i.nome_usuario?.trim()).filter(n => !!n);
                      if (nomes.length === 0) return '-';
                      const contagem = nomes.reduce((acc, nome) => {
                        acc[nome] = (acc[nome] || 0) + 1;
                        return acc;
                      }, {});
                      return Object.entries(contagem).sort((a, b) => b[1] - a[1])[0][0];
                    })()}</div>
                    <div style={{ fontWeight: 'bold' }}>Dias do Envio:</div>
                    <div>{(() => {
                      const enviada = itens[0]?.dt_enviada;
                      if (!enviada) return '-';
                      const diff = Math.floor((new Date().getTime() - new Date(enviada).getTime()) / (1000 * 60 * 60 * 24));
                      return diff + ' dias';
                    })()}</div>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', marginBottom: '1rem', borderBottom: '1px solid #e0e0e0', flexShrink: 0 }}>
                <button onClick={() => setActiveTab('itens')} style={{ padding: '0.75rem 1.5rem', border: 'none', background: 'none', cursor: 'pointer', fontSize: '1rem', fontWeight: activeTab === 'itens' ? 'bold' : 'normal', color: activeTab === 'itens' ? '#1b4c89' : '#555', borderBottom: activeTab === 'itens' ? '2px solid #1b4c89' : 'none' }}>Itens</button>
                <button onClick={() => setActiveTab('historico')} style={{ padding: '0.75rem 1.5rem', border: 'none', background: 'none', cursor: 'pointer', fontSize: '1rem', fontWeight: activeTab === 'historico' ? 'bold' : 'normal', color: activeTab === 'historico' ? '#1b4c89' : '#555', borderBottom: activeTab === 'historico' ? '2px solid #1b4c89' : 'none' }}>Histórico</button>
                <button onClick={() => setActiveTab('erros')} style={{ padding: '0.75rem 1.5rem', border: 'none', background: 'none', cursor: 'pointer', fontSize: '1rem', fontWeight: activeTab === 'erros' ? 'bold' : 'normal', color: activeTab === 'erros' ? '#1b4c89' : '#555', borderBottom: activeTab === 'erros' ? '2px solid #1b4c89' : 'none' }}>Erros</button>
              </div>
              
              <div style={{ overflowY: 'auto', flexGrow: 1 }}>
                  {activeTab === 'itens' && (
                    (respostaInvalida || itens.length === 0) ? (
                      <p style={{ textAlign: 'center', color: '#888', paddingTop: '2rem' }}>Nenhum item a ser exibido para esta nota.</p>
                    ) : (
                      <div>
                        <h3 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '1rem' }}>📝 Itens da Nota Fiscal</h3>
                        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
                          <thead style={{ backgroundColor: '#1b4c89', color: '#fff' }}>
                            <tr>
                              <th style={{ padding: '10px', border: '1px solid #ccc', textAlign: 'left' }}>Item XML</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc', textAlign: 'left' }}>Descrição XML</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc', textAlign: 'left' }}>Descrição Pedido</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc' }}>Pedido</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc' }}>Similaridade</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc' }}>Valor Bate</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc' }}>Item OK</th>
                              <th style={{ padding: '10px', border: '1px solid #ccc', textAlign: 'left' }}>Justificativa</th>
                            </tr>
                          </thead>
                          <tbody>
                            {itens.map((item, index) => (
                              <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#f9f9f9' : '#fff' }}>
                                <td style={{ padding: '8px', border: '1px solid #ddd' }}>{item.item_xml}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd' }}>{item.descricao_xml}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd' }}>{item.descricao_pedido ?? '-'}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>{item.num_pedido ?? '-'}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>{item.similaridade_descricao}%</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>{renderStatusIcon(item.valor_unitario_bate)}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd', textAlign: 'center' }}>{renderStatusIcon(item.item_ok)}</td>
                                <td style={{ padding: '8px', border: '1px solid #ddd' }}>{item.justificativa}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )
                  )}

                  {activeTab === 'historico' && (
                    (movimentacoes.length === 0) ? (
                      <p style={{ textAlign: 'center', color: '#888', paddingTop: '2rem' }}>Não há movimentações no histórico ainda.</p>
                    ) : (
                    <div>
                      <h3 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '1rem' }}>🧾 Histórico de Movimentações</h3>
                      <div style={{ backgroundColor: '#f4f6fb', padding: '1rem', borderRadius: '8px', border: '1px solid #d0d7e2' }}>
                          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                            {movimentacoes.map((mov, idx) => {
                              const isSystem = (mov.cod_usuario || '').toLowerCase().includes('integração') || (mov.cod_usuario || '').toLowerCase().includes('sistema');
                              const dias = Math.floor((new Date().getTime() - new Date(mov.dt_movimentacao).getTime()) / (1000 * 60 * 60 * 24));
                              const dataFormatada = new Date(mov.dt_movimentacao).toLocaleString('pt-BR', { timeZone: 'UTC' });
                              return (
                                <li key={idx} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start', marginBottom: idx === movimentacoes.length - 1 ? 0 : '1rem', background: '#fff', padding: '1rem', borderRadius: '8px', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                                  <div style={{ flexShrink: 0 }}><div style={{ width: '36px', height: '36px', borderRadius: '50%', backgroundColor: isSystem ? '#1b4c89' : '#ccc', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '0.9rem' }}>{isSystem ? '⚙️' : '👤'}</div></div>
                                  <div style={{ flexGrow: 1 }}>
                                    <strong style={{ color: '#1b4c89' }}>{mov.nome || mov.cod_usuario || 'Sistema'}</strong>
                                    <div style={{ fontSize: '0.8rem', color: '#777', marginBottom: '0.25rem' }}>{dataFormatada} - {dias} dias atrás</div>
                                    <div style={{ fontSize: '0.95rem', color: '#333' }}>{mov.mensagem}</div>
                                  </div>
                                </li>
                              );
                            })}
                          </ul>
                      </div>
                    </div>
                    )
                  )}

                  {activeTab === 'erros' && (
                    (errosExecAuto.length === 0) ? (
                      <p style={{ textAlign: 'center', color: '#888', paddingTop: '2rem' }}>Não há erros a serem exibidos para esta nota.</p>
                    ) : (
                    <div>
                      <h3 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '1rem' }}>❗ Ocorrências de Erro ExecAuto</h3>
                      <div style={{ backgroundColor: '#fff0f0', padding: '1rem', borderRadius: '8px', border: '1px solid #f5c2c7' }}>
                          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                            {errosExecAuto.map((err, idx) => {
                              let dataFormatada = "Data não informada";
                              if (err.dt_movimentacao) {
                                const dt = new Date(err.dt_movimentacao);
                                if (!isNaN(dt.getTime())) { 
                                  dataFormatada = dt.toLocaleString('pt-BR', { timeZone: 'UTC' }); 
                                }
                              }
                              return (
                                <li key={idx} style={{ background: '#fff', borderLeft: '4px solid #dc3545', padding: '1rem', borderRadius: '8px', marginBottom: idx === errosExecAuto.length - 1 ? 0 : '1rem', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                                  <div style={{ fontSize: '0.85rem', color: '#dc3545', fontWeight: 'bold', marginBottom: '0.5rem' }}>{dataFormatada}</div>
                                  <div style={{ fontSize: '0.95rem', color: '#333', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                    <div><strong>Campo:</strong> {err.campo || '-'}</div>
                                    <div><strong>Motivo:</strong> {err.motivo || '-'}</div>
                                    <div>
                                      <strong>Mensagem:</strong>
                                      <div style={{ background: '#f8d7da', padding: '0.75rem', borderRadius: '4px', marginTop: '0.5rem' }}>
                                        <FormattedOriginalMessage message={err.mensagem_original} />
                                      </div>
                                    </div>
                                  </div>
                                </li>
                              );
                            })}
                          </ul>
                      </div>
                    </div>
                    )
                  )}
              </div>
            </>
          )}

        </div>
      </div>
    </>
  );
}
