"use client";
import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { FaSearch, FaSpinner, FaTimesCircle, FaCheckCircle } from "react-icons/fa";

/** Tipos mínimos para plugar no seu ModalDetalhes */
export type TesBuscaResult = { codigo: string; descricao: string };
export type ItemNota = { item_xml: number; descricao_xml: string };
export type TesItem = { id: number; nItem: number; tes_codigo: string };
export type TesData = { chave: string; total_itens: number; itens: TesItem[] };
export type ApiMessage = { type: "success" | "error"; text: string };

type Props = {
  open: boolean;
  onClose: () => void;
  onSave: (updates: { id: number; tes: string }[]) => Promise<void>;
  items: ItemNota[];
  tesData: TesData | null;
  loading?: boolean;
  apiMessage?: ApiMessage | null;
  /** endpoint de busca TES (POST { tesCode }) -> [{F4_CODIGO, F4_TEXTO}] */
  endpointBuscaTes?: string;
};

export default function ModalTes({
  open,
  onClose,
  onSave,
  items,
  tesData,
  loading = false,
  apiMessage = null,
  endpointBuscaTes = "/api/nfe/nfe-busca-tes",
}: Props) {
  const [updates, setUpdates] = useState<Record<number, string>>({});
  const [validationError, setValidationError] = useState<string | null>(null);

  /** Busca TES */
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeItem, setActiveItem] = useState<TesItem | null>(null);
  const [term, setTerm] = useState("");
  const [results, setResults] = useState<TesBuscaResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  /** drag */
  const modalRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [off, setOff] = useState({ x: 0, y: 0 });
  const [drag, setDrag] = useState(false);

  useEffect(() => {
    if (open && tesData) {
      const initial = tesData.itens.reduce((acc, it) => {
        if (it.id) acc[it.id] = it.tes_codigo ?? "";
        return acc;
      }, {} as Record<number, string>);
      setUpdates(initial);
      setValidationError(null);
    }
  }, [open, tesData]);

  const mapByItemXml = useMemo(() => {
    const idx: Record<number, TesItem> = {};
    tesData?.itens.forEach((t) => (idx[t.nItem] = t));
    return idx;
  }, [tesData]);

  const openSearch = (it: TesItem) => {
    setActiveItem(it);
    setTerm("");
    setResults([]);
    setSearchError(null);
    setSearchOpen(true);
  };

  const doSearch = async () => {
    if (term.trim().length < 2) {
      setSearchError("Digite pelo menos 2 caracteres.");
      setResults([]);
      return;
    }
    setSearchLoading(true);
    setSearchError(null);
    try {
      const resp = await fetch(endpointBuscaTes, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tesCode: term }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data?.message || "Erro na busca de TES.");
      const list = (Array.isArray(data) ? data : []).map((r: any) => ({
        codigo: r.F4_CODIGO,
        descricao: r.F4_TEXTO,
      }));
      setResults(list);
      if (list.length === 0) setSearchError("Nenhuma TES encontrada.");
    } catch (e: any) {
      setSearchError(e.message);
    } finally {
      setSearchLoading(false);
    }
  };

  const selectTes = (t: TesBuscaResult) => {
    if (activeItem?.id) {
      setUpdates((p) => ({ ...p, [activeItem.id!]: t.codigo }));
    }
    setSearchOpen(false);
  };

  const handleSave = () => {
    if (!tesData) return;
    const needAll = tesData.itens.every((i) => updates[i.id] && updates[i.id].trim() !== "");
    if (!needAll) {
      setValidationError("Todos os itens devem ter uma TES preenchida.");
      return;
    }
    const original = tesData.itens.reduce((acc, it) => {
      acc[it.id] = it.tes_codigo ?? "";
      return acc;
    }, {} as Record<number, string>);

    const diff = Object.entries(updates)
      .filter(([id, tes]) => (original[Number(id)] ?? "") !== (tes ?? ""))
      .map(([id, tes]) => ({ id: Number(id), tes }));

    if (diff.length > 0) onSave(diff);
    else onClose();
  };

  /** drag handlers */
  const onMouseDown = (e: React.MouseEvent) => {
    if (!modalRef.current) return;
    const t = e.target as HTMLElement;
    if (["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(t.tagName)) return;
    setDrag(true);
    const r = modalRef.current.getBoundingClientRect();
    setOff({ x: e.clientX - r.left, y: e.clientY - r.top });
    e.preventDefault();
  };
  const onMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!drag) return;
      setPos({ x: e.clientX - off.x, y: e.clientY - off.y });
    },
    [drag, off]
  );
  const onMouseUp = useCallback(() => setDrag(false), []);
  useEffect(() => {
    if (drag) {
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  }, [drag, onMouseMove, onMouseUp]);
  useEffect(() => {
    if (open && modalRef.current) {
      const m = modalRef.current;
      const x = (window.innerWidth - m.offsetWidth) / 2.2;
      const y = 60;
      setPos({ x: x > 0 ? x : 20, y });
    }
  }, [open]);

  if (!open) return null;

  return (
    <>
      <div onClick={loading ? undefined : onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 2147483648 }} />
      <div ref={modalRef} style={{ position: "fixed", top: pos.y, left: pos.x, background: "#fff", borderRadius: 8, zIndex: 2147483649, width: "92%", maxWidth: 920, display: "flex", flexDirection: "column", maxHeight: "90vh", boxShadow: "0 10px 30px rgba(0,0,0,.2)" }}>
        <div onMouseDown={onMouseDown} style={{ padding: "1.2rem 1.5rem", borderBottom: "1px solid #e9ecef", background: "#f1f5fb", borderTopLeftRadius: 8, borderTopRightRadius: 8, cursor: "move" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <strong>Informar TES Manualmente</strong>
            <button onClick={loading ? undefined : onClose} style={{ border: "none", background: "none", fontSize: "1.5rem", cursor: loading ? "not-allowed" : "pointer" }}>
              &times;
            </button>
          </div>
        </div>

        {/** mensagens */}
        <div style={{ padding: "0.8rem 1.5rem" }}>
          {apiMessage && (
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 600, color: apiMessage.type === "success" ? "#28a745" : "#dc3545" }}>
              {apiMessage.type === "success" ? <FaCheckCircle /> : <FaTimesCircle />} {apiMessage.text}
            </div>
          )}
          {validationError && (
            <div style={{ marginTop: 8, background: "#f8d7da", border: "1px solid #f5c6cb", color: "#721c24", padding: ".6rem .8rem", borderRadius: 6 }}>
              {validationError}
            </div>
          )}
        </div>

        {/** tabela */}
        <div style={{ padding: "0 1.5rem 1rem", overflow: "hidden", flexGrow: 1 }}>
          <div style={{ overflowY: "auto", maxHeight: "60vh" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
              <thead style={{ position: "sticky", top: 0, zIndex: 1, background: "#f1f5fb", color: "#1b4c89" }}>
                <tr>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 80, textAlign: "center" }}>Item</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", textAlign: "left" }}>Descrição XML</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 160, textAlign: "center" }}>TES</th>
                  <th style={{ padding: 10, border: "1px solid #e9ecef", width: 60 }} />
                </tr>
              </thead>
              <tbody>
                {items.map((it, idx) => {
                  const info = mapByItemXml[it.item_xml];
                  if (!info?.id) return null;
                  return (
                    <tr key={it.item_xml} style={{ background: idx % 2 ? "#fafafa" : "#fff" }}>
                      <td style={{ padding: 10, border: "1px solid #f1f1f1", textAlign: "center", fontWeight: 700 }}>{it.item_xml}</td>
                      <td style={{ padding: 10, border: "1px solid #f1f1f1" }}>{it.descricao_xml}</td>
                      <td style={{ padding: 10, border: "1px solid #f1f1f1", textAlign: "center", fontWeight: 700 }}>{updates[info.id] || ""}</td>
                      <td style={{ padding: 10, border: "1px solid #f1f1f1", textAlign: "center" }}>
                        <button
                          onClick={() => openSearch(info)}
                          disabled={loading}
                          title="Buscar TES"
                          style={{ width: 34, height: 34, borderRadius: "50%", border: "1px solid #a3b8d1", background: "#eaf2fa", display: "flex", alignItems: "center", justifyContent: "center", cursor: loading ? "not-allowed" : "pointer" }}
                        >
                          <FaSearch size={12} color="#1b4c89" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 12 }}>
            <button onClick={onClose} disabled={loading} style={{ padding: "10px 18px", borderRadius: 6, border: "1px solid #ced4da", background: "#f1f1f1", fontWeight: 700, cursor: loading ? "not-allowed" : "pointer" }}>
              Cancelar
            </button>
            <button onClick={handleSave} disabled={loading} style={{ padding: "10px 18px", borderRadius: 6, border: "none", background: "#28a745", color: "#fff", fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", display: "flex", alignItems: "center", gap: 8 }}>
              {loading ? <><FaSpinner className="animate-spin" /> Salvando...</> : "Salvar Alterações"}
            </button>
          </div>
        </div>
      </div>

      {/** modal interno de busca TES */}
      {searchOpen && (
        <>
          <div onClick={() => setSearchOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2147483650 }} />
          <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "#fff", borderRadius: 8, zIndex: 2147483651, width: "92%", maxWidth: 520, padding: "1rem 1.2rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <strong>Buscar TES</strong>
              <button onClick={() => setSearchOpen(false)} style={{ border: "none", background: "none", fontSize: "1.4rem", cursor: "pointer" }}>&times;</button>
            </div>
            <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
              <input value={term} onChange={(e) => setTerm(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doSearch()} placeholder="Digite o código ou descrição..." style={{ flex: 1, padding: 10, borderRadius: 6, border: "1px solid #ced4da" }} autoFocus />
              <button onClick={doSearch} disabled={searchLoading} style={{ padding: "10px 14px", borderRadius: 6, border: "none", background: "#1b4c89", color: "#fff", fontWeight: 700 }}>
                {searchLoading ? <FaSpinner className="animate-spin" /> : "Buscar"}
              </button>
            </div>
            {searchError && <div style={{ color: "#dc3545", marginBottom: 8 }}>{searchError}</div>}
            <div style={{ border: "1px solid #eee", borderRadius: 6, maxHeight: 300, overflowY: "auto" }}>
              {results.length > 0 ? results.map((r) => (
                <div key={r.codigo} onClick={() => selectTes(r)} style={{ padding: 10, borderBottom: "1px solid #f3f3f3", cursor: "pointer" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f0f8ff")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "#fff")}
                >
                  <strong style={{ color: "#1b4c89" }}>{r.codigo}</strong> — {r.descricao}
                </div>
              )) : !searchLoading && <div style={{ padding: 14, color: "#6c757d" }}>Nenhum resultado.</div>}
            </div>
          </div>
        </>
      )}
    </>
  );
}
